## 变更记录
### 2026-09-30 | feat：接入食安佳 H5 动态追溯接口适配器
- **定因**：`h5.shiaj.com/t/64?...` 返回的 HTML 只有前端模板，真实资料由浏览器脚本调用 `CheckTraceCodeAllInOne/64` 与 `ProductCertificate/64` 获取；截图视觉识别只能看到空模板，无法稳定提取字段。
- **实现**：新增 `server/utils/source-adapters/shiaj.ts`，固定使用站方 `X-Source: H5` 请求头和公开 POST 接口，提取产品、登记证、持有人、企业、剂型、毒性、含量、规格、许可证、标准号、有效期和原药信息；适配器失败时仍回到通用抓取/视觉兜底。
- **验证**：固定响应映射测试通过；`node --test tests/source-adapters.test.mjs` 为 8/8（另 4 条真接口测试因本机 DNS 代理把外站解析为非公网地址而无法执行，非代码断言失败）。
- **属性**：零 DDL、零依赖、零新增密钥；新增 POST 请求能力仍复用来源域名公网地址校验；需重新打包上线。
### 2026-09-30 | feat：增加外部动态页面截图与 DeepSeek 视觉校验兜底
- **流程**：普通 HTML 解析读不到动态页面时，调用本机无头 Chrome 等待脚本渲染并截图，再将 PNG 发送给 DeepSeek `deepseek-flash` 视觉模型。
- **安全与准确性**：密钥只从 `.env` 的 `DEEPSEEK_API_KEY` 读取；模型按字段返回值和置信度，低于阈值的字段留空，随后复用既有登记库比对；截图不落库，失败自动回到原有提示。
- **配置**：新增 `DEEPSEEK_BASE_URL`、`DEEPSEEK_VISION_MODEL`、`DEEPSEEK_VISION_ENABLED`、`PLAYWRIGHT_EXECUTABLE_PATH` 示例；本机密钥未进入 Git。
- **验证**：`tsc --noEmit` 仅剩既有 `server/utils/bill-input.ts(86,5)` 类型错误；无 DDL、无依赖变更。
### 2026-09-30 | feat：账本首页精简为查询与支出概览入口
- **用户裁定**：删除首页统计卡片和展开的查询表单；查询改按钮打开弹窗；支出概览进入独立页面展示总花费、近六个月柱状图和用肥/用药/其他支出三类饼图。
- **实现**：查询草稿打开时回填、取消不应用；概览各项统一按近六个月汇总，当前年份截止本月、历史年份截止十二月，跨年按年月取数；无数据、加载和失败状态均有提示。图表复用已有 SVG 组件，手机图例上下排列避免拥挤。
- **验证**：生产构建完成；跨年六个月、历史年份、旧类别兼容与分类合计验证通过；类型检查仅既有 bill-input.ts(86,5) 错误。零 DDL、零依赖、未上线。
### 2026-09-30 | feat：记账体验改进（门店字段、其他支出、重复记账提醒）
- **范围**：总金额必填文案统一；购买渠道为“农资店”时增加独立的具体门店字段；用途增加“其他支出”统计桶，避免把无法归类的费用算进用药；保存时对同一消费者、日期、产品和金额的重复账单弹出确认，用户仍可确认继续保存。
- **接口与数据库**：`farm_bill.store_name` 增量迁移；POST/PATCH/GET 全链路支持；用药统计改为总额减去用肥和其他支出。
- **验证**：`npm run build` 通过；`tsc --noEmit` 仍只有既有 `server/utils/bill-input.ts` 类型错误（历史问题）。
### 2026-09-29 | feat：账本增加筛选并提升记账完整率
- **用户需求**：实现产品建议 1（账本搜索/筛选）与 4（提高记账信息完整率）。
- **筛选**：`/bill` 增加产品名称关键词、日期范围、作物、购买渠道筛选；服务端 `/api/bill` 统一把筛选条件应用到列表和统计，空结果会给出筛选态提示。
- **完整率**：总金额从“缺失时按数量×单价或 0 兜底”改为前后端都必须明确填写；保存成功后若数量、单价、作物、购买渠道未填，会提示可继续补充，但不阻断记账。
- **属性**：零 DDL、零依赖；旧账仍可查看和编辑，筛选只影响当前查询结果。
### 2026-09-29 | fix：记账本金额统一使用黑色正文色
- **用户反馈**：账本中的红色金额过于刺眼，希望金额改为黑色。
- **改动**：账本首页的成本卡、逐笔金额、月小计、全年总计、删除确认摘要，以及成本分析页摘要/作物金额、分类图例和记账弹窗总金额输入框，统一从 `text-error` 改为 `text-default`；删除与异常按钮仍保留红色强调。
- **属性**：仅前端展示样式调整，零接口、零数据库、零依赖变更。
### 2026-09-28 | fix：external_source_snapshot 存储放大收口（失败不落原文 · 失败也进缓存 · 成功截 64KB）
- **触发**：AGENTS.md 遗留待办①（`external_source_snapshot` 存储放大，服务器与 cynx 共用磁盘长期 75%+），
  用户裁定「本轮就改这个」。
- **三重放大（定因，逐条对上代码）**：① `raw_document` 是 `MEDIUMTEXT`（上限 16MB），而抓取侧只在 **1MB**
  处截断（`source-fetch.ts`：`size > 1024 * 1024` 即 destroy）⇒ **表本身完全没有兜底**；② 抓取或解析**失败时
  原文照样落库**，而失败页恰恰是读不出内容的那一类，留着几乎无用；③ 失败行原本**整条排除在缓存之外**
  （`status <> 'unavailable'`）⇒ 每次重试都要重新抓一次外站、再落一行 —— **这是放大的主因**。
- **改法（收口在单模块，不碰抓取/解析/判定）**：新增 `server/utils/source-raw-cap.ts`，只回答两件事 ——
  **原文留多少**（`capRawDocument`，默认 `RAW_DOCUMENT_MAX_BYTES = 64KB`；按 UTF-8 字节上限截断，
  **且向前退到字符起始处**，绝不把一个中文/emoji 切成半个乱码字符）、**缓存留多久**
  （`SUCCESS_CACHE_MINUTES = 10` 维持原值 / `FAILURE_CACHE_MINUTES = 2` 新增）。`source-snapshot.ts` 三处改：
  ① 缓存查询改为按行自身 status 选 TTL（失败行也复用，2 分钟）—— `created_at > IF(JSON_UNQUOTE(JSON_EXTRACT(payload,'$.status'))='unavailable', DATE_SUB(NOW(), INTERVAL ? MINUTE), DATE_SUB(NOW(), INTERVAL ? MINUTE))`；
  ② 增 `succeeded` 标记（走到「解析出声明」才为真）；③ INSERT 时失败传 `NULL`、成功传 `capRawDocument(document)`。
- **实测（硬证据，非推断）**：`ddspp` 成功页原文 **235,414 B → 65,536 B**；`jilinhengda` 失败壳 **344 B 原文被丢弃**
  （库内 `raw_document IS NULL`）；失败重试在 2 分钟内**不再新增行**（负缓存生效）。验证脚本
  `logs/_verify-rawcap.mjs`（直连真库验 TTL 子句 5 用例）与 `logs/_verify-rawcap-e2e.mjs`（HTTP 全链路：
  失败不落原文 / 负缓存 / 成功 ≤64KB）。
- **回归**：`tests/source-raw-cap.test.mjs` **6/6**（新增）· `source-snapshot` **8/8** · `external-summary` **5/5**
  · `source-adapters` **6/6（+3 例真接口默认跳过）**；`tsc --noEmit` 仅剩既有 `bill-input.ts(85,5)`。
- **属性**：**零 DDL**（`db-init.mjs` 逐字节未变、表数仍 17）· **零依赖** · **零 `.env`** · **零 nginx** · **零删除**；
  `SOURCE_PARSER_VERSION` 未动（仍 `2026-09-27.4`，本轮没动解析口径）。⚠️ **未上线** —— 不在 41 号包内
  （41 号范围止于 `4d0f83d`），需另打包含本轮 3 个文件的新包。
### 2026-09-28 | docs(fix)：纠正「单测 13/13」错记（那是两文件合计数，单文件是 8 例）
- **触发**：收尾复测按 `AGENTS.md` 现状块口径重跑 `node --test tests/source-snapshot.test.mjs`，得 **8/8**，
  与该文档写的 **13/13** 不符 ⇒ 顺线追查到底谁错。
- **定因（实测，非推断）**：`source-snapshot.test.mjs` 全历史用例数 = `0598e2d` **8** → `3bf3042` **8** →
  `f820bcd` **10** → 回退后 **8**（**峰值 10，从未到过 13**）。13 = **`source-snapshot`(8) + `external-summary`(5)**
  的**合计数**。错在把「两文件合计」写成「单文件」，并据此把那条「两侧一致支持」用例叫成「用例 13」
  （该文件**没有任何内部编号**，那条实为**第 8 条**）。
- **顺手复核 41/40 号单另外两个数字，均正确（不改）**：① `tests/source-snapshot.test.mjs` 包内 **9,471 字节** ✔
  —— 这是 **CRLF 尺寸**（git blob 是 **9,346**（LF）；本机 `core.autocrlf=true` ⇒ `git archive` 产物 = 9,346 + 125 个换行
  = **9,471**，实测 tar 成员 `size=9471 CRLF=125`）；② `+21 −5` ✔（`git diff --numstat 47bcbd7 4d0f83d`）。
- **修改文件**：`AGENTS.md` · `PROJECT_LOG.md` · `docs/handover/41-…md` · `docs/handover/40-…md`（**纯文档**）。
  **零代码 · 零依赖 · 零 DDL · 包内容不受影响**（`AGENTS.md`/`PROJECT_LOG.md` 本就在包内、且早已记在「包 vs HEAD
  差异 2 个文档」里；`docs/handover/` 是 `export-ignore`）。
- **教训（可复用）**：① **「两文件合计」「单文件」是两个口径**，写进文档必须带文件归属；②
  **「git blob 字节数(LF)」与「包内字节数(CRLF)」也是两个口径**（本机 `core.autocrlf=true`），核对执行单的字节判据
  必须用后者，否则会把正常的包误判成"打错了"。
### 2026-09-28 | feat：接入 zp.hyny168.cn / www.sdakzw.com 外站适配器 · 并回退一个会读坏既有站点的解析改动
- **用户指令**：「查看更改，完成另一个 AGENT 未完成的任务」（附上一轮对话记录）。
- **上一轮的结论是反的（本轮定因）**：上一轮认定这两站「服务端返回完整 HTML，只需补字段别名」——实抓推翻：
  `http://zp.hyny168.cn/ny?c=<码>` 只有 **12,107 B**（Vue 空壳 + 「正在加载系统资源，请耐心等待」），
  `http://www.sdakzw.com/nyzs/<码>` 只有 **1,661 B**（Vue3 + Element Plus 空壳 + `/frontassets/js/index-*.js`）。
  浏览器里「看得见内容」是因为**浏览器替它们执行了 JS 并调了接口**。⇒ 标签根本不在抓下来的 HTML 里，
  **补多少别名都不可能有用**，只能按它们自己调的接口接入。
- **真接口（照抄对方前端源码，不猜）**：hyny168 → `GET {页 origin}/prod-api/trace/{码}`（其 axios 实例
  `baseURL='/prod-api'`、`/ny` 页调 `getTrace2()`）；sdakzw → `GET http://api.sdakzw.com/api/nongYaoItem/zhuisu/{码}`
  （其 `/config.js` 的 `VITE_API_URL`）。字段名逐条抄自 hyny168 页面 chunk 的 `fieldMap` 与 sdakzw 结果页的渲染绑定。
- **顺手回退 `f820bcd`（`62561ef`）**：那次「通用 HTML 解析兜底」只在合成 HTML 上过了单测。本轮补做
  **`.4` vs `.5` 六个真实页面逐字段对照**，发现**两处读坏**：① `ddspp.cn` 的 `batchNo` 由「无」变成
  「见瓶盖或瓶体，袋装请见喷码」——把「生产日期及批号」的说明文字当成了**批次**，等于凭空声明一个批次；
  ② `nyzs315.com` 空壳页被读出 `productName="商标名称："`、`holderName="识别代码：/追溯网址：/农药类别："`
  这类标签残渣 ⇒ 空壳判据不再触发，消费者会看到**编造出来的字段**。逐层归因定位到 `extractConcatenatedFields`
  （`extractAttributeFields` 在样本页面零命中），**无一个站点因此多读到正确内容** ⇒ 整体回退，解析器版本回到 `2026-09-27.4`。
- **新增「第三态」**：适配器可返回 `{ notFound: true }`，`SourceIssue` 多一档 `source-not-found` ⇒ 对方明确答复
  「查无此码」时给正确文案，不再退回通用抓取撞空壳页、把对方的答复说成「页面要靠浏览器才能显示内容」
  （实测 `app/` 下零引用 `issue`、只显示 `message` ⇒ 本次改动**后端闭合**，不动前端）。
- **验收（4 组全绿）**：① `node --test tests/source-adapters.test.mjs` **6/6**；② `NZ315_LIVE_ADAPTERS=1`
  真接口 **9/9**；③ HTTP 全链路 `/api/trace?source=…`：hyny168 真码 → `resultType=external-reg` ·
  `status=ok` · **比对 18 项（16 match + 2 review）**，合规六项全取到、原药两组准确配对；
  sdakzw 未知码 → `issue=source-not-found` + 正确文案；④ 既有回归 **8/8 + 5/5 = 13/13**、`tsc --noEmit` 仅剩既有 `bill-input.ts(85,5)`。
- **代价（必须知情）**：每次调用都会在**对方系统写入一条扫码记录**（hyny168 实测带回 `scanNum`/`firstScanTime` 且
  对方写出了 `scanLogId`，不存在的码同样写）。与 nyzs315 同族，靠 10 分钟缓存 + 白名单缓解；
  删 `source-adapters/index.ts` 里一行登记即可整体下线。
- **遗留**：sdakzw 的 `result` 字段路径取自其前端源码，**尚未用该站真码回放**（手头没有 sdakzw 的真码）
  ⇒ 拿到真码后第一件事就是补端到端验收。
- **修改文件**：`server/utils/source-adapters/{hyny168,sdakzw,index}.ts` · `server/utils/source-snapshot.ts` ·
  `shared/types/source-snapshot.ts` · `tests/source-adapters.test.mjs` · `tests/_ts-loader.mjs` ·
  `tests/fixtures/{hyny168-trace.json,shell-hyny168.html,shell-sdakzw.html}` · `docs/handover/42-…md`。
  **零 DDL · 零依赖 · 零删除 · 零 `.env` · 零 nginx · 解析器版本号未变。**

### 2026-09-28 | fix(docs)：41 号执行单去掉「嵌套引号 + 半截粘贴」隐患（首次实战即踩中）
- **触发**：用户在服务器上照 41 号单跑 §0.4（外码 fix 前对照）时贴回的输出暴露了四个症状：`grep -c "亨达美田")` → `bash: syntax error near unexpected token ')'`；`Q: command not found`（连带若干条）；`$CNT0` 为空 ⇒ 打印成 `打之后快照表行数 = （期望 = + 1）`；最后一条命令引号没闭合，**提示符卡在 `>` 续行**。
- **定因（三条，全是「粘贴姿势」，不是环境故障）**：① **只粘了代码块的后半段** ⇒ §0.4 开头的 `while … export` + `M=` + `Q() {}` 三行没进去，`Q` 这个 **shell 函数**自然不存在（`Q()` 只活在当前终端窗口，换窗口 / 重连 / 关掉面板终端再开也会没）；② 原命令把 `grep -c` 的结果写在 `$(echo "$PAGE" | …)` 里、外面再套一层双引号 —— **语法合法，但被截断必炸**（`$(` 与 `)` 不配对 ⇒ 报 `unexpected token ')'`）；③ 引号未闭合 ⇒ bash 进续行模式，**此后粘的一切都被吞进那个没写完的字符串**（所以越粘越乱）。
- **修法（本轮只动 `docs/handover/41-…md`）**：① **§0.4 拆成 `0.4-A 先粘这一段`（定义 `$M` / `$DB_*` / `Q()`）与 `0.4-B 探测`**，并在 A 末尾加 `echo "M=[$M]  DB=[…]"` 自检行 —— 漏粘会**当场**表现为 `M=[]`，不必带着一堆 `command not found` 继续往下跑；② **把所有「嵌套引号」命令改成「先算成变量、再 echo」**（形如 `N_HENG=$(printf '%s' "$PAGE" | grep -c '亨达美田')`），涉及 §0.4② · §6.5②③ · §6.8①；③ §1 由「五件事」扩为「**六件事**」，新增第 6 条**粘贴纪律**（整段粘 · `Q()` 只在当前窗口 · 卡在 `>` 按 `Ctrl+C`）；④ §5' 速查表新增 **4 行**，把 `Q: command not found` / `unexpected token ')'` / 提示符卡 `>` / `--no-defaults`（原有一行、改口径）四个症状**连到「重粘 §0.4-A」这个动作**上。
- **★ 教训（值得复用）**：给「逐条粘贴」型执行单写命令，**判据不只是「命令对不对」，还要「被截断时会不会崩」**。⇒ 规则一：**不要在 `echo "…"` 里嵌 `$( … "$VAR" … )`**，要「标签 + 数字」就先**赋值给变量再 echo**（每行自包含，截断也最多少一行，不会把语法炸掉）。规则二：**任何依赖 shell 函数 / 变量的区块，都要在自己开头重复定义、并自带一行自检 echo**，让"前置条件没粘贴"这件事**立刻可见**，而不是拖到几屏之后才爆。
- **影响面**：**纯文档**。41 号单在 `docs/handover/` 下（`export-ignore`）⇒ **包内容一字未变**（`nz315-ycdb-4d0f83d.tar.gz` 750,651 B / SHA256 `d48f7990…6173` / 187 文件照用），**§0.4 之后的判据与期望值全部未改**（只是可粘贴性变好）。
- **修改文件**：`docs/handover/41-部署执行单-外码假空壳修复与记账下拉化（2026-09-28）.md` · `PROJECT_LOG.md` · `.workbuddy/memory/2026-09-28.md`。**零代码改动。**

### 2026-09-28 | deploy-prep：打「外码假空壳修复 + 记账表单下拉化」上线包（`4d0f83d` / 750,651 B）· 产出 41 号执行单
- **用户指令**：「打包准备上线，在给我上线流程前先把 memory 和 agent.md 里的过期文档清理了」（清理本身见上一条记录）。
- **先量指纹（本机记录一律不可信）**：`curl -s https://www.nz315.cn/_nuxt/builds/latest.json` → **`1790496675391` = 2026-09-27 16:11:15**，与上一轮实测量到的值**一致** ⇒ 线上自 16:11 起未再部署，38 号那批（`47bcbd7`）确实已上线 ⇒ 本轮范围定为 `git diff 47bcbd7..4d0f83d`。
- **★ 范围**：**11 个提交 / 17 文件 / +2,442 −891**；**运行时代码 5 个（全修改，+193 −54）** = `app/components/BillFormModal.vue`（+122 −36）· `server/utils/source-parser.ts`（+42 −12）· `server/utils/source-snapshot.ts`（+4 −1）· `shared/types/source-snapshot.ts`（+4 −0）· `tests/source-snapshot.test.mjs`（+21 −5）。**零新增文件 · 零删除文件 · 零依赖变化 · 零构建配置变化。**
- **★ 包自验（四组判据全绿）**：**`nz315-ycdb-4d0f83d.tar.gz`**（落 `E:\software\workbuddy\文件存放处\2026-09-28-1450-ycdb-外码假空壳修复与记账下拉化上线包\`）= **750,651 字节 / SHA256 `d48f79906fd6fae3b6be777d270696b539b254b00f77f5f2f92ab91d53226173` / 包内 187 文件**（tar 条目 248 = 文件 187 + 目录 60 + `pax_global_header` 1）。
  - **清单双向核对**：`git -c core.quotePath=false ls-tree -r --name-only 4d0f83d` = **232** − `export-ignore` **45** = **187 == 包内实际 187**；**只在包里 0 / 只在仓库 0**；
  - **禁入项扫描**：`.env*`（白名单仅 `.env.example`）/ `node_modules/` / `.output` / `.nuxt/` / `.git/` / `*.exe` / `public/tools/` —— **命中 0 条**；
  - **逐文件内容比对**：**先 `\r\n → \n` 归一**再与 `git cat-file blob` 比 SHA256 ⇒ **不一致 0 个**（其中 **182** 个只差 CRLF，属 Windows 打包机的必然现象，无害）；
  - **`deploy/*.sh|conf|cjs` 全 LF** ✅；`public/tools/*.exe` 本来就没被 git 跟踪 ⇒ 天然不进包；
  - **零 DDL 硬证据**：`scripts/db-init.mjs` 包内 **35,933 字节**、与基线 `47bcbd7` **归一后逐字节一致**；`package.json` / `package-lock.json` / `nuxt.config.ts` / `.gitattributes` **相对基线全部未变**。
- **★ 40 号整包被本单吸收**：40 号那轮（`47bcbd7 → bf6ae7e`）只有外码解析器修复、**一直没部署**；本轮的包是它的**超集**。⇒ **40 号的包 `nz315-ycdb-bf6ae7e.tar.gz`（742,679 B）作废**，已把它连同所在目录移入 `文件存放处/_作废包-勿传（已过期）/`，防手滑传错版本；40 号**正文仍有效**（「假空壳」定因写得最细），但**上线照 41 号跑**。
- **★ 41 号执行单**（新增 `docs/handover/41-部署执行单-外码假空壳修复与记账下拉化（2026-09-28）.md`）相对 40 号的**结构性变化**：① **主验收从两条扩到五条** —— 新增「**客户端产物级**：`按关键词自动归入` ≥1」这条，因为记账弹窗是 `UModal` **懒渲染**，`curl` 抓不到弹窗 DOM，只能判「新组件进了客户端 bundle」+ 真浏览器人工点数；② 新增 **§6.7 真浏览器人工确认清单（7 条）**，把「恰好 4 个下拉 / 平铺芯片一个不剩 / 切「自定义…」光标自动落进输入框」变成可点可数的判据；③ §0.3 反查扩为**两批**（服务端旧版本号 `2026-09-24.3` 应为 1；前端 `PRESET_CUSTOM` 与 `<select` 行数应分别为 0 与 1）；④ §2 清理清单**加删 40 号那个包**；⑤ `.deploy-version` 的新 `code_base`（`47bcbd7 → 4d0f83d`）与 `note` 同时覆盖两件事。
- **★ 顺手记下的两条「判据口径」教训（已写进执行单）**：① `UModal` 这类**懒渲染**弹窗的内容**不在 SSR 产物里** ⇒ 断言它的文案会得 `0`，**那不是功能缺失**，必须改判据为「客户端 bundle 指纹 + 真浏览器点开再断言」；② `__custom__` 这个哨兵值**旧版也有**（旧代码把哨兵写成字面量、共 5 处）⇒ 它只能当**旁证**；`按关键词自动归入` 才是**本轮专属**指纹（旧版 0 次）。⇒ **判据必须选「只在改动后才出现」的串**，否则会把"没生效"判成"生效"。
- **✅ 已推送**：`git push origin ycdb` 成功（`aca8b14..4f9409e`，**3 个提交**）。🔴 照例**不信退出码**：`git ls-remote origin refs/heads/ycdb` = `4f9409e` == 本地 HEAD；本机 `refs/remotes/origin/ycdb` 又没落盘，已 node 直写 loose ref 修好（`rev-list --left-right --count` = `0	0`）。判据永远以 `ls-remote` 为准、**不写死 SHA**。
- **📌 上线决定的过程（记录一笔，免得日后对不上）**：用户先下「**取消上线，要增加新功能**」（据此把包与执行单在当日日志里标了「暂缓 / 勿传」），**十几分钟后改口「算了，先上线当前版本吧」** ⇒ **41 号那批恢复上线，包与执行单原样可用、判据未改**。⚠️ 当时**没有**去改 `AGENTS.md` 的 41 号定位与 `PROJECT_LOG.md` 的上线结论（只写在 append-only 的当日日志里）⇒ 这次撤销**零返工**。**教训：上线开关类的用户决定，先只写当日日志，等确定后再动长期文档。**
- **修改文件**：**新增** 41 号执行单；**修改** `AGENTS.md`（把 40 号标为**已作废 + 包别再传**）· `PROJECT_LOG.md` · `.workbuddy/memory/2026-09-28.md`。**本轮零代码改动**（0 个 `.ts`/`.vue`/`.mjs` 被改）。

### 2026-09-28 | docs：清理过期状态块（AGENTS.md 四块合一）+ memory 日志压缩归档
- **用户指令**：「打包准备上线，在给我上线流程前先把 memory 和 agent.md 里的过期文档清理了」。
- **AGENTS.md（91,803 → 88,180 字符 / 167,311 → 160,541 字节，CRLF 保持）**：把 **4 个互相打架的时间块**（09-23 记账上线块 / 09-24 线 B 块 / 09-27 17:3x 38 号块 / 09-28 记账表单块）**合并为一个「【2026-09-28 现状块】」**置于文首，并把「接手顺序」行前置 **41 号**。合并的动因是**自相矛盾**：同一件事在不同块里同时标着「已上线」和「未上线」——例如 36 号「档 3 nyzs315 适配器」在 09-24 块写「未上线」、在 09-27 块写「已上线」；39 号解析器修复也是「已备包待放行」与「本轮未上线」并存。⇒ 现状块以**公网构建指纹**为唯一版本判据，把「未上线 / 未推送 / 待放行」的过时表述一次性收编；原文细节不删，指向 `PROJECT_LOG.md` 与 `docs/handover/`。
- **memory（`.workbuddy/memory/`）**：把三份过期日志（`2026-09-23.md` / `2026-09-24.md` / `2026-09-27.md`，合计约 65K 字符）**压缩要点为 `ARCHIVE-2026-09-23_09-27.md` 后删除原文**（原文另备份在 `C:/shots/_deleted-2026-09-2[3|4|7].md`）。归档只保留**仍有跨会话价值**的部分：三批（线 A / 线 B / 38 号）的最终归属与指纹链、仍有效的硬知识（外码构造公式 · nginx `proxy_pass` 指 cynx 3000 的警告 · `regdata.ts` 隐式耦合 · 权限 5 守卫 · 记账 2 口径 · N1 豁免 · C7/E4 已知缺陷）、做过又被撤销的事（扫码页折叠 · diff 备份位置）、以及**已过期的回归断言点**。`MEMORY.md` 同步加一节「📜 历史批次要点」指向归档；顺手把 `MEMORY.md` 的**混行（74 CRLF + 15 裸 LF）归一为纯 CRLF**。
- **为什么值得做**：交接文档里出现**互相矛盾的版本状态**，是比「没有文档」更贵的债 —— 接手者会照旧块里的「未上线」重复上线，或照「已上线」跳过验证。本轮把版本判据**唯一化**（只信 `curl -s https://www.nz315.cn/_nuxt/builds/latest.json` 的 `timestamp`）。
- **影响面**：**纯文档 / 纯记忆 —— 零代码、零依赖、零 `.env`、零 nginx**。`AGENTS.md` 与 `PROJECT_LOG.md` **会进上线包**（未加 `export-ignore`，属 40 号 §6' 的待裁定老问题）；`.workbuddy/memory/` 已被 `export-ignore` 剔出 ⇒ **归档动作不影响包内容**。
- **本轮上线范围（预告）**：`git diff --name-status 47bcbd7..d0c5c3b` = **10 提交 / 14 文件**，其中**运行时代码 5 个**（`app/components/BillFormModal.vue` · `server/utils/source-parser.ts` · `server/utils/source-snapshot.ts` · `shared/types/source-snapshot.ts` · `tests/source-snapshot.test.mjs`），其余 9 个是文档；**零 DDL**（`scripts/db-init.mjs` 逐字节未变）· **零依赖** · **零删除** · **零 nginx**。上线执行单 = **41 号**（打包指纹见下一条记录）。
- **修改文件**：`AGENTS.md` · `PROJECT_LOG.md` · `.workbuddy/memory/MEMORY.md` · **新增** `.workbuddy/memory/ARCHIVE-2026-09-23_09-27.md` · **删除** `.workbuddy/memory/2026-09-23.md` / `2026-09-24.md` / `2026-09-27.md`。

### 2026-09-28 | feat：记账表单「补充信息」选项全部收进下拉框（+ 修「自定义输入看不见」）
- **用户指令**：「我要把这个页面的选项全部做成箭头下拉框选择，而不是直接写在页面上供选择，还有购买渠道的自定义，选择后并不能自己输入」。
- **改动（单文件 `app/components/BillFormModal.vue`，+122 −36）**：
  - 原先平铺在页面上的快捷芯片 —— 单位 7 个、用途 6 个、作物 6 个 —— **全部删掉，收进带箭头的下拉框**（原生 `<select>`，与原来的购买渠道下拉同款：自带箭头、手机上唤起系统选择器）。
  - 四个「可预设 + 可自由输入」字段（单位 / 购买渠道 / 用途 / 作物）**统一成同一套交互**：`picker[key] = { preset, custom }` 两半状态 + `PRESET_CUSTOM` 哨兵；下拉选「自定义…」→ 该字段下方出现输入框。抽出 `fillPicker()`（已存值 → 下拉选中项/自定义输入两半）与 `pickValue()`（提交时取值），**四个字段共用**，杜绝各写一套。
  - 🔴 **`fillPicker()` 是编辑态的数据安全线**：老账里 `unit='毫升'`（不在预设清单内）若不回填，用户一进编辑就看到空下拉，一保存就把原值抹成空（PATCH 语义下 `unit` 出现过即被覆盖）⇒ 非预设值一律落回「自定义…」+ 输入框原样回填。
  - 新增 `onPresetChange()`：下拉切到「自定义…」时 `nextTick` 后把焦点送进刚出现的输入框（只在**用户手动切换**时触发，回填老账不打扰，否则一开弹窗页面就被滚走）。
  - **用户裁定**：单位/作物**保留自由输入**（下拉 + 自定义）；用途**也允许手输**。用途手输后服务端仍按 `normalizeBillCategory()` 关键词归入六类、无法归类的落「其他」，故在用途的自定义输入框下写明这行提示。
- **★ 用户报的「购买渠道选了自定义却不能输入」—— 对照实验证伪了「代码 bug」**：把 `BillFormModal.vue` 临时还原到 HEAD 版本（`git show HEAD:app/components/BillFormModal.vue` 写回工作区，新版备份在 `C:/shots/_BillFormModal.new.vue`），用 CDP **真鼠标点击 + 真键盘输入**复测旧代码 ⇒ 输入框**能出现 / 能聚焦 / `customChannel` 拿到 `'乡镇代购点'`**，逻辑本身是通的。⇒ 真因是那个输入框只是静默出现在下拉下方、落在弹窗滚动区里不显眼处，用户以为没得填；**对症修复 = 自动聚焦**（手机顺势滚入视口并弹键盘）。
- **验证（真浏览器 CDP，非合成事件）**：4 个下拉就位、**平铺芯片 0 个**；逐个切「自定义…」→ 焦点自动进入对应输入框 **4/4 通过**；真鼠标点击渠道输入框 → `document.activeElement` 命中 → `Input.insertText` 真键盘输入 → `input.value` 与组件 `setupState.picker.channel.custom` **均为「乡镇代购点」**（证明 v-model 真的把值写进了会被提交的状态）；预设项回显正常。截图 `C:/shots/bill-form-1-collapsed.png` · `-2-custom-filled.png` · `-3-preset.png`。
- **影响面**：**零 DDL / 零新依赖 / 零接口改动 / 零 `.env`**（服务端 `bill-input.ts`、`shared/utils/bill-category.ts` 一字未动，仅新增对 `BILL_LIMITS` 的引用）。
- **修改文件**：`app/components/BillFormModal.vue` · `PROJECT_LOG.md` · `AGENTS.md` · `.workbuddy/memory/*`。临时验证页 `app/pages/devcheck/bill-form.vue` 与本机验证脚本只在本机存在过，**验证完即删，未入库**。
- **上线状态**：**未打包、未推送、未部署**；线上现役指纹仍应为 `1790496675391`（下轮上线前先现量）。
- **给下一个 Agent 的提示**：遇到「点了没反应 / 某个控件用不了」类反馈，**先做「回退版本对照复跑」再下结论** —— 本轮据此避免了一次方向完全错误的排查（原本会去找并不存在的 v-model / 组件 bug）。

### 2026-09-28 | chore：推送 `ycdb` 到远端（+ 修本机跟踪引用不落盘的老毛病）
- **用户指令**：「先PUSH到远程GIT」。
- **结果**：`git push origin ycdb` 成功 —— 第一次回显 `6afeee6..a74ae7c  ycdb -> ycdb`，`git ls-remote` 复核远端 = `a74ae7c`；随后**把「本次推送」这件事记录下来的那个提交 `5e2229a` 也已一并推送**。🔴 **最终判据一律以 `git ls-remote origin refs/heads/ycdb` == 本地 HEAD 为准，不写死终端 SHA**（否则「记录推送」这个动作本身就又把 SHA 推进一格，永远差一个）。本轮共推 **15 个提交**（`git rev-list --count 6afeee6..a74ae7c` = 15，从线 B 之后的 `74c9dd7` 一路到 `a74ae7c`）。
  ⚠️ 顺带说明：这 15 个里**含 38 号那批已上线的代码**（`cd25c88` / `62c4333` / `9ac658e` / `a2d3011` / `b740b3d` / `8739b98` 等）—— 它们此前**只在本机**、只通过 tar 包上的线，**这次才真正进远端仓库**。
- **🔴 顺手修掉本机那个老毛病（它又犯了）**：push 回显成功、`ls-remote` 也看到远端新值，**但本地 `refs/remotes/origin/ycdb` 没写盘** ⇒ `git rev-parse origin/ycdb` 报 `fatal: ambiguous argument 'origin/ycdb': unknown revision`，`git branch -vv` 会显示 `[origin/ycdb: gone]` —— **看着像推送失败，其实远端早就收到了**（此时若重推或回滚，纯属自己吓自己）。
  修法（已验证）：**node 直写 loose ref** —— `fs.writeFileSync('.git/refs/remotes/origin/ycdb', sha + '\n')`（本机 `git update-ref` 同样**静默失败**，退出码 0 但不落盘）。修后：`git rev-parse origin/ycdb` = `a74ae7c`、`git rev-list --left-right --count origin/ycdb...HEAD` = **`0	0`**、`git branch -vv` 显示 `* ycdb a74ae7c [origin/ycdb]`。
- **★ 更正了三处「未推送」的当前状态表述**（🔴 历史条目里的「未推送」是**当时的真实状态，一律不改**）：`AGENTS.md` 的「上线包已备」块 → 改为「已推送 / 仍未部署」；**40 号执行单**的「本次代码基线」行 → 改为「已于 2026-09-28 推送到 `origin/ycdb`，远端与本地同步」；`docs/handover/README.md` **两处**（按顺序读表 + 文件清单）同步；**39 号** §8 那条加「2026-09-28 更正」注。
- **📌 推送与本轮上线包的关系（说清，避免误判"包过期"）**：推送让 HEAD 从 `bf6ae7e` 前进到 `a74ae7c`，多出的 **2 个提交都是纯文档**（`18711a1` = 40 号执行单与文档同步；`a74ae7c` = 40 号包基线说明修正），**其余 13 个提交在打包前就已存在**。⇒ 已逐文件比对证明「**包 vs 新 HEAD**」的差异只有 `AGENTS.md` 与 `PROJECT_LOG.md` 两份文档、**运行时代码/配置差异 0**（脚本 `_pkg-vs-head.mjs`）⇒ **包 `nz315-ycdb-bf6ae7e.tar.gz` 不必重打，40 号执行单照用。**
- **修改文件**：`AGENTS.md` · `PROJECT_LOG.md` · `docs/handover/40-部署执行单-外码假空壳解析器修复（2026-09-27）.md` · `docs/handover/39-外码来源页假空壳定因与解析器修复（2026-09-27）.md` · `docs/handover/README.md` · `.workbuddy/memory/2026-09-28.md`（当日日志，含另一会话的 PPT 交付记录，一并入库）· `.workbuddy/memory/MEMORY.md`。**零代码改动 / 零依赖 / 零 `.env` / 未接触服务器。**
- **遗留提醒**：① **仍未部署** —— 照 **40 号**跑（38 号不适用）；② 仓库根出现**新的未跟踪产物**：`ppt-output/`（内含 1 个 `.pptx`）、`.ppt-build-20260928/`、`.slidep/`，另有老面孔 `scripts/generate-user-guide.mjs` 与 `docs/厂家后台使用说明/` ⇒ **建议给前三个加 `.gitignore`**，否则日后一次 `git add -A` 就会把 64 KB 的 pptx 与构建临时目录夹进代码仓库（**本轮未动，属独立主题**）。
- **给下一个 Agent 的提示**：**别信 `git push` 的退出码，也别信本地 `origin/<分支>` 引用** —— 判推送是否成功**只看 `git ls-remote origin refs/heads/<分支>`**；本机这条跟踪引用要手动用 node 直写 loose ref 补。
- **测试情况**：`git ls-remote` 复核远端值 == 本地 HEAD；`rev-list --left-right --count` = `0	0`。本轮**零代码改动**，无需跑测试。
### 2026-09-27 | deploy-prep：打「外码假空壳解析器修复」上线包（`bf6ae7e` / 742,679 B）· 产出 40 号执行单
- **结果一句话**：用户下了一句「**准备上线该版本**」⇒ 按既定流程做了四件事：① **现量公网指纹**；② 用 `git archive` 打上线包并**逐文件自验**；③ 本机 `nuxt build` + **产物级反查**；④ 产出 **`docs/handover/40-部署执行单-外码假空壳解析器修复（2026-09-27）.md`**。⚠️ **只做「准备」——未部署、未动服务器、未推送、未动线上数据库。**
- **🔴 先量指纹（本机记录一律不可信）**：`curl -s https://www.nz315.cn/_nuxt/builds/latest.json` → **`1790496675391` = 2026-09-27 16:11:15**。与上一轮实测量到的值**一致** ⇒ 线上**自 16:11 起未再部署**，38 号那批（`47bcbd7`）**确实已上线**。⇒ 本轮范围定为 `git diff 47bcbd7..bf6ae7e`。
- **★ 本轮范围极小且干净**：`git diff --stat 47bcbd7..bf6ae7e` = **10 文件 / +1,330 −61**，其中**运行时代码只有 4 个、全是修改**（`server/utils/source-parser.ts` · `server/utils/source-snapshot.ts` · `shared/types/source-snapshot.ts` · `tests/source-snapshot.test.mjs`）+ 根级文档（`AGENTS.md`/`PROJECT_LOG.md`，**会进包**）+ 内部手册与记忆（`docs/handover/`、`.workbuddy/`，`export-ignore` 剔出）。**零新增文件 · 零删除文件 · 零依赖变化 · 零构建配置变化。**
- **★ 包自验（四组判据全绿）**：**`nz315-ycdb-bf6ae7e.tar.gz`**（落 `E:\software\workbuddy\文件存放处\2026-09-27-1755-ycdb-外码假空壳修复上线包\`）= **742,679 字节 / SHA256 `b2029918f806541e51c8eb1cf47b92d688670d20e1b552b63d2226c940bbebac` / 包内 187 文件**（tar 条目 248 = 文件 187 + 目录 60 + `pax_global_header` 1）。
  - **清单双向核对**：`git -c core.quotePath=false ls-tree -r --name-only bf6ae7e` = **232** − `export-ignore` **45** = **187 == 包内实际 187**；**只在包里 0 / 只在仓库 0 / 应剔除却在包里 0**；
  - **禁入项扫描**：`.env*`（白名单仅 `.env.example`）/ `node_modules/` / `.output/` / `.nuxt/` / `.git/` / `*.exe` / `.output.bak` —— **命中 0 条**；
  - **逐文件内容比对**：**先 `\r\n → \n` 归一**再与 `git cat-file blob` 比 SHA256 ⇒ **不一致 0 个**；
  - **`deploy/*.sh|conf|cjs` 全 LF** ✅；`public/tools/*.exe` **本来就没被 git 跟踪**（`ls-files public/` 只有 3 个文件）⇒ 天然不进包。
- **★★ 包对包比对（比 SHA256 正确得多的判据，也是"包确实只变了这 4 个"的硬证据）**：拿**已上线那版** `nz315-ycdb-47bcbd7.tar.gz` 与本次新包逐文件比 —— **只在旧包 0 / 只在新包 0 / 内容不同 6**；其中 **4 个是运行时代码**、**2 个是 `AGENTS.md` 与 `PROJECT_LOG.md`**。⇒ **运行时差异恰好就是本轮那 4 个文件，包里没有夹带任何别的东西**。
  - 顺手复核：**旧包的 SHA256 = `c6dc1b0e0359d19b3aee4d2482a7851da266b7832a024f70a288eb84c875e55a`**，与 38 号执行单里写死的值**逐字符一致** ⇒ 确认那包就是 38 号那版、且**它就是已上线的包**（旁证线上 = `47bcbd7`）。
- **★ 产物级反查（skill 明令：构建退出码 0 ≠ 代码进了产物）**：
  - 本机 `npm run build` 走不通（本机 shim 里 `/usr/bin/env: bash: No such file or directory`）⇒ 绕开 npm 脚本，直接 **`node node_modules/nuxt/bin/nuxt.mjs build`**，**exit 0、1 分 11 秒、`✨ Build complete!`**；
  - 扫描 `.output` 全部 **559** 个 `*.mjs|*.js|*.json`：**正向** `2026-09-27.4` ✔（落在 `server/chunks/_/source-parser.mjs`）、`品种名称` ✔（同文件）、`commodityName` ✔（`server/chunks/routes/api/trace.get.mjs` + `source-parser.mjs`）；**反向** 旧版本串 `2026-09-24.3`、`2026-09-27.3` **各 0 命中**。⇒ **代码确实进了产物**。
- **★ 40 号执行单相对 38 号的结构性变化（都是本轮特有）**：① **第 4 步从"必须做"降级为"可选"** —— 本轮零 DDL，`db-init.mjs` 逐字节未变（**包内 `35,933` 字节**），判据从"必须出现那条迁移行"**反转为"不应出现任何 `[db] 迁移：` 行 + 表数仍 17"**；② **新增「同一外码 fix 前后对照」这条主验收**（§0.4 先记 `status≠ok`+`empty-shell`，§6.4 再打同一个码应得 `status=ok`+页面出「亨达美田」+ 失败文案消失；同一码同一址、前后只差我们的代码 ⇒ 归因干净），并配 §6.5 按 id 清掉那 2 行测试快照；③ **新增「产物级 grep」主验收**（`2026-09-27.4` ≥1 / `2026-09-24.3` = 0 / `commodityName` ≥1）；④ **§0.3 反查对象改为"新代码现在还不在这台机器上"**（旧版本号应为 1、`commodityName` 应为 0）；⑤ **回滚节明确「反向清单为空」**（本轮 0 新增 ⇒ `tar` 恢复不会留残留，与 38 号那轮必须写 `rm` 清单**正好相反**）；⑥ 首次写入 `.deploy-version` 的新 `code_base`（`47bcbd7 → bf6ae7e`）与 `note`。
- **★ 顺手修掉执行单里的两处"会炸的文本"（自查抓到）**：① 一处 `echo "…这是"新代码真的到了"的…"` **在双引号里嵌了未转义双引号**（bash 会提前闭合引号）⇒ 改为不带内层引号的写法；② `.deploy-version` 的 `note` 里 `副作 用=` 有个**误插的空格** ⇒ 修正为 `副作用=`。
- **修改文件**：**新增** `docs/handover/40-部署执行单-外码假空壳解析器修复（2026-09-27）.md`；**修改** `AGENTS.md`（接手顺序插入 40 号 + 17:3x 状态块追加「上线包已备」行）· `PROJECT_LOG.md`。**本轮无代码改动**（0 个 `.ts`/`.vue`/`.mjs` 被改）⇒ 上线包内容 = `bf6ae7e` 的 `git archive`，**与工作区一致**。
- **遗留问题/待办**：① **等用户放行部署**（照 40 号跑；38 号不适用）；② `ycdb` 本地领先 `origin/ycdb` **13 个提交**、**未推送**；③ 🔴 `external_source_snapshot` **存储放大**修复仍挂在待办（本轮版本号升版会让旧快照缓存一次性失效、之后重新抓取，短期会**加剧**表增长）——**建议下一轮优先**；④ 39 号 §8 那三项（同族盲区其它标签 / `productName` 别名表仍含「商品名称」/「只在用户点原页时才查」）**未做**。
- **给下一个 Agent 的提示**：① **判「线上是哪个版本」只信公网指纹**（本轮再次验证了这一点）；② **判「包是否过期」只能逐文件比内容**（本轮实测：同内容不同提交的包 SHA256 必然不同，而**包对包比对**才能证明"只变了 4 个文件"）；③ **本机 `npm run build` 会被 shim 挡**（`/usr/bin/env: bash` 找不到）⇒ 用 `node node_modules/nuxt/bin/nuxt.mjs build`。
- **测试情况**：包自验 4 组判据全绿 · 包对包比对运行时差异恰为 4 个文件 · 本机 `nuxt build` exit 0 · `.output` 正向 3 项命中 / 反向 2 项 0 命中。**零代码改动 / 零依赖 / 零 `.env` / 零 nginx / 未接触服务器 / 未推送。**
### 2026-09-27 | fix：外码来源页「假空壳」定因并修复解析器盲区（`3bf3042`，未上线）
- **现象**：`cx.jilinhengda.com/q.do?i=<32位码>` 在公众端固定显示「这个来源页面要靠浏览器才能显示内容，本平台读不到里面的资料」（`issue=empty-shell`），与 36 号记的「JS 壳页面」症状一模一样。
- **定因（推翻"要靠浏览器"的直觉）**：该站返回 **200 / 17,424 B 服务端渲染完整页**、字段齐全、5 种 UA 结果逐字节同一份（无 JS、无 JSON 接口、无 UA 依赖）⇒ **不是抓取问题，是我们自己的解析器盲区**。`sourceText()` 把 `</td>` 转 Tab、`</div>` 转换行；该页「td 里再包 div」⇒「品种名称：」与「亨达美田」被拆到**两行、各剩一格**；而含标签路径**只按 Tab 切 + 只认同行「标签：值」** ⇒ `pairs` 为空 ⇒ 三空判据抛错。（⇒ 用户原先设想的接接口 / 无头浏览器 / 截图 OCR / 接 Agent 四种解法**都不是正解**。）
- **修复（4 文件）**：① `source-parser.ts` 兜底③「标签一行、值一行」从 `plain` 专用**放开到全路径**，且下一行**只取首个 Tab 单元格**（防整行吞值），新增 `EXTRA_KNOWN_LABELS`（单元识别码 + 原药六项）并入白名单；② 新增 `commodityName`（品种名称/品种名）**单独一档**，**绝不并进 `productName` 别名表**——这类站写的「品种名称」是**商品名**（本站写「亨达美田」，登记证 `PD20241818` 的农药名称是「丙硫菌唑·戊唑醇」），并进去会**误报「与登记资料不一致」**（用户裁定 = **选项 A：只作展示字段，不参与强比对**）；③ `source-snapshot.ts` 三空判据纳入 `commodityName`；④ `shared/types/source-snapshot.ts` 加可选 `commodityName`。`SOURCE_PARSER_VERSION` `.3` → **`2026-09-27.4`**（缓存键含版本号 ⇒ 旧快照自然失效，无须清表）。
- **验证**：**逐字段对拍硬证据** —— 同一份 HTML 改前/改后喂项目解析器，`ddspp` / `nyzs315` / `mashangzhuisu` **逐字节一致**（零回归），仅 `cx.jilinhengda` 新增 9 字段、`throwLike` true→false。端到端 `GET /api/trace?source=http://cx.jilinhengda.com/q.do?i=…` 返 `resultType=external-reg`、`sourceSnapshot.status=ok`、**mismatch 0 项**、登记候选 `PD20241818 / 丙硫菌唑·戊唑醇` 正确。Edge + CDP 真浏览器：页面渲染「商品名称 亨达美田 / 登记证持有人 吉林八达 / 生产企业 吉林八达」，比对「一致 1 项 · 存在差异 0 项」，旧技术文案已消失。单测 `tests/source-snapshot.test.mjs` **8/8**（**与 `tests/external-summary.test.mjs` 的 5 例合并计 13/13**；其中**最后一条**用例原把「HTML 不认分行」当契约固定 ⇒ 按用户裁定改为「两侧一致支持」）；`tsc --noEmit` 仅既有 `bill-input.ts(85,5)`。M7 回归 19/22，3 FAIL（`wla1` 真实 403 / 通用 HTML 抓取）**已用 `git stash` 回退 4 文件复跑证实与本改动无关**（同 3 FAIL，假预警 id 24→25）；M7 写入已按基线清理。
- **对 36 号 §4.1 判据的修订**：原判据「抓下来去标签后还有没有值」**不足以**判该不该做适配器 ⇒ 细化为「**标签与值是否落在同一个 Tab 分隔的单元格内**」。同一盲区若再遇到，**一律先修通用解析器，不要按平台铺开写适配器**（对外站计数污染最小）。
- **修改文件**：`server/utils/source-parser.ts` · `server/utils/source-snapshot.ts` · `shared/types/source-snapshot.ts` · `tests/source-snapshot.test.mjs`（提交 **`3bf3042`**）；**新增** `docs/handover/39-外码来源页假空壳定因与解析器修复（2026-09-27）.md`；**修改** `AGENTS.md` · `PROJECT_LOG.md` · `.workbuddy/memory/*` · `logs/_m7-regression.mjs`（HOST 改 `process.env.M7_HOST || 'localhost'`，本机脚本未单独提交）。**零 DDL / 零新依赖 / 零 `.env` / 零 nginx**。
- **上线状态**：**仅本机实施验证，未推送、未部署**；公网构建指纹仍为 `1790496675391`。上线**零 DDL**，但**须在服务器 `npm run build` 后仅 `pm2 reload nz315`**，不得上传本机构建产物。
- **本机环境**：`hosts` 映射块新增 `39.105.91.144 cx.jilinhengda.com`（备份 `logs/hosts.bak-2026-09-27T09-23-06-619Z.txt`），仓库外改动不入库。

### 2026-09-27 | feat：外码取材打通——空壳站适配器（nyzs315）+ 失败原因分人话文案 + 本机抓取环境修复
- **用户指令**：「先做 2 3，然后把文案改为消费者能看得懂的人话。」（② 本机代理直连/打通、③ 空壳站适配器、文案 = 消费者人话）
- **② 本机抓取打通（仓库外，属开发环境修复）**：本机 DNS 被代理接管成 fake-ip（外站域名全 → `198.18.x`/`198.19.x`），而 `source-fetch.ts` 的 SSRF 黑名单恰好含 `198.18.0.0/15` ⇒ 本机抓任何外站 100% 报「来源网址不是可访问的公网地址」。用 DoH 取真实公网 IP 后写 `hosts` 映射（`mashangzhuisu.com` / `ddspp.cn` / `nyzs315.com` / `www.wla1.cn`），夹在 `# === nz315-dev-source-fetch BEGIN/END ===` 之间，备份 `logs/hosts.bak-2026-09-27T07-02-02-398Z.txt`。⇒ **本机首次能真实验收外码抓取**（此前只能拿 ddspp fixture 造快照，会把「假数据」当成功能可用）。
- **③ 档 3 适配器（`server/utils/source-adapters/`）**：新增 `nyzs315.ts` + `index.ts` 宿主白名单注册表；`source-fetch.ts` 新增**可选固定请求头**（向后兼容，不传时逐字节同旧）；`source-snapshot.ts` 改为「**适配器先行**、未登记宿主走原路径」。接口/参数/请求头全部照抄原页脚本：`GET /api/h5/Code/QueryCodeJson`，**`X-Tenant-ID: <m>` 必需**（缺了返「该码未找到相关信息!」），`firstFullAddress` 必须三级。**降级链**：适配器失败 → 通用抓取 + 解析 → 仍失败仍有原页链接。
- **配套 §5.3.5（档 3 真正的工作量）**：外站接口**不返回登记证号** ⇒ 不补这一步，适配进来后所有比对项会因「参考值取不到」恒为 `insufficient`。新增 `referenceProductFor()`：来源页未声明证号且该声明来自适配器时，用码内「后六位 + 类别」走**共用原语** `findRegistryRowsByUnitCode` 取登记参考。**两条边界**：① 只在**唯一候选**时才当参考（后六位撞车可能跨 PD/WP 类，多候选无法确定是哪张证 ⇒ 宁可全 `insufficient` 也不误报「存在差异」）；② **不扩展到**通用解析出来的「有名称没证号」页面（那类页面的名称常是商品名/商标，拿登记库农药名称去比容易误报）。
- **文案（人话化）**：`source-snapshot.ts` 新增 `ISSUES` 映射（错误原文 → `issue` 分类 + 消费者文案），**技术原文只进 `detail`**（后台排查用，消费者看不见）；`SourceSnapshot` 新增可选 `issue`/`detail`；`external-summary.ts` 新增 `ISSUE_HINTS` 按 `issue` 给中性兜底文案，标题改「暂未取得来源页资料」；`TraceSourceSnapshot.vue` 两处文案改口语化。**核心是把「打不开」与「打开了但读不出内容」彻底分开**，不再出现「平台适配 / 由脚本加载」这类术语。
- **实测（本机 dev + 真浏览器）**：`nyzs315.com` 从「未提取到产品信息」变为 **`status=ok` + 11 项比对（4 一致 / 5 资料不足 / 2 待核实）**，取出「联菊·啶虫脒 / 青岛正道药业有限公司 / 山东哈维斯生化科技有限公司」；`ddspp.cn`（未登记宿主）**18 项比对、15 一致，与改动前逐字一致**（零回归）；`mashangzhuisu.com`（空壳但未适配）正确落到「读不出内容」文案且保留原页链接。回归：`source-snapshot` **8/8**、`external-summary` **5/5**、`tsc --noEmit` 仅既有 `bill-input.ts(85,5)`。Edge + CDP 真浏览器：截图正常，文案断言 `hasLink/hasCount11/hasSuccessTitle` 均 true、**技术原文不出现在页面上**。
- **🔴 付掉的账（36 号 §5.3.4 三笔账之二；用户已通过「先做 2 3」放行）**：本轮为钉死接口形状与端到端验证，对 nyzs315 共发起 **2 次成功调用**，该码 `queryCount` 13 → 14。**外站页面「第 N 次查询该产品」的计数会被我们的查询计入** ⇒ 若担心污染对方统计，删掉 `source-adapters/index.ts` 里的一行登记即可整体下线；更小污染的口径是「只在用户点『查看原查询页』时才查」（**未做**）。
- **修改文件**：**新增** `server/utils/source-adapters/nyzs315.ts` · `server/utils/source-adapters/index.ts`；**修改** `server/utils/source-snapshot.ts` · `server/utils/source-fetch.ts` · `shared/types/source-snapshot.ts` · `shared/utils/external-summary.ts` · `app/components/TraceSourceSnapshot.vue`。**零 DDL / 零新依赖 / 零 `.env` / 零 nginx**（`hosts` 改动在仓库外，不入库）。
- **上线状态**：**仅本机实施验证，未推送、未部署**；公网指纹仍为 `1790236396250`。⚠️ 适配器只对 `nyzs315.com` 生效，其余平台走原路径、行为不变。
### 2026-09-27 | feat：记账表单精简与扫码信息预填
- **用户目标**：让记账表单更容易填写；总金额优先、扫码带入产品名称/剂型/生产日期，原“类别”改为次要“用途”，购买渠道改为常用选项加自定义，并提供作物快捷选项。
- **界面**：总金额置于表单首位并使用浅绿色重点卡；日期、剂型、产品名称放在首屏；数量、单位、单价、购买渠道、用途、作物、备注收进“补充信息（选填）”；账本列表优先显示剂型，类别改以“用途：”次要展示。
- **数据链路**：`farm_bill` 新增可空 `dosage` 列，POST/GET/PATCH 及扫码入口完整传递；新增剂型、作物、渠道常量。旧账单剂型为空时保持兼容，类别统计口径不变。
- **验证**：本机 `node scripts/db-init.mjs --migrate-only` 成功（17 张表，补充 `farm_bill.dosage`）；`npm run build` 完整通过。受限开发服务无法启动 esbuild 子进程，使用生产构建产物启动预览并确认账本页可正常渲染；未部署。

### 2026-09-24 | feat：顶部操作按钮增大并等宽铺满
- **用户确认范围**：查询页顶部“记一笔账 / 一键举报 / 重新扫码”，不改记账弹窗底部按钮。
- **改动与验证**：`TraceExternal.vue` 顶部改三列等宽网格，三个按钮全部 `lg + block`，移除右侧自动留白；Edge 真浏览器目视确认整行铺满、文字图标完整。仅布局变更，未新增测试，`git diff --check` 通过；未推送、未部署。产品建议单独反馈，未混入实现。

### 2026-09-24 | feat：外码查询页操作按钮移至顶部
- **改动**：仅调整 `TraceExternal.vue`，页标题下放紧凑操作行：“记一笔账”“一键举报”改为 `sm` 非通栏按钮，“重新扫码”移至同一行右侧；删除底部重复返回按钮，保留左上角返回。记账预填、举报弹窗和扫码跳转逻辑不变。
- **验证**：Edge 真浏览器目视确认顶部布局与仅一个返回入口；举报按钮正常打开渠道弹窗；`git diff --check` 通过。纯布局调整未新增测试；未推送、未部署。

### 2026-09-24 | feat：外码比对页登记资料优先展示与状态摘要
- **用户确认**：绿色标题采用“本次比对未发现明显异常”，不用“该产品合格”；下方加“此页面仅为农资315数据与外部对比页”，非本站签发说明降为小字。
- **界面**：完整 `/trace` 外码结果页顺序改为登记库资料 → 来源页链接 → 来源产品/生产/原药信息 → 逐项比对 → 码值及结构；登记资料补充总含量和无候选空态。比对区增加四态数量汇总，参考值置于来源值上方（查询码标注为“本次查询码”，不冒充登记资料）。历史快照仍只展示当时来源与比对，不实时重查登记库。
- **展示规则**：共用纯函数 `summarizeExternal`；明确产品日期已过、匹配登记证过期、字段 mismatch、成分/原药等 review 显示警示；insufficient、无登记参考的批次及受托企业不计异常。抓取失败、无确定登记候选或无一致比对时保持中性；成功且未发现上述问题时绿色，不表示质量或真伪鉴定。日期仅认有效完整日历日期，不从“2年/见喷码”推断。
- **验证**：新增状态规则测试 5/5，原解析器 8/8；类型检查仅既有 bill-input.ts(84,5)；本机生产构建通过。Edge 真浏览器检查绿色布局与过期橙色状态，过期探针已恢复。ddspp 真实离线样本 18 项比对（15 一致/0 差异/1 不足/2 人工核实）；保留一条本机明确标识的成功样本快照供用户预览，UUID `57878377-3766-4968-910f-88f830f8034e`，非线上实时抓取。
- **范围**：仅展示层状态与布局，服务端解析器、核验规则、预警、DDL 均未修改；未推送、未部署。既有其他未提交文件保持原样。

### 2026-09-24 | fix：块 1 通用兜底——来源抓取失败仍保留原页入口并从 URL 提码
- **改动**：4 个运行时文件；快照新增可选 `sourceUrl/platform`，正常收集、繁忙短路、限流短路均回填；只带来源网址时先调用共用 `extractTraceCode`，再收集快照，最后以页面码兜底。原页链接不再依赖解析成功，产品/生产/原药区块条件不变。
- **验证**：解析器单测 8/8、M7 回归 22/22、隔离依赖验证繁忙与限流短路通过；nyzs315 本机抓取被 SSRF 拒绝时，仍返回合法码、`external-reg`、候选 `PD20172225`。Edge 真浏览器目视验证失败链接及成功样本三块内容；成功样本来自仓库 ddspp fixture，18 项比对、10 条产品字段，不能替代线上实时抓取验收。`npm run build` 成功；`tsc --noEmit` 仅既有 `bill-input.ts(84,5)` 错误。
- **清理**：本轮 M7 新增 5 行按运行前基线 + 当日 + 精确 ID 删除；本轮 3 条来源快照按 UUID 删除，未产生假预警。证据在忽略目录 `logs/block1-*` 与 `logs/m7-regression-result.json`。
- **边界**：解析内核、核验判定、预警、存储策略均未改；零 DDL/依赖/环境配置。按用户方案，旧快照无顶层新字段时不显示链接（旧的成功快照此前可以显示来源内的链接，此处存在展示差异，未迁移旧数据）。
- **上线状态**：本轮仅本机实施验证，未推送、未部署；公网实测指纹仍为 `1790236396250`。既有线 B 表已在线，本轮增量无须迁移；发布须在服务器重新构建并仅 `pm2 reload nz315`，不得上传本机构建产物。部署后仍须验证 ddspp 实时成功抓取与 nyzs315 兜底。

### 2026-09-24 | deploy-prep：打「线 B 外码来源页快照 + M7/M1 解析器合并 + 登记库收口」上线包（`a40ef08` / 732,720 B）· 产出 35 号执行单 · 推送 `ycdb`
- **结果一句话**：用户下了一条三合一指令「**①可以清除 · ③推送然后准备上线**」⇒ ① 清掉本机 `external_source_snapshot` 里上一轮遗留的 **5 行测试残留**（清前把 5 行原样存到 `logs/_snapshot-rows-backup.json`，清后该表 **0 行**）；② `git push -u origin ycdb` 成功（**远端 `refs/heads/ycdb` = `a40ef08`**；本地 `origin/ycdb` 跟踪引用因本机 git 老毛病未落盘，已用 node 直写 loose ref 修好，现 `## ycdb...origin/ycdb`）；③ 用 `git archive` 打出上线包 **`nz315-ycdb-a40ef08.tar.gz`**（**732,720 B** / SHA256 `9353df93c9d48bb3e4b28ee3a638d23274ba820a7e6c27a4d837c8f594acadf3`，落 `E:\software\workbuddy\文件存放处\2026-09-24-1447-ycdb-外码来源页快照与解析器合并上线包\`）并做完整自验；④ 产出 **`docs/handover/35-部署执行单-线B外码来源页快照与解析器合并（2026-09-24）.md`**（**取代 33 号用于本次**）。⚠️ **只做「准备」——未部署、未动服务器、未动线上数据库**。
- **🔴 本轮最先要纠正的一条既有事实（差点让执行单写错基线）**：早期 memory 里记的「33 号那单只准备、未部署 / 线上 = `39753e3`」**是当时的会话口径**，已被 09-24 的公网实测推翻 ⇒ **线上 = `35da7cc`**（2026-09-23 **18:07:50** 构建，公网构建指纹 **`1790158070910`**）。⇒ 本轮范围定为 `git diff 35da7cc..a40ef08`。**35 号里「时间戳必须不再是 `1790158070910`」这条判据就是据此写的**；`AGENTS.md` / memory 已同步更正。
- **★ 本轮要推的东西 = 34 号那轮的三笔**（线 B 快照与比对 + M7/M1 解析器合并 + 登记库候选查询收口）。`git diff --stat 35da7cc..a40ef08` = **33 文件 / +2,918 −301**；其中**运行时代码 25 个（12 新增 + 13 修改）**、`AGENTS.md`/`PROJECT_LOG.md` 两个文档、6 个内部文档/AI 记忆。
- **★ 与 33 号最大的不同：本轮【有 DDL】** —— 新建表 `external_source_snapshot`（`db-init.mjs` 的 `DDL` 数组 16 → **17** 张；`verify-db-migration.mjs` 的 `ACTIVE_TABLES` / `EXPECTED_NEW_TABLES` 两个白名单都已加）。⇒ **33 号那句「不出现任何 `[db] 迁移：…` 行」的正确输出判据本轮不能照抄**；35 号的判据改成两条可数证据：**迁移前 `表数=16` / 迁移后 `17 张表创建完成`**、**`compare` 打出 `OK 新表 external_source_snapshot 0（本次迁移预期新建，空表属正常）` 且退出码 0**。
- **★ 包自验（四组判据全绿）**：
  - **清单双向核对**：`git -c core.quotePath=false ls-tree -r`（**229**）− `export-ignore`（**47**）**= 182 == 包内实际 182**（tar 条目 241 − 目录 59 = 文件 182）；**多出 0 / 缺失 0**；
  - **禁用项扫描**：`.env*`（白名单仅 `.env.example`）/ `node_modules/` / `.output/` / `.nuxt/` / `.git/` / `*.exe` / 嵌套包 —— **命中 0 条**；
  - **逐文件内容比对**：**先做 `\r\n → \n` 归一**再与 `git cat-file` 比 ⇒ **不一致 0 个**；
  - **运行期必备文件抽查 25 个全在位**；`deploy/*.sh|conf|cjs` **全 LF** ✅。
- **★ 打包过程中自己抓到的两个坑（已避开，写进 35 号）**：① `git ls-tree -r --name-only -c core.quotePath=false` **`-c` 写在子命令之后** ⇒ **exit 0 但输出 0 个文件**（假成功）⇒ 必须 `git -c ... ls-tree`；② 禁用项正则写太宽（`/^\.env\./`）会把 `.env.example` 误判成 `禁用项 1` ⇒ 改成显式 `/^\.env\.[a-z]+$/i` + 白名单；顺手核了 `.env.example` 确为**纯模板**（`DB_PASSWORD=` 空、`SESSION_SECRET=change-me-…`、WECHAT/AMAP key 全空）。
- **★ 35 号执行单相对 33 号的结构性新增（都是本轮特有）**：① **第 0 步加「反查新表现在还不存在 + 两个新路由现在都是 404 + 记下当前构建指纹」**（这样第 6 步「它在、它们通」才是真证据）；② **第 4 步判据整体换掉**（见上）；③ **主验收增加两条**：新表/新接口/新页面三件通（含「未登录 `401` vs 第 0 步 `404`」这组前后对照）、**`?source=` 全链路跑一次**（用**内网地址**当来源 ⇒ 被 SSRF 拦 ⇒ `status=unavailable` + `raw_document` 为 `NULL` + 表里恰好 1 行 + 匿名能读回 + 后台能看到，**读完按 id 精确删掉那一行**）；④ **保留线 A 的回归**（N1 建档文案 + 四页记账 `genuine=1`）；⑤ 回滚节新增**源码级反向清单**（本轮 12 个新增文件，因为 `tar` 恢复**不会删**它们），并明确 **「不要为了回滚去 `DROP TABLE`」**。
- **★ 顺手算出来的一个数字（已写进 35 号，供用户裁定用）**：包内 `AGENTS.md` **189,100** 字节 + `PROJECT_LOG.md` **465,464** 字节 = **654,564** ≈ 本次 732,720 字节包的 **89%** ⇒ 这个包**九成体积是给内部看的说明书**。给这两个文件加 `export-ignore` 可把包瘦到约 **78 KB**（**零运行时影响**，因为运行期不读它们）—— **仍待用户裁定**。
- **★ 本轮新识别的运维风险（未修，已写进 35 号 §6' 与 AGENTS.md）**：`external_source_snapshot` 是**匿名可写**的表 —— `/api/trace?code=<32位>&source=<任意公网URL>` **未登录即可触发**，每次最多抓 **1MB** 原文落库，且 `status='unavailable'` 的行**不参与 10 分钟缓存复用** ⇒ **抓取失败时每次请求都新落一行**（限流 60 行/分）⇒ 最坏 GB/小时级，而**服务器与 cynx 共用且盘已 75%**。方案已定（失败只落元数据、成功截断 64 KB），**本轮刻意未修**（超出范围）⇒ 建议下一轮优先。
- **修改文件**：**新增** `docs/handover/35-部署执行单-线B外码来源页快照与解析器合并（2026-09-24）.md`；**修改** `AGENTS.md`（接手顺序 + 本轮块 + 线上基线更正）· `PROJECT_LOG.md` · `docs/handover/README.md` · `.workbuddy/memory/2026-09-24.md` · `.workbuddy/memory/MEMORY.md`。**本轮无代码改动**（0 个 `.ts`/`.vue`/`.mjs` 被改）⇒ 上线包内容 = `a40ef08` 的 `git archive`，**与工作区一致**。
- **遗留问题/待办**：① **等用户放行部署**（照 35 号跑；**33 号不适用**）；② 上一节（方案 3）遗留的「`MAX_ROW_SCAN`/`MAX_CANDIDATES` 上下限联动」仍在，而「本机 5 行残留」**已由本轮清除**（闭环）；③ 线 B 自带 4 条缺口**未动**（死代码 `outcome.externalSource` · `resultType` 隐式真值 · `raw_document` 存储放大 · `PRIVATE_HOST` 正则末尾多 `$`）；④ `.output.bak-*` 线上本轮后会到 **5 个**，盘约 75%。
- **给下一个 Agent 的提示**：① **判「线上是哪个版本」只能看公网实测的构建指纹**（`curl -s https://www.nz315.cn/_nuxt/builds/latest.json`），**不要信本机 memory 里写的**（本条就是活教材）；② 本轮上线**有 DDL**，`--migrate-only` **绝不能省、而且真的会建表**；③ 走 35 号时**第 0 步必须先反查新表还不存在**，否则第 6 步的"它在"没有证明力；④ 本机 `git ls-tree` 的 `-c` **必须在子命令之前**（写成 `git -c core.quotePath=false ls-tree`）。
- **测试情况**：包自验 4 组判据全绿（182/182 双向核对 · 禁用项 0 · 归一后内容不一致 0 · `deploy/` 全 LF）· 本机 5 行测试残留已清（清前已备份行内容）· `ycdb` 已推送且跟踪引用已修好。**零代码改动 / 零依赖 / 零 `.env` / 零 nginx / 未接触服务器**。
### 2026-09-24 | refactor：外码候选查询收口为共用原语（方案 3「保守收口」）—— 零语义变化
- **结果一句话**：上一轮把「方案 3 = M7 直连登记库收口」列为**独立做一轮**；本轮用户先拍**收口力度**（在「保守收口 / 强收口」之间选**保守**）⇒ 把「**登记证后六位 + 按类别过滤**」这套**此前两端各写一遍**的口径收口为 `registry-lookup.ts` 新导出的共用原语 **`findRegistryRowsByUnitCode(codeParts)`**，M7（`external-verification.ts`）的内联 SQL 与重复的 `regCategoryOf` 过滤**整段删除**。**本轮提交 = `797407c`**（2 文件 / +79 −14，**未推送、未上线**）。
- **★ 为什么不让 M7 直接改用 `lookupRegistryByCode()`（"强收口"，被否）**：那个带**展示口径** `slice(0,5)` 与 **10 分钟进程内缓存**。而 M7 是拿候选集做 `.find(证号完全相等)` 来定「来源证号 vs 登记候选是否一致」⇒ **一旦截断，真实证号排在 5 条之外时会把「一致」误判成「不一致」** —— 在防伪核验工具里等于**误指认**。⇒ 改用**共用原语 + 两端各自保留截断/缓存/映射**的保守形态。
- **★ 动手前先用真实数据把边界算出来（三条硬数字，本机 `pesticide_reg` 97,471 行）**：① 按「后六位 + **真类别口径**（`^WP|^WL`→2，其余→1）」分桶 = 84,175 桶，撞车桶 **12,103**，**单桶最大 4 条**；② 但 `LIMIT` 加在**类别过滤之前**，故真正要管的是「**仅按后六位**」的桶 ⇒ 最大 **6 条**（后六位 `3-2000`；分布 1条:66776 / 2条:9096 / 3条:3174 / 4条:720 / 5条:19 / 6条:1）⇒ **`LIMIT 20` 有 3 倍余量、当前数据零截断**；③ 「**同后六位但跨类别**」的桶 **4,389** 个 ⇒ **类别过滤不是可选项**（缺了必然拿 WP 的证去比 PD 的码），这条已写进原语文档。
  ⚠️ 中途踩过一次口径：第一版用 `LIKE 'PD%'/'LS%'/'EX%'` **近似**类别、把其余行单列成第 0 类**排除**，等于**把一部分真实撞车拆开了** ⇒ 结论不可信，按 `regdata.ts` 的**真实函数口径**重算才定案。
- **★ 穷举等价证明（比 22 条断言更硬，覆盖全表）**：`logs/_equivalence-proof.mjs` 对 **159,572** 个「后六位桶 × 类别」对，逐对比较**收口前 vs 收口后**的候选集 ⇒ **M7 候选集不一致 0 对 · 公众端候选集不一致 0 对 · 顺序变化 0 对**（本机导入本就按证号排序，连顺序都没变）。
- **★ 只改三处口径差异，全部实测为零影响**：① 取数由**无上限**→`LIMIT 20`（加在过滤前，实测零截断）；② 新增 `ORDER BY registration_no`（原无序，同桶多行"谁在前"由 MySQL 随机决定 ⇒ 变确定）；③ 原语守卫 = **`validCategory && registrationLast6`，与 M7 收口前逐字一致**；🔴 刻意**不含** `validLength` —— 公众端在调用前已自行判过，两处都不加会让「≥32 位」这条约束失效。顺手修掉 `MAX_ROW_SCAN` 的一句**写反的注释**（原写"先按类别过滤再截断"，实际 LIMIT 在**过滤之前**）。
- **★ 验证（含"证明服务真在跑新代码"）**：① **金丝雀 A/B/A** —— 临时让原语 `return []`，`/api/trace` 候选当场 **4 → 0**（`external-reg` → `not-found`），撤销后第三个码回到 **4** 且与库内**逐条一致** ⇒ 同时证明「dev 确实加载了新代码」与「新代码真挂在公众端链路上」（**只跑回归是证明不了这一点的**）；② **M7 四路回归 22/22**、**假预警 0**（A/I 两例的 `registration-suffix:match` + `registration-no:match` 正走本次收口的查询）；③ 解析器单测 **8/8**；④ `tsc --noEmit` 仅剩**既有的** `server/utils/bill-input.ts(84,5)`；⑤ 回归写入的 **5 行** `external_verification`（id 64–68）已删，库**还原至基线**（44 行 / maxId 44；`risk_alert` 12 行、`trace_code` 110 行未动）。
- **★ 提交手法**：`git commit -F logs/_commit-msg-registry.md -- <两个文件路径>`（**pathspec 限定**，中文 message 走文件）；`git show --name-status` 复核 = **只有这 2 个文件**，两个 master 线未跟踪项（`docs/厂家后台使用说明/`、`scripts/generate-user-guide.mjs`）**未被卷进来**。**回滚方式**：`git reset --soft HEAD~1`。
- **★ 遗留的两件事**：① 本机 `external_source_snapshot` 有 **5 行上一轮（11:16–11:21）的测试残留**（含一行 url 是 `http://127.0.0.1:3100/api/stats` 的内网拒绝探针）—— **本轮未删**，属"上一轮清理时漏下的"，留待用户裁定；② **上下限联动**：将来登记库导入若让某个后六位桶 **>20 条**，原语会在类别过滤前丢行 ⇒ 核验漏候选、可能误判不一致 ⇒ `MAX_ROW_SCAN` 与 `MAX_CANDIDATES` 必须一起上调。
- **修改文件**：`server/utils/registry-lookup.ts`（+ 原语 + 修注释）· `server/utils/external-verification.ts`（删内联 SQL / 改调原语 / 加收口说明）· `docs/handover/34-…（ycdb·2026-09-24）.md`（§8.1 由"待做"改"已完成"+证据）· `AGENTS.md` · `PROJECT_LOG.md` · memory 两份。**代码侧归属 = 代码提交 `797407c`**。
- **给下一个 Agent 的提示**：① **改 `findRegistryRowsByUnitCode` 就是同时改两端**（公众端兜底 + 后台核验），口径要点全写在函数注释里；② 判「收口有没有改变行为」**不要只跑 22 条断言** —— 断言覆盖不到"截断边界"，要用 `logs/_equivalence-proof.mjs` 那种**全表穷举集合比较**；③ 本机 `git` 的 coreutils 全瘫（`ls/head/tail/sleep` 找不到）⇒ 一律 node 绝对路径 + 落盘再读；④ **M7 回归会真写库**，跑完必须清（`id>44 AND created_at>=今天`）。
- **测试情况**：穷举等价 159,572 对 0 不一致 · M7 四路回归 22/22 · 单测 8/8 · `tsc` 仅 1 条既有错 · 数据库已还原。**零 DDL / 零依赖 / 零 `.env` / 零 nginx / 未接触服务器**。
### 2026-09-24 | feat：外码来源页快照与比对落成提交 · M7 与公众端外页解析器合并为一套（并修掉合并引入的一个真回归）
- **结果一句话**：用户先要「模块拆分分析」（只给方案）→ 追问「M7 与 M1 业务是否重合」→ 定下**方案 1（合并解析器）**→ 说「开工」→ 最后裁定「按一轮一提交」。⇒ 本轮把**一直挂在工作区、从未提交**的「外码来源页快照与比对」功能线落成提交，并把 M7 后台侧**内联**的外页解析实现**整段删除**、改调公众侧内核；**合并过程中实测抓到一个真回归（手工粘贴纯文本被压平、登记证号与持有人全部取不到）并修掉**。**本轮提交 = `0598e2d`**（27 文件 / +1,562 −280，**未推送、未上线**）。
- **★ 为什么是一个提交而不是两个**：`server/utils/source-parser.ts` / `shared/types/source-snapshot.ts` / `tests/` 都是**线 B 新增的文件**，本轮只在其上继续改 ⇒ **物理上拆不开**（硬拆得先造一个"有内核没消费者"的中间版本）。
- **★ 合并的形态（刻意保留的部分）**：内核取两边之长 —— M1 的**组边界原药配对 + 严格日期 + 版本号**，并入 M7 的**12 字段同义词表 + 全角转半角归一 + JS/JSON 脚本键提取 + `spec`** ⇒ `pick()` 三层取值（精确标签 → 同义词别名 → 脚本键，精确层命中时结果不变）。**不合并**：`fetchWla1` 专用适配器（`productionType` 唯一来源）· `pageText` 手工粘贴通道（M1 没有）· 判定与预警语义（M7 逐项 6 项判定 + 触发 3/5/6/7；M1 四态含 `review` 降级 + 只读不预警）。`SOURCE_PARSER_VERSION` `.2` → **`.3`**。
- **★ 🔴 抓到的真回归（本轮最值钱的产出）**：内核 `sourceText()` 一刀切 `.replace(/\r?\n/g, ' ')` ⇒ 手工粘贴的纯文本**整段并成一行**、逐行配对全废 ⇒ 用例 A（与登记库完全一致的 9 字段）**三项判定全 `insufficient`**。而后台核验页的失败提示原文明确承诺「标签与值之间用**冒号、Tab 或换行**分隔」。**取证**：`git show HEAD:server/utils/external-verification.ts` 的旧实现 `stripHtmlToText` **不压平换行**、`extractLabeledFields` 按 `text.split(/\r?\n/)` **逐行配对**并支持「取下一非空行」⇒ **确认为合并引入，不是既有缺陷**。**修法**：内核用 `/<[a-zA-Z!/][^>]*>/` 探测输入类型 —— **纯文本**保留换行并认「冒号 / Tab / 2+空格 / 换行」四种分隔（含「标签一行、值一行」兜底，且下一行本身是标签时不取值）；**含标签的 HTML** 逐字节维持原口径（源码换行先压平、行结构只由块级标签产生）⇒ **公众端 `/api/trace` 外页快照零变化**。🔴 铁律：**纯文本特有的兜底一律挂在 `plain` 探测下面**。
- **★ 验证（22/22 + 8/8，不是"应该好了"）**：① 单测 `node --test tests/source-snapshot.test.mjs` ⇒ **8 pass / 0 fail**（5 → 8 例：新增别名与脚本键兜底、纯文本换行护栏、纯文本「分行 + 双空格」；含 ddspp **真实页面** fixture 用例 = **HTML 侧零变化有证据**）；② 新写四路 HTTP 回归 `logs/_m7-regression.mjs`（自行登录 admin + 查库取真实样本 `PD20001183 / 0.5%溴敌隆母液 / 河南远见农业科技有限公司`，构造 32 位码）⇒ **22/22 断言通过**：纯文本匹配路 `overall=match` 且后台页 **8 个展示字段全非空** · 别名/脚本键兜底全命中 · 裸码 `insufficient` **不误判 mismatch** · `ftp://` 填「来源链接」栏 ⇒ **200 退化为仅码值核验**（实测否掉了"应该是 400"的直觉）· 内网 `http://127.0.0.1:3100/login` ⇒ **502 未被抓取**（另单独验 `source-fetch`：`127.0.0.1` / `10.2.3.4` / `169.254.169.254` / `[::1]` **全拒**）· `source_data` **键名合集**兼容（旧 44 行 14 键 → 新 16 键，**零缺失**，新增 `originals`/`productFields`）· **未产生假预警**（`risk_alert` 全程 12 行未变）；③ `tsc --noEmit` ⇒ 仅剩**合并前就存在**的 `server/utils/bill-input.ts(84,5)` 一条，改动文件全干净；④ 回归写入的 19 行测试工单（id 45–63）已按 `id>44 AND created_at>=今天` **清除**，`external_verification` 复原为 **44 行 / maxId 44**。
- **★ 提交手法（按项目铁律，没走捷径）**：**逐路径 `git add --`**（26 条路径，**绝不 `-A`/`.`**）→ 核对 `git diff --cached --name-only` **= 27 项且禁入项 0** → `git commit -F logs/_commit-msg.txt`（中文 message 走文件）。✅ **两个 master 线未跟踪项确认排除**：`docs/厂家后台使用说明/` 与 `scripts/generate-user-guide.mjs`（提交后 `git status` 只剩这两项）。`logs/` 已被 `.gitignore` 覆盖，回归脚本/证据/提交信息**均未入包**。**回滚方式**：`git reset --soft HEAD~1`。
- **⚠️ 两处「本机测不了 / 与直觉相反」的实测事实（别当回归）**：① **`wla1` 与通用 HTML 抓取两路在本机不可测** —— 本机出口经代理 ⇒ `www.wla1.cn` / `ddspp.cn` 被 DNS 解析到**非公网地址** ⇒ 硬化的 `fetchSourceDocument` 主动拒绝（wla1 表现为 **500 裸错**、通用页 **502**）⇒ 这两路只能在能直连外网的机器上验；HTML 解析内核由 ddspp fixture 单测覆盖，wla1 路由**源码级断言**兜底（断言 `productionType: product.createtype` 仍在）。② 回归脚本的**基线必须取「今天之前创建的行」**（本机库 `external_verification` 有 **44 行 09-22 的历史测试残留**，按 `MAX(id)` 比会拿自己上一轮的行当基线）；`source_data` 兼容性判据是**键名合集**而非逐行键集。
- **修改文件**：**新增** `docs/handover/34-交接手册-外码来源页快照与解析器合并（ycdb·2026-09-24）.md`；**修改** `AGENTS.md` · `PROJECT_LOG.md` · `docs/handover/README.md` · `.workbuddy/memory/2026-09-24.md` · `.workbuddy/memory/MEMORY.md`；**（技能）** `nz315-func-regression`（新增「M7 四路输入回归」一节）。**代码侧归属 = 代码提交 `0598e2d`**（27 文件 / +1,562 −280）。
- **遗留问题/待办**：① **用户已裁定「独立做一轮」**：**方案 3 = M7 的登记库直连收口到 `registry-lookup.ts`**（`external-verification.ts` 直连 `pesticide_reg` + 自建类别过滤，M1 走 `registry-lookup.ts`→`regdata.ts`，**同一口径两处实现**）；② 线 B 自带 4 条缺口**本轮未动**（见 34 号 §8）：死代码 `outcome.externalSource`（服务端零赋值，功能已被 `TraceSourceSnapshot` 覆盖）· `trace.get.ts` 的 `resultType: hasReg || sourceSnapshot` 隐式真值 · 🔴 **`raw_document` 存储放大**（匿名可触发，抓取上限 1MB、失败也落库且 `unavailable` 不复用缓存 ⇒ 最坏 GB/小时级，**服务器与 cynx 共用且盘 75%**）· `PRIVATE_HOST` 正则末尾多 `$`（**当前不可利用**，真实抓取已收口 `source-fetch`）；③ 本轮新记录两条：`raw.extracted` 形状由「9 字段对象」变为「数字」（**全库零消费者** ⇒ 安全）· `fetchWla1` 对"来源不可访问"未包装成 502、直接裸 **500**（**与合并前同构，非本轮回归**）。
- **给下一个 Agent 的提示**：① **改 `sourceText` / `parseSourceDocument` 前先读 34 号 §4** —— 「纯文本保留换行」与「HTML 逐字节不变」必须**同时**成立，纯文本特有的兜底一律挂在 `plain` 探测（`/<[a-zA-Z!/][^>]*>/`）下面；② **「已提交」≠「已上线」**：`0598e2d` 未推送未上线，且**含新 DDL**（表 `external_source_snapshot`）⇒ **33 号（零 DDL）不适用，要上线必须另出执行单**；③ 提交仍按老规矩：`ycdb` 上**逐路径 `git add --`**、中文 message 用 `git commit -F`、提交后 `git show --name-status` 复核；④ 回归入口 = 单测 `node --test tests/source-snapshot.test.mjs` + `node logs/_m7-regression.mjs`（**会真写库，跑完要清理**；细节见技能 `nz315-func-regression` 的「M7 四路输入回归」一节）。
- **测试情况**：单测 8/8 · 四路 HTTP 回归 22/22 · `tsc --noEmit` 仅 1 条既有错 · 数据库已复原（`external_verification` 44 行 / `risk_alert` 12 行未变）。**零依赖 / 零 `.env` / 零 nginx / 未接触服务器**；**含新 DDL**（新表 `external_source_snapshot`）。
### 2026-09-23 | deploy-prep：打「N1 + 四页记账入口」上线包（`35da7cc` / 698,370 B）· 产出 33 号执行单 · 修掉 24 号一处流程缺陷
- **结果一句话**：用户说「**准备上线**」⇒ ① 用 `git archive` 打出上线包 **`nz315-ycdb-35da7cc.tar.gz`**（**698,370 B** / SHA256 `445b2c8df06f7a10341f2d1f1baba542650d0b956dea28aeee36a7054f8d018`，落 `E:\software\workbuddy\文件存放处\2026-09-23-1640-ycdb-N1与四页记账入口上线包v3\`）并做完整自验；② 产出 **`docs/handover/33-部署执行单-N1与四页记账入口（2026-09-23）.md`**（**取代 24 号用于本次**）；③ 顺手修掉 24 号里一处**真实流程缺陷**。⚠️ **只做「准备」——本轮未推送、未部署、未动服务器、未动数据库**。
- **★ 本轮要推的东西 = 32 号那四笔**：N1 建档/编辑校验登记证号（含 `platform_admin` 专属「新证豁免」+ `risk_alert(3)` 留痕）· 公众端「一键记账」铺满四个结果页 · 新增「一键举报」`TraceReport` · 正品页入口统一为底部撑满大按钮。基线 `39753e3`（= 线上）→ **`35da7cc`**；`git diff --stat 39753e3..35da7cc` = **21 文件 / +1,875 −121**（其中 11 个是文档/记忆，**运行时代码 10 个**）。
- **★ 包自验（四组判据全绿，脚本 `logs/_pkgverify.mjs`，证据 `logs/_selfverify.txt`）**：
  - **清单双向核对**：`git ls-tree -r`（214）− `export-ignore`（44）**= 170 == 包内实际 170**；**包内多出 0 / 缺失 0**；
  - **禁用项扫描**：`.env` / `node_modules/` / `.output/` / `.nuxt/` / `.git/` / `*.exe` / 嵌套包 —— **命中 0 条**；
  - **逐文件内容比对**（两侧 `\r\n→\n` 归一后算 SHA256）：**170/170 一致，不一致 0**（其中 165 个"字节数不同但归一后一致"= 纯 CRLF 差异，**字节差恰好等于行数**，已逐条解释，见下）；
  - **`deploy/*.sh|conf|cjs` 全 LF**（Linux 上 `bad interpreter` 的前提）。
- **★ 与上一版包（`39753e3`）逐文件比内容（这才是"包是否过期"的正确判据）**：**② 只在旧包有（= 本轮删除）= 0** ⇒ **本轮无删除动作**（`git diff --name-status 39753e3..35da7cc` 里确实**没有一条 `D`**）⇒ **33 号执行单里不需要 `rm -f` 小节**（这与上一轮「删附近门店 5 文件」形成对照）；**① 本轮新增 = 2**（`TraceBillEntry.vue` / `TraceReport.vue`）；**③ 内容变了 = 10**（8 个运行时代码 + `AGENTS.md` / `PROJECT_LOG.md`）。
- **🔴 ★ 修掉 24 号的一处真实流程缺陷（本轮最值钱的一条）**：24 号把 `mv .output .output.bak-<TS>` 放在**第 1 步**，而它**当场**打断静态资源（Nitro 的静态资源是**运行期读盘**：`/`、`/trace` 照旧 200 的迷惑现象下，页面其实**没样式没交互**、`/tools/*.exe` 500），导致「上传 / 解包 / 迁移判据核对」这些**需要停下看数字的步骤全被塞进断资源窗口里** ⇒ 上一轮实测窗口 **15:06→15:29 = 23 分钟**。**33 号把 `mv` 挪到第 5 步 `npm run build` 的紧前一行** ⇒ 第 0–4 步全程线上正常，**窗口压到 2–3 分钟且中途无停顿点**。
- **★ 新增一条「N1 上线前必做」的只读核对（写进 33 号第 0 步）**：查线上 `product` 里**证号不在 `pesticide_reg`** 的行 —— 那些行上线后**改证号会被拦**（改名/备注/停用**不受影响**，代码只在证号变化时校验）。本机库有 **2 条**（`id=21 PD20990001` / `id=22 PD20990002`，带【测试】）；**线上数量未知**，故必须在部署前查、并按「预期影响面」而非「故障」解读。
- **★ 33 号里按「判据可靠性」重写了两处验收**（不是照抄 24 号）：① **N1 阻断必须断言到报错文案**「在农药登记资料库中不存在，无法建档」—— 因为 `POST /api/admin/products` 在 N1 校验**之前**还有 6 道校验（登记证号非空/名称/specId/category/原药行/证号重复/企业归属），**任一不过都返 400** ⇒ 只看状态码 = **假通过**；② **四页记账入口用 `genuine` 页的 `记一笔账` 计数当核心判据**（应为 `1`：`0` = 没构建进去，`2` = 页头旧按钮残留），并显式写明 `grep -c` 数的是**匹配行数**而非出现次数（SSR 产物通常一整行）。
- **★ 环境坑（沿用 node 落盘法，本轮新写 4 个临时小工具）**：`logs/_gitrun.mjs`（跑 git + 落盘）· `_lsdir.mjs`（列目录 + 落盘）· `_mkpkg.mjs`（archive + 指纹）· `_pkgverify.mjs`（包自验）。PowerShell **stdout 依旧被整体吞掉**（`git rev-parse` 等全返回 exit 0 无输出）⇒ 全程走 node `writeFileSync` 落盘再 Read。另确认 `logs/` 已被 `.gitignore` 忽略（那些 `_*.txt` 不污染 `git status`）。
- **⚠️ 一处已知的"文档 vs 包"差异（无运行时影响，但要讲清）**：按「先提交代码 → 再打包 → 最后写文档（文档里要写死 SHA256）」的顺序，本次打包之后又改了 **`AGENTS.md` / `PROJECT_LOG.md` / `docs/handover/README.md`**（其中后两个在 `export-ignore` 白名单内 ⇒ **不影响包内容**）。⇒ **包内那两份根目录文档是打包那一刻的版本**，与 HEAD 的差异**仅在文档、运行时代码零差异**（可用 33 号里那套逐文件比对证明）。**根因**：`AGENTS.md` / `PROJECT_LOG.md` **未加 `export-ignore`** —— **待用户裁定**是否加。
- **修改文件**：**新增** `docs/handover/33-部署执行单-N1与四页记账入口（2026-09-23）.md`；**修改** `AGENTS.md` · `PROJECT_LOG.md` · `docs/handover/README.md` · `.workbuddy/memory/2026-09-23.md`。**产物（在仓库外）**：`E:\software\workbuddy\文件存放处\2026-09-23-1640-ycdb-N1与四页记账入口上线包v3\nz315-ycdb-35da7cc.tar.gz`。**零代码改动 · 零 DDL · 零依赖 · 零 `.env` · 零 nginx · 未接触服务器**。
### 2026-09-23 | style：正品页「记一笔」从页头小按钮改为操作区大按钮（用户发图裁定，四处形态统一）
- **结果一句话**：用户发来两张截图（正品页的页头 `size="xs"` 小按钮 / 异常页的底部撑满大按钮）说「**这个页面的记一笔也做成这样吧**」⇒ 正品页页头那个小按钮**移除**，入口移到**操作区**（反馈入口之后、返回按钮之前）并 `block` 撑满 ⇒ **四个结果页（正品 / 外码 / 异常 / 查无此码）形态与位置彻底统一**。本轮提交 = **`b173abf`**（7 文件 / +80 −27，**未推送**）。
- **★ 为什么必须「移位」而不只是「放大」**：`PageHeader` 右侧是给**图标级动作**（分享）用的窄区，塞一个撑满行的大按钮会撑坏标题栏；而「撑满一行」这个形态天然属于页面主体（`block` 要独占一行宽度）⇒ 用户要的"做成这样"**必然包含移位**。顺带把四处入口真正统一了（此前正品页是唯一的例外形态）。
- **★ 改动（1 个组件 + 1 处注释）**：`TraceResult.vue` 的页头 `#right` 删掉 `<TraceBillEntry size="xs">`（只留分享按钮），页面底部在反馈入口之后、返回按钮之前插入 `<TraceBillEntry :code :product-name :category block />`；`TraceBillEntry.vue` 顶部注释同步（改为「四个结果页入口一律底部撑满」+ 记下页头形态已废弃的原因，防后人照旧文档改回去）。
- **★ 真浏览器验证（2 张新截图 + 2 组探针；探针新增 `billCount` / `billInHeader` 两个断言）**：正品页 `billCount=1`（**无重复入口**）· `billInHeader=false`（页头已清干净）· `x=621,y=781,w=640,h=36`（**与异常页 / 外码页 / 查无此码页同尺寸**，仅 y 随内容长度不同）· `block=true` · 预填 `【测试】30%草甘膦水剂` / `除草剂` 未被破坏 · 未登录点击仍弹登录提示；**异常页回归**（`frozen`）`billCount=1`、同尺寸 ⇒ 未被波及。
- **⚠️ 一条被本轮推翻的旧结论（留档）**：32 号 §4.4 里那句「正品页按钮与改前**逐像素一致**（布局零变化）」**只在 17:3x 那一刻成立** —— 17:2x 用户明确要求改版式 ⇒ 已在 32 号就地标注作废，并新增 **§4.5** 记录这次改动的完整断言与取舍。
- **★ 取舍留档**：正品页是全站信息量最大、页面最长的一页，把最该被看见的动作放到页面最底部，代价是用户得滚到底才看到；换来的是四个结果页形态统一（用户裁定优先）。
- **修改文件**：`app/components/TraceResult.vue` · `app/components/TraceBillEntry.vue`（注释）· `docs/handover/32-….md` · `AGENTS.md` · `PROJECT_LOG.md` · `.workbuddy/memory/2026-09-23.md` ·（技能）`nz315-func-regression`。**零 DDL / 零依赖 / 零 `.env` / 零 nginx**；仍须 rebuild + `pm2 reload nz315`；**仍未上线**。
### 2026-09-23 | feat：记账入口铺满四个结果页 · 正品页「记一笔」统一到 `TraceBillEntry`（用户追加裁定）
- **结果一句话**：用户对上一轮的三个待裁定给了答复 —— **① 异常页 / 查无此码页「也加」记账入口；② 外码页记账预填类别恒为「其他」先不管；③ 正品页那份「记一笔」**和新组件统一**；④ 欠着的（数据治理 / 服务器残留与磁盘清理）「下一轮你觉得可以做的时候顺便做」**。⇒ 三处前端改动 + 7 页真浏览器验证；本轮提交 = **`14fd75e`**（9 文件 / +111 −72，**未推送**）。**仍未上线**（沿用上一轮「先不上线」）。
- **★ 改动（3 个文件）**：`TraceAlert.vue`（异常页）与 `TraceNotFound.vue`（查无此码页）在「一键举报」之前补 `<TraceBillEntry block />` ⇒ **四个结果页全覆盖**（正品 / 外码 / 异常 / 查无此码）；`TraceResult.vue` 里那份**内联实现整体删除**（script 里 `meData`/`loggedIn`/`billOpen`/`loginTipOpen`/`billInitial`/`openBill`/`goLogin` 全删 + 模板里 `BillFormModal` 与登录提示 `UModal` 全删），页头按钮改走组件：`<TraceBillEntry label="记一笔" variant="soft" color="primary" size="xs" icon="i-lucide-receipt" :code :product-name :category />`；`TraceBillEntry.vue` 顶部注释把「已知技术债 · 建议后续统一」改写为「已统一」，并补上**各页预填口径表**。
- **★ 各页预填口径（有意不同，已写进注释与 32 号 §7，防后人"顺手统一"）**：正品页 / 非作废异常页 → 产品名 + 类别都预填；**作废码 → 都不预填**（该页刻意不展示产品信息，不把没展示的东西写进用户账本）；**外码页 → 仅在唯一候选时**才预填（后六位撞车多候选时预填错比不预填更糟）；**查无此码页 → 都不预填**。
- **★ 真浏览器验证（7 张截图 + 7 组探针，`ui-shot.js` + 通用探针 `logs/_v-props.js`）**：**正品页** 页头按钮 `x=1137,y=80,w=72,h=24` ⇒ **与改动前逐像素一致（布局零变化）**，props `productName="【测试】30%草甘膦水剂"`/`category="除草剂"`/`block=false`；**已冻结** 按钮 `[复制, 记一笔账, 一键举报, 信息有误点此反馈, 返回]` 两入口在位；**登记证过期** props `"【测试】40%毒死蜱乳油"`/`"杀虫剂"` 与接口一致；**已作废** 两入口在位且**反馈入口仍不出现**（原设计未回归）；**查无此码** 两入口在位、未传产品名；**外码页** props `"硝钠·萘乙酸"`（唯一候选已预填）未回归。
- **🔴 本轮用接口证伪了一个「看起来像 bug」的现象（值得留档）**：探针里「已冻结 / 已作废 / 查无此码」三页的 `productName` 都是空 —— 先按"看起来像取值写错"去查，**跑 `GET /api/trace` 逐码实测才发现这三种结果下 `product` 本来就是 `null`**（只有 `genuine` / `reg-expired` 带 `product`，`external-reg` 只有 `registryCandidates`）⇒ **空预填是正确行为**。教训与 skill 里那条「上限/截断/唯一性类怀疑必须用真实数据算边界」同源：**先证伪自己的怀疑，再改代码**。
- **★ 新踩一条探针手法（可复用）**：未登录时记账表单打不开 ⇒ 预填值**肉眼看不到**。解法 = 从 `button` 沿 `__vueParentComponent` 向上遍历，找到 `type.__name === 'TraceBillEntry'` 的实例，**直接读 `inst.props`**（DEV 模式专有字段，dev server 可用）⇒ 预填对不对有了硬断言，不必造消费者会话。
- **★ 影响面（仍未上线）**：**零 DDL / 零新依赖 / 零 `.env` / 零 nginx**；改了 3 个前端组件（其中正品页是**删实现**）⇒ **必须重新 build + `pm2 reload nz315`**，上一版包（`39753e3`）已过期须重打。上线验收项已补进 32 号 §5（四个结果页都要有入口、正品页仍是不撑满的页头小按钮）。
- **修改文件**：`app/components/TraceAlert.vue` · `app/components/TraceNotFound.vue` · `app/components/TraceResult.vue` · `app/components/TraceBillEntry.vue`（注释）· `docs/handover/32-….md` · `PROJECT_LOG.md` · `.workbuddy/memory/2026-09-23.md`。
### 2026-09-23 | feat：N1 建档校验（含新证豁免通道）+ 公众端补「一键记账」「一键举报」入口 · 补提交 31 号文档
- **结果一句话**：① 先补提交 31 号那轮文档（**`b447785`**，5 文件 / +356 −3）；② 修掉 **N1** —— 26 号里**唯一仍未修的 P1**：建档/编辑时校验登记证号是否存在于国家农药登记资料库，并开**新证豁免通道**（用户裁定「开一个豁免通道方便新证收录」）；③ 公众端**外码页补「一键记账」入口**、**全部异常页补「一键举报」弹窗**（12316 热线 + 农业农村局渠道）。**未上线**（用户「先不上线还有问题」）；本轮主提交 = **`2c1e1f2`**（`ycdb`，**17 文件 / +677 −14**，**未推送**）。完整记录见 **`docs/handover/32-N1建档校验与公众端两个入口（一键记账·一键举报·2026-09-23）.md`**。
- **★ N1 = PRD §5.9 异常-3 要求「后台预警 + 建档时阻断」，修之前两半都没做**：`products.post.ts` 只校验登记证号**非空** + **本系统内重复**，**从不查 `pesticide_reg`**；`[id].patch.ts` 同样只有非空校验；前端登记证号输入框是**自由文本**（占位符还写着「可修改」）。⇒ 填一个格式合法但库里不存在的证号即可 **200 建档出码**，消费者扫到「登记证号 PD99999999」而该证根本不存在，且**零预警**（全仓库零处 `triggerAlert(3)`）。**防伪平台的主防线此前是敞开的。**
- **★ 修法（3 处后端 + 1 处前端）**：`server/utils/regdata.ts` 新增 `registrationExistsInRegistry()` —— **完整证号精确匹配**（走 UNIQUE 索引 `uq_registration_no`；**刻意不用后六位**：后六位在库里会撞车必然误放行，且实测 8,914 条老证号是「后六位含非数字」形态）· `products.post.ts` 在**归属企业解析之后、写库事务之前**插入校验 · `products/[id].patch.ts` 同口径但**仅当证号发生变化时**校验 · `products/index.vue` 新增「新证豁免」勾选框（`v-if="isPlatformAdmin"`）+ 三处文案。
- **🔴 两条实测逼出来的设计决定**：① **PATCH 无条件校验会锁死存量孤儿产品** —— 本机库里就有 **2 条**证号不在登记库的产品（`id=21 PD20990001` / `id=22 PD20990002`），无条件校验会让它们**连改名字、停用都 400**（实测确认 `body.status` 单独分支在 `:18` 提前 return，不受影响）；② **豁免必须落 `risk_alert(3)` 且必须带 `product_id`** —— `triggerAlert` 的合并键是 `(enterprise_id, code_id, product_id, external_verification_id, alert_type, handle_status)`，`product_id` 为 `null` 会让同企业所有豁免**合并成一条、`evidence` 被逐次覆盖**（N2 踩过同款坑）。⚠️ **附带后果（须知，非 bug）**：证号被改成库里不存在的值后，**改回来也需要豁免**（回退目标同样不在库）。
- **★ N1 实测八例（本机 dev 3100 + 本机库，逐条真跑，证据 `logs/_n1-verify.json` / `_n1-verify2.json`）**：企业账号建档 `PD99999999` → **400 且不落库**（`product` 4→4）· 企业账号带 `regExempt:true` → **仍 400**（豁免只认 `platform_admin`）· 管理员豁免建档 → **200** + `alert_type=3` **0→1**（`product_id=24`、`evidence` 含 `operator:"admin"`）· 正向真实证号（`EX20200001`）→ **200** · 编辑证号不变（孤儿）→ **200**（存量不被锁死）· 编辑改成 `PD99999998` → **400 且库仍是原值** · 编辑+豁免 → **200 + 留痕**（`action:"update"`）· 仅改 `status` → **200**。**清理复核**：`product` 回 **4 行**、`risk_alert(3)` 回 **0 行**、`product 21` 证号已还原、无 `【验证用】` 残留。
  ⚠️ 测试中途 E/F 曾用**企业账号**跑出 `404 产品不存在` —— 那是**租户隔离正常生效**（`id=21` 归属企业 5，`lvfeng` 非该企业账号），换 `platform_admin` 后 E/F 全绿。**不是缺陷**，但下一轮用企业账号测产品接口别再被这个 404 误导。
- **★ 「一键记账」的查证结论（本轮最值钱的发现）**：**后端整条链路早就按「扫码记账」设计好了，唯独少了扫码结果页上的入口** —— `bill-input.ts:122-128` 的 `source` 语义（1 扫码 / 2 手动，带 `code` 时**默认 1**）· `BillFormModal.vue:11` 注释「扫码预填：调用方把 `initial` 传进来即自动带入产品名/类别/追溯码」· `bill-category.ts:4` 注释「类别要供 ① **扫码结果页按产品原始类别自动预填**」· `/bill` 空态文案「扫码后可以顺手把这一笔记下来」· **29 号自己把它列进「本轮明确没做」**（扫码结果页之外的其它结果页记账入口）。⇒ 新增 **`app/components/TraceBillEntry.vue`**（按钮 + 登录说明 + 预填表单三合一）接入 `TraceExternal.vue`。已登录直接开预填表单；未登录先弹说明再**直达微信授权**（不绕 `/profile`），回跳带 `&bill=1` **自动打开表单**。⚠️ 预填只在**唯一候选**时带产品名 —— 后六位撞车（多候选）时预填错了比不预填更糟。
- **★ 「一键举报」**：新增 **`app/components/TraceReport.vue`**，接入 **4 个结果页**（外码 / 异常 `TraceAlert` / 查无此码）。弹窗 = 大号可拨 `tel:12316` 的**全国农业系统公益服务统一热线** + 用户指定原文「**此外，您还可以通过当地农业农村局的官方网站或微信公众号提交举报信息。**」+ 本次追溯码与一键复制。**纯展示、零接口、零 DDL** —— 举报的受理方是农业农村部门，平台收下也无权处理；而每加一个**公众可写接口**都要配套防刷与运营流程（N2 的教训）。另：**举报 ≠ 反馈**（反馈是平台内纠错、落 `risk_alert(7)`），两个入口不可合并。
- **★ 真浏览器验证（CDP + Edge，8 张截图 + 探针断言，证据 `logs/_ui-verify.json` / `_cdp-bill.json`，截图在 `C:\shots\`）**：外码页按钮清单 = `[复制, **记一笔账**, **一键举报**, 返回, 重新扫码, 扫码查询]`；举报弹窗 `hasHotline12316` / `hasSentence`（逐字）/ `telLink`（`a[href="tel:12316"]`）**全 true**；未登录点记账 → 弹「记账需要先登录」+「微信一键登录」；查无此码页、已作废页举报入口在位；**正品页与作废页回归正常**（页头「记一笔」仍在、作废码仍无反馈入口 = 原设计）。**已登录路径**用**自签消费者会话 + `Network.setCookie`** 端到端真验：点「记一笔账」弹出**预填表单**（产品名 `高氯·残杀威` 已带入、日期已填、保存按钮吸底）、`&bill=1` 回跳**自动开表单且 URL 参数已自动清掉**；验完 `consumer` 与 `farm_bill` **均回 0 行**。
- **⚠️ 已知不足（本轮未修，已记 32 号 §6）**：① **外码页预填的类别恒为「其他」** —— 根因是 `TraceRegistryCandidate` 不含 `category` 字段（`pesticide_reg.category` 有列，只是 `/api/trace` 没往外带）；**修法 4 文件**（`registry-lookup.ts` 加字段 → `shared/types/trace.ts` → `trace.get.ts` 映射 → `TraceExternal.vue` 传值），**会动公众扫码路径的输出形状** ⇒ 建议单独一轮做并重验；② **正品页的「记一笔」是页头 `size="xs"` 小按钮**（不显眼），本轮**刻意没动**（不擅自改已上线且已验证的功能）；要统一应把它那份**内联实现**换成 `TraceBillEntry`，否则两套实现必然漂移。
- **★ 上线影响面（本轮未上线）**：**零 DDL / 零新依赖 / 零 `.env` / 零 nginx**；但改了 **3 个服务端 `.ts` + 1 个后台页面 + 新增 2 个组件 + 4 个结果页接入** ⇒ **必须重新 build + `pm2 reload nz315`**，且**上一版包（`39753e3`）已过期须重打**（⚠️ 判包过期必须逐文件比内容，绝不能比 SHA256）。不需要用户重登。
- **★ 本轮新踩 5 条环境坑（已写 32 号 §8）**：① **PowerShell `Remove-Item` 被 safe-delete 垫片接管、对含中文路径必然失败**（`[safe-delete][SAFE_DELETE_FAIL_CLOSED] trash-failed`，报错里路径已 mojibake）⇒ 删文件一律走 **node `fs.unlinkSync`**；② **`git log --format=%H…` 里的 `%` 触发安全策略**（被当成 cmd 的 `%VAR%` 语法，整条拦下）⇒ 用 `--pretty=fuller`；③ **PowerShell 输出中文 mojibake**（UTF-8 字节被按 GBK 解码再编码）⇒ 加 `[Console]::OutputEncoding = UTF8` 或**走 node 落盘**（本轮全程用后者）；④ **`git commit` 传中文 message 有编码风险** ⇒ 用 **`git commit -F <utf8文件> -- <pathspec>`**（实测提交信息正常）；⑤ **`git add -A -- docs/handover`**（用 ASCII 目录规避中文路径，且不会卷进 `docs/厂家后台使用说明/` 与 `scripts/generate-user-guide.mjs` 两个 master 线未跟踪项）。
- **修改文件**：**新增** `app/components/TraceReport.vue` · `app/components/TraceBillEntry.vue` · `docs/handover/32-N1建档校验与公众端两个入口（一键记账·一键举报·2026-09-23）.md`；**修改** `server/utils/regdata.ts` · `server/api/admin/products.post.ts` · `server/api/admin/products/[id].patch.ts` · `app/pages/admin/products/index.vue` · `app/components/TraceExternal.vue` · `app/components/TraceAlert.vue` · `app/components/TraceNotFound.vue` · `AGENTS.md` · `PROJECT_LOG.md` · `docs/handover/31-….md` · `docs/handover/26-….md` · `docs/handover/README.md` · `.workbuddy/memory/2026-09-23.md`。**未改动** `nuxt.config.ts` / `package.json` / `package-lock.json` / `.env`。
### 2026-09-23 | docs+feat：新增 31 号交接手册 · 线上核验二维码包（13 张码 + 10 张真浏览器截图）· 修正三条错误认知
- **结果一句话**：① 产出用户要的「打开新对话用」的交接文档 **`docs/handover/31-交接手册-新对话接续（记账已上线·线上核验码已备·2026-09-23）.md`**（**取代 30 号**：30 号是那次上线的执行总纲，**上线已完成**）；② 产出**线上核验二维码包** `qr-test/online-20260923/`（**26 个文件**：13 张二维码 PNG + 总览页 `index.html` + `manifest.json` + 可再生脚本 `gen-online-verify-qr.mjs` + **10 张 CDP 真浏览器截图**；`qr-test/` 已被 `.gitignore` 忽略，**不入 git**）；③ 过程中**修正了三条会被后人照抄的错误认知**。
- **★ 现状实测（2026-09-23 16:3x，本机现测）**：git = **`ycdb` @ `bd451c8`**（2026-09-23 16:10:59）= master + **64 提交 / 76 文件 / +9,674 −1,023**，**未合入 master、未推送**；工作区 = `.workbuddy/memory/2026-09-23.md` 已改 + 2 个 master 线未跟踪项。公网：构建指纹 **`1790148550717`** = **2026-09-23 15:29:10**（与上线记录一致 ⇒ **未再部署**）· `/` `/trace` `/bill` `/bill/analysis` `/scan` `/profile` **全 200** · `/nearby-stores` **404** / `/api/stores/nearby` **404** · `/api/bill` **401** · `/api/auth/me` `{"user":null}` · 工具 v1.2.0 **200** / v1.1.0 **404** · 裸域名 **301** 保留路径 · 恶意 Origin **403**。
- **🔴 修正 1：24 号 §6.6「演示用的测试码只在开发库，生产库里没有」是错的。** 实测线上 **4 条 seed 演示码全在役**：`12301011001000000000000000001001` → `genuine` · `…1002` → `genuine` · `…0004` → `frozen` · `…0005` → `voided`。⇒ 线上库 = **演示数据**（`trace_code` 7 行 = 这 4 条 + 3 条未知）**+ 真登记资料库**（`pesticide_reg` **97,471** 行）。
- **🔴 修正 2：「登记证过期」在线上没有 `reg-expired` 数据可触发，但可零写入绕过去。** `reg-expired` 要求 `trace_code` **先命中**，而 seed 产品登记证有效期到 **2031** ⇒ 线上无数据。**绕法**：构造**不在 `trace_code`** 的码 ⇒ 走 `lookupRegistryByCode` 登记库兜底，而 `TraceExternal.vue:114-117` 本就有 `single.expired` 的红色横幅 ⇒ 拿登记库里一条 **`expire_date < 今天` 且后六位唯一**的登记证（`PD20111008` 乙羧氟草醚 / 江苏省农药研究所 / 到期 **2026-09-22**）构造外码，线上实测 `external-reg` + `expired=true` ⇒ 页面出「该登记证已于 2026-09-22 到期，持证生产的有效期已过，请勿购买使用」。**一行业务数据都没往线上写**（外码分支纯只读：不写 `scan_log`、不触发预警）。
- **🔴 修正 3：公众端「内容与登记库不符」的反馈入口其实已可用。** AGENTS.md 把「公众端『产品内容不符』提示位」列为未做的 P2 —— **实测该入口存在且可用**：正品页/冻结页底部「信息与包装标签不一致？点此反馈」可点开，是**完整表单**（反馈内容 10–500 字 + 字数计数器 + 联系方式选填 + 取消/提交），**非 stub**（N2 修复确已上线生效）。仍未做的只是「扫码时**自动**比对内容」的**主动**提示位（架构上拿不到另一侧内容，28 号已论证）。
- **★ 外码构造公式（可复用）**：`类别位(1=PD / 2=WP) + 登记证号后六位 + 生产类型位(1/2/3) + 21 个 0 + 3 位序号 = 32 位`。⚠️ 登记库兜底**只看 `validLength && validCategory && registrationLast6`，不看第 8 位**（第 8 位=9 非法照样命中，实测 `10929279…` → `external-reg`）⇒「结构部分非法」与「登记库命中」可并存。⚠️ `regCategoryOf`：**PD/PDN/LS/EX 都算 1**，只有 **WP/WL/WPN 算 2**；类别过滤会正确排除撞车的另一类（实测后六位 `040008` 的 5 条候选中 `WP20040008` 被排除、页面列 4 条）。
- **★ 13 张码全部线上实测通过**：A1–A4（`genuine`×2 / `frozen` / `voided`）· B1 登记证已过期 · B2 登记证有效（对照）· B3 WP 类过期 · B4 结构合规但登记库无此证 · B5 类别位非法 · B6 生产类型位非法但命中 · B7 委托加工 · B8 后六位撞车多候选 · C1 位数不足。
- **⚠️ 唯一线上测不了的分支**：`repeat`（重复查询）—— 判据是「同一码 ≥3 次 **且** `DISTINCT province ≥2`」，省份来自扫码 IP 定位，**一台设备/一个网络只会是同一个省**；需不同网络的手机分别扫同一张码。
- **⚠️ `/api/stats` 两个数字的读法（避免被误判成故障）**：`totalQueries` **28 → 43** = **本轮核验扫码写进去的 `scan_log` 行**（正常业务行为）；`abnormalClues = 1` = **N3 巡检**写的那条 `risk_alert(alert_type=6)`。**两者都是预期内。**
- **★ 本轮踩到的三条环境/工具坑（已写进 31 号 §5.1）**：① **Bash 工具整体报废**（`dirname` / `ls` / `head` 全不存在）⇒ 只能走 PowerShell + 专用工具；② 🔴 **CDP 截图并行多开必失败**（报 `ERR CDP 端口未就绪`，4 个实例各用不同端口 9334–9337 全失败）⇒ **必须串行**（默认端口 9333）；③ **依赖分散在三处 `node_modules`**（`@zxing/library` 在项目、`qrcode` 在隔离工作区、`pngjs` 挂在 `qrcode/node_modules` 下）⇒ 临时脚本 `load()` **必须多基路径兜底**。
- **修改文件**：**新增** `docs/handover/31-交接手册-新对话接续（记账已上线·线上核验码已备·2026-09-23）.md`；**修改** `AGENTS.md`（接手指针改指 31 号 + 三条认知修正）· `docs/handover/README.md`（顺序表与文件清单补 31 号）· `PROJECT_LOG.md` · `.workbuddy/memory/2026-09-23.md`。**产物（不入 git）**：`qr-test/online-20260923/` 26 个文件。**线上侧零变更**（未部署、未改代码、未动 DDL/依赖/nginx/`.env`）。
### 2026-09-23 | deploy：「农资记账」上线完成（含「附近门店」彻底下线 · N3 计划任务补齐 · 部署标记补齐）
- **结果一句话**：按 30 号总纲把「农资记账」推上线，**9 步全绿**。线上基线 `a573f09` → **`39753e3`**，构建指纹 **`1790148550717` = 2026-09-23 15:29:10**。**同时补齐了上一轮漏掉的两件事**：N3 每日 03:00 巡检计划任务（此前**从没加过**）、服务器 `.deploy-version`（此前**停在 09-19**）。
- **★ 上线现场证据（服务器实测 + 本机公网复核）**：`sha256sum` = `40ff6745…a14b14` / 671,250 B（与 v2 包逐字符一致）· 备份 `TS=20260923-150643`（`src.tar.gz` 846,547 B · `db-nz315.sql.gz` 3,661,586 B 且 **`-- Dump completed on 2026-09-23 15:06:44`**）· `--migrate-only` 后 `farm_bill` **存在 / 16 列 / 0 行 / 2 索引**、`total_tables = 16`、`trace_code_rows = 7`（**与迁移前基线一致 ⇒ 零写入**）· `npm install` up-to-date → `npm run build` **`✨ Build complete!`**（15:29:37）→ `pm2 reload nz315` · **公网**：`/bill` **200** / `/api/bill` **401** / `/bill/analysis` **200** · `/nearby-stores` **404** / `/api/stores/nearby` **404**（门店彻底下线）· 首页含「账本」、**无**「附近门店」、**无** `128630` · 首页 25 个 `/_nuxt/*` 抽查 8 个**全 200** · `external-reg`、恶意 Origin **403**、工具包 200/`95,035,957`、裸域名 **301** 全部未回归。
- **★ N3 计划任务（第 7 步）**：dry-run 待写入 **1 条**（类型 6「生产厂家不符」）⇒ 宝塔「计划任务」加「**每天 03:00** + `/usr/local/node22/bin/node … --apply >> /www/wwwlogs/nz315-inspect.log 2>&1`」并**点该行「执行」实测跑通**（`risk_alert` 出现 `alert_type=6` **1 行**：`id=1` / `handle_status=0` / `evidence.source=daily-inspection`）⇒ 复跑「**待写入 0 条**」= 30 天冷却幂等成立。**顺带证明 N3 在真实数据上确实能检出问题**：产品 #1 的登记证持有人与**国家登记资料库**记载的厂家不一致。
- **🔴 修掉执行单两处真实缺口（现场才暴露，均已回写 24 号）**：① **`tar xzf` 不会删除「包里没有、服务器上还在」的文件** ⇒ 24 号第 3 步原**只有解包、没有删除动作**，照做会让门店模块（页面 + 匿名 POI 接口）继续在线（且 `/nearby-stores` 会因引用已删的 `amapJsKey` 而打开即坏）；已补 **§3.0 删除小节**。**通用自检法**：把 `git diff --name-status <旧基线>..<包基线>` 里所有 **`D` 开头的路径**当「反向清单」，逐个确认执行单有对应删除动作。② **`mv .output .output.bak-<TS>` 会【当场】打断静态资源** —— Nitro(node-server) 的 `/_nuxt/*.js|css` 是**运行期读盘**，而 `/` 与 `/trace` 仍是 200（SSR 在内存）⇒ 现象极具迷惑性（**页面有字、没样式没交互**、`/tools/*.exe` 500）。本次窗口 **15:06 → 15:29（23 分钟）** ⇒ **铁律：需要停顿判断的步骤（备份、迁移判据核对）一律放在 `mv` 之前，`mv` 之后一路跑到 build 结束。**
- **★ 三条判据陷阱（都已写进文档）**：① **`/api/bill` 返回 401 不能证明 `farm_bill` 存在** —— `requireConsumer` 鉴权跑在查库**之前** ⇒ 表没建也是 401 而不是 500，**必须回库查**（本次实测 16 列 / 0 行才证实）；② **`enterprise` 里出现「山东绿丰生物科技有限公司」不是污染** —— 那是建库时 `seed()` 落的**演示企业**（`db-init.mjs:460`），**从迁移前到迁移后一直是 1 行**（11:25 三明治的明细快照全 OK 即证），判据应是「**行数仍是 1 且内容不变**」（24 号 §6.7 原文那句"不该多出"有歧义，已修）；且 `seed()` 是"存在即复用"，**光看企业行数根本区分不出有没有误 seed**；③ **N3 第一次 `--apply` 显示「待写入 0 条」≠ 失败** —— 只要此前有人跑过一次（本次是**面板点「执行」**），冷却期就会把它挡住；真判据是**查库看 `alert_type=6` 有没有行**。
- **★ 收尾文档同步**：`30-交接手册` 顶部新增「**✅ 本轮上线已完成**」块（9 步实测表 + 线上基线 + 两处缺口 + 遗留清单）、§0 开场白标**已作废**并在最前给出新开场白（旧版折叠留档）、§1 末尾「两件查不到的事」改为**已查清并解决**；`AGENTS.md` 状态指针顶部插「已上线」块并标注原 (1)(2)(4)(5) 作废；`.workbuddy/memory/MEMORY.md` 状态块改写（另：高德 key 那条改为「**现仅 `ip-geo` 一个调用方**」）；`24-部署执行单` 的 §6.7 / §7.3 / §8 三处修正。
- **★ 仍未做（下一轮，别顺手做）**：服务器 `/var/www/nz315/` 下早年残留的 `docs/handover` + `.workbuddy`（**公网实测全 404、不构成泄露**，择期删）· `.output.bak-*` 已堆到 **3 个**（磁盘约 75%）· **N1 建档不校验登记证号** · **P2 公众端「产品内容不符」提示位** · **数据治理（线上仍是演示企业/产品/批次/码）** · `tsc` 类型检查（项目无 `vue-tsc`、无 typecheck 脚本）。
- **修改文件**：`docs/handover/24-部署执行单-ycdb整线上线.md` · `docs/handover/30-交接手册-上线记账功能（2026-09-23）.md` · `AGENTS.md` · `PROJECT_LOG.md` · `.workbuddy/memory/2026-09-23.md` · `.workbuddy/memory/MEMORY.md`。**线上侧零 DDL 变更（本次迁移只建 `farm_bill`）/ 零依赖 / 零 nginx / 零 `.env`。**
### 2026-09-23 | fix+docs：确认上一轮上线已完成 · 三明治白名单补 farm_bill · 重打 v2 包 · 新增 30 号上线交接手册
- **结果一句话**：用户告知「上一次上线已经完毕」并要一份用于打开新对话的交接文档。**没有直接写文档，先做 13 项公网实测定位线上版本** ⇒ 确认线上 = `a573f09`（N2–N6 / P1-1 / 外码核验 / `external-reg` / 上限 50 万**全部已生效**），**独缺记账功能** ⇒ 本次上线面 = `a573f09..HEAD` = **34 文件 / +2,690 −1,037**（其中 27 条是运行代码/配置：12 新增 / 5 删除 / 10 修改）。产出 **`docs/handover/30-交接手册-上线记账功能（2026-09-23）.md`**（本次上线总纲）+ **v2 上线包**。
- **★ 现状实测（2026-09-23 14:40，本机直连公网）**：构建指纹 `1790135393647` = **2026-09-23 11:49:53（东八区）**（新于 09-19 ⇒ 上一轮上线确实完成）· `/api/stats` → `{"totalQueries":28,"abnormalClues":0}`（**N5 真数已生效**，旧版是伪造 `128630/42`）· `/api/stores/nearby?lng=999&lat=999` → `200 {"located":false,"rows":[]}`（**N6② 短路已生效**，且说明**门店模块还在线上**）· `/trace?code=10929272…0` → `200` / 34,930 B 含「不是农资315签发」+`PD20092927`（**`external-reg` 已生效**）· 恶意前缀 Origin → **403** · 同站 Origin → `401` · `HEAD v1.2.0.exe` → `200`/`95,035,957`、`v1.1.0.exe` → `404` · `https://nz315.cn/abc?x=1` → `301` 保留路径。**未上线侧**：`/api/bill` → **404** · `/bill` → **404** · 首页含「账本」= **false** · `/nearby-stores` → **200** · 首页含「附近门店」= **true**。
- **🔴 修了一个会当场误导上线的人**：v1 包（`f3c43e0`）里的 `scripts/verify-db-migration.mjs`，`EXPECTED_NEW_TABLES` **只登记了 `external_verification`** ⇒ 本次三明治第 ③ 步**必然**把新表 `farm_bill` 报成 `FAIL 出现了基线中不存在、且不在预期白名单里的新表: farm_bill`（**假 FAIL、退出码 1**），而真正该看的「新表 0 行」判据反被这条红字盖住。**处置**：`farm_bill` 同时加进 **`EXPECTED_NEW_TABLES`**（新表必须存在且 **0 行**）与 **`ACTIVE_TABLES`**（上线后消费者记账会正常写行，**不该算污染** —— 与 `scan_log`/`operation_log`/`external_verification` 同族）。提交 **`39753e3`**。
- **★ 四分支实测（真跑，非推断）**：① 白名单内新表**非空**（实测 5 行）→ **FAIL 并报出行数** ✅；② 白名单内新表**为 0** → **`OK 新表 farm_bill 0`、退出码 0** ✅；③ 白名单**之外**建表 `zz_probe_new` → **FAIL「不在预期白名单里」** ✅（证明白名单不能被绕过）；④ 窗口期增长（基线 0 → 现 2 行）→ **不计 FAIL**，输出「↑ 窗口期内的真实业务写入：farm_bill +2」✅。测完探针表/行全部清掉、被改过的基线文件也删掉。
- **🔴 顺手抓到自己一条假记录（值得留档）**：上一轮我在 `.workbuddy/memory/2026-09-23.md` 里写过「验收数据已清干净（`farm_bill` 回空表）」—— **实测 `farm_bill` 还剩 5 行、`consumer` 还剩 2 个测试账号**（`dev_bill_test_a` / `dev_bill_test_b`），**当时根本没清**。⇒ 本轮**先备份**（`logs/_t-bill-testdata-backup.json`）**再补清**，复核 `farm_bill = 0` / `consumer = 0`；日志里**就地更正**并写下教训：**「已经清理过了」属于必须实测的断言**，不能凭"我做过"写进记忆文件，否则下一个人会据此跳过校验。
- **★ v2 包（自验 PASS）**：`E:\software\workbuddy\文件存放处\2026-09-23-1442-ycdb记账版上线包v2\nz315-ycdb-39753e3.tar.gz` = **671,250 B** / SHA256 `40ff67453d5ce79c8f37e4a0d0d97f5132eb066e17a84e93b845bd946fa14b14` / **168 文件 + 55 目录**（跟踪 209 − `export-ignore` 41）。自验 **多出 0 / 缺失 0 / 泄漏 0 / 违规 0**，37 个关键文件逐个点名在位，包内无真 `.env`。**三个作废包全部移入 `_作废包-勿传（已过期）\`**：`a573f09`（**线上正在跑的那版**）、`1c6730a`、`f3c43e0`（v1）⇒ 交付目录里**只剩一个可用的 ycdb 包**。
- **★ 30 号交接手册（用户要的交付物）**：开场白（可直接粘贴）→ **现状 13 项实测表** → 变更面（六块 + 影响面）→ **v2 包指纹三件套**（含「为什么是 v2」）→ **9 步总纲（每步都写明"何时停手贴我"）** → **10 条 before/after 验收判据** → **8 条铁律** → 踩坑速查表 → 已知缺口/待决 → 文档索引。其中 P1-1 的验收**被迫换判据**（门店接口已删 ⇒ 改成"新扫一次码后看 `scan_log.province` 有没有值"）。
- **同步改动的文档**：`24-部署执行单`（文首新增「**14:50 现场更新：上一轮上线已完成**」+ 执行顺序块 + R2 说明「本次只需建 `farm_bill`」；全文旧指纹批量换为 v2）· `29-…方案` §11.5（白名单已修 ⇒ 判据由"预期 FAIL"改为"应 `OK 新表 farm_bill 0`"）· `AGENTS.md` 状态指针（**改指 30 号**，并把「上线停在半路」的两句改写成"上一轮已完成 / 本次只推记账"）· `docs/handover/README.md` 索引（补 28/29/30）· `.workbuddy/memory/2026-09-23.md` · 本条目。
- **★ 本次未做/未验**：① `tsc` 类型检查**仍未跑**（项目无 `vue-tsc`、无 typecheck 脚本）；② 真实微信授权跳转未跑；③ **两件本机查不到、需用户在宝塔确认**的事已写进 30 号 §1 末尾 —— 上一轮的 **N3 每日 03:00 计划任务**是否真加了、服务器 `.deploy-version` 是否写成 `a573f09`。
- **修改文件**：**新增** `docs/handover/30-交接手册-上线记账功能（2026-09-23）.md`；**修改** `scripts/verify-db-migration.mjs`（白名单补 `farm_bill`）· `docs/handover/24-部署执行单-ycdb整线上线.md` · `docs/handover/29-农资记账功能方案（2026-09-23）.md` · `docs/handover/README.md` · `AGENTS.md` · 本条目 · `.workbuddy/memory/2026-09-23.md`。**零 DDL 变更 / 零依赖 / 零 nginx / 零 `.env`**（脚本改动只影响部署期的校验工具，不影响运行代码）。
### 2026-09-23 | feat：农资记账 —— 下线「附近门店」，原地换成账本（档案页）+ 成本分析
- **结果一句话**：按用户需求把公众端「附近门店」**整体删除**（页面/地图组件/高德 JS 加载器/坐标纠偏/POI 接口共 5 个文件），同一位置换成一套**农资记账**能力：扫码结果页右上角「记一笔」→ 账本页（= 档案页，4 张成本卡 + 按月分组 + 月小计 + 年总计）→ 成本分析页（本月/本季/本年 + 12 个月柱状图 + 类别环形图 + 作物维度）。方案见 **`docs/handover/29-农资记账功能方案（2026-09-23）.md`**（口径、DDL、接口、验收清单、实施记录全在里面）。**带 DDL（新增 1 张表）· 零新依赖 · 零 nginx · 零新增 `.env` 变量**。
- **★ 用户四项裁定（开问前先问清，避免返工）**：① 账本页 = **删掉附近门店页原地改**（底栏变成 首页/扫码/账本/我的，`/profile` 不动）；② 未登录点「记一笔」→ **弹窗提示 → 强制跳「我的」做微信登录**（**明确否决**"本地暂存后合并"，理由：换机就丢还要处理冲突）；③ 附近门店**彻底删除**（不是只摘入口）；④ 作物与渠道**纯自由输入、可为空**（不设枚举，避免"柑橘/柑桔/橘子"统计散架的问题由用户自己承担 —— 这是用户明确选择）。
- **★ 数据模型（本轮唯一 DDL）**：新表 `farm_bill`（16 列），归属键只有 `consumer_id`（消费者私人数据，**后台/厂家看不到**）；`product_name` 存**快照**（产品改名不影响历史账目）；`code` 只做来源标记、**刻意不做外键**（手动记账无码，且扫到的码可能非本平台签发）。
- **★ 统计口径（三条，写死在接口注释里）**：**用药 = 总 − 用肥**（不是各自 SUM —— 保证「用药 + 用肥 === 总花费」恒成立）；用肥 = `category='肥料'`；覆盖作物 = `COUNT(DISTINCT crop)` 排除空值。另：**`category` 落库恒为 6 类白名单之一**（空 → `其他`），库里不存 NULL ⇒ 饼图固定 6 分区、"不选类别"不会让统计多出一个分支。
- **★ 实测证据（全部本机真跑，24 项状态码逐条核对）**：未登录 401 ✅ · 仅填产品名（**"可跳过补录"**）200 且 `total_amount=0` ✅ · 总额≠数量×单价（950）**落库 950**（采信用户手工调整的总金额）✅ · 总额缺失兜底算出 `3×25=75` ✅ · 未来日期/缺产品名/负单价 400 ✅ · 乱类别归一化为「其他」、脏追溯码落 NULL（**都不 400**，不因为一个脏字段把整条账单打回）✅ · 年度账本 **用药155 + 用肥950 = 1105 = 总花费**（恒等式成立）✅ · 年份参数非法回落当年不 500 ✅ · 编辑类别「杀虫剂」落库归一化「杀虫」✅ · 🔴 **越权改/删他人账单均 404，且查库确认对方记录未被改动**（`123.45` 原封不动）✅。
- **★ 页面实测**：带真实消费者 Cookie 抓 SSR —— `/bill` 渲染出 4 张卡 + 分组 + 月小计 + 年总计，页面金额 `225.00/950.00/1175.00` 与库内聚合 **1175.00 完全一致**；`/bill/analysis` 三切换 + 三区块齐全；**`/nearby-stores` → 404** ✅；首页导航含「账本」、不含「附近门店/附近农资店」。
- **★ 真浏览器验证（CDP + 移动视口 390×844，6 张截图逐张目视）**：账单页（金额全红、编辑/删除图标、月小计、年总计）· 分析页（柱状图/环形图/作物条形）· 记一笔弹窗 · 扫码结果页（右上角「记一笔」按钮数 = 1）。**这一步抓出两个真问题**：① 弹窗表单长，**「保存」被推出屏幕**（断言 `inViewport:false`）⇒ 改成「头部固定 / 表单滚动 / **按钮吸底**」，复验 `inViewport:true`；② 柱状图纵轴原按"下一个 10 的幂"取整 ⇒ 1175 被抬到 2000 刻度、柱子只占 59% 高度（看着像"没画满"）⇒ 改成细档位 `1/1.2/1.5/2/…`，1175 取 1200（柱高 97%）。
- **★ 6 处相对方案的修正（方案初稿有 3 处是错的，均已改并回写文档）**：① `category` 恒为 6 类之一（初稿"可空"会让饼图裂出第 7 分区）；② 用药 = 总 − 用肥；③ **`totalAmount` 优先采信前端**（初稿写"不信任前端算出来的数"，与用户"可以调整总金额"的需求**直接冲突**）；④ 新增 **`localToday()` 兜底** —— 若 `CURDATE()` 取不到，`today=''` 会让日期校验把**所有**请求判成"未来日期" ⇒ **记账全量 400**，这类故障极难排查，故在 `parseBillBody` 与 `analysis` 两处统一收口；⑤ 弹窗吸底；⑥ 柱状图档位。
- **★ 下线连带收益（免费的安全加固）**：POI 调用彻底消失 ⇒ `AMAP_WEB_KEY` 只剩 `ip-geo` 一个调用方 ⇒ **原先"POI 配额被刷爆会连带绞杀 `scan_log.province` 写入"的 P1-1 死穴被物理消除**（比原计划"拆 key"更彻底）⇒ **26 号的 N6④（拆 key）与 N6-b（搜索框）两条缺陷随之关闭**，不再是技术债。顺带发现 `.env.example` **从未登记 `AMAP_WEB_KEY`**（而 `ip-geo` 依赖它）⇒ 已补上；服务器 `.env` 里残留的 `NUXT_PUBLIC_AMAP_JS_KEY` 变成无害死变量，不必特意清。
- **★ 上线影响面**：① **带 DDL（新表）⇒ 上线必须走 `node scripts/db-init.mjs --migrate-only` 三明治**（已核：该参数**会执行 DDL 循环**，只跳过 seed，故新表能自动建出）；② 需 build + `pm2 reload nz315`；③ 不要求用户重登；④ 🔴 **现有上线包 `nz315-ycdb-a573f09.tar.gz`（655,237 B）已作废** —— 本轮动了运行代码 ⇒ **必须重打**，24 号执行单流程不变、只改包指纹。
- **★ 本轮明确没做 / 没验**：① **生产构建（`npm run build`）与类型检查未执行** —— 本机 dev server 一直在跑，构建会清 `.nuxt` 与 dev 冲突（项目惯例：构建前先停 dev），故 29 号 §7 的"build 通过"**仍待办**；② 真实微信授权跳转未跑（本机无微信环境，用**同算法手工签发的消费者会话**替代，覆盖了鉴权/归属/越权）；③ 功能范围外刻意不做：账单导出、预算预警、多人共享账本、后台侧账单查看、"扫码结果页之外的其它结果页（外部码/异常页）记账入口"（最小闭环，可按需扩展）。
- **★ GitHub 调研结论（用户要求先看）**：翻了 `green-chitian-vue-ui`（农户化肥农药施用记录 + 按月/季/年统计，Vue+Vant+ECharts）、`Land-degradation-pesticide-control`（月度用量柱状图 + 超量预警）、`Denisganga/Farm_Management_System`（费用字段设计：供应商/支付方式/单价×数量自动算总额）、`farmOS`/`LiteFarm`/`Tania`。**结论：借鉴维度设计，不借代码** —— 它们全是 Django/Go/Ruby 的**管理端 Web**，没有"扫码→记账"链路、没有微信授权，与本项目"消费者→产品"的数据模型不同构；自建 5 接口 + 3 页面 + 2 个 SVG 组件成本更低（**不为 1 柱 1 环引入 ECharts**）。
- **修改文件**：**新增** `shared/utils/bill-category.ts` · `server/utils/bill-input.ts` · `server/api/bill.get.ts` · `server/api/bill.post.ts` · `server/api/bill/[id].patch.ts` · `server/api/bill/[id].delete.ts` · `server/api/bill/analysis.get.ts` · `app/pages/bill/index.vue` · `app/pages/bill/analysis.vue` · `app/components/BillFormModal.vue` · `app/components/BillBarChart.vue` · `app/components/BillPieChart.vue` · `docs/handover/29-….md`；**修改** `scripts/db-init.mjs` · `app/components/TraceResult.vue` · `app/components/PageHeader.vue`（右侧容器 `w-12` → `min-w-12`，容纳两个按钮）· `app/components/BottomNav.vue` · `app/components/AppHeader.vue` · `nuxt.config.ts` · `.env.example` · `server/utils/rate-limit.ts` · `server/utils/ip-geo.ts` · 本条目 · `.workbuddy/memory/…`；**删除** `app/pages/nearby-stores.vue` · `app/components/StoreMap.vue` · `app/composables/useAmapLoader.ts` · `app/composables/useGeoConvert.ts` · `server/api/stores/nearby.get.ts`。**带 DDL（`farm_bill` 新表）⇒ 上线需 `--migrate-only`；需 build + reload。**
### 2026-09-23 | docs：N2–N6 实施记录（28 号）+ 同步 AGENTS/ 状态指针（🔴 上线包已过期须重打）
- **结果一句话**：新增 `docs/handover/28-N2至N6实施记录（五条已修·待重打包上线·2026-09-23）.md`，作为 27 号方案的**执行结果**留档；同步重写 `AGENTS.md` 顶部指针与「项目进度」段。**本轮零运行代码改动**（5 个代码提交已在前置条目里各自记录）。
- **★ 28 号写了什么**：五条提交清单（N5 `27f1514` · N6 `18b40f5` · N4 `5a59478` · N2 `d1dbf78` · N3 `d38ba0a`，含哪条需 build）· 逐条实测证据（首页统计 `128630/42`→`213/12`、非法坐标 38ms 短路且不再烧高德、连打 40 次第 27 次 429、过期产品精确 400 且未过期不误拦、反馈四态 + 同码/IP 双限流 + 真浏览器三条页面、巡检连跑两次 apply 幂等）· **实施时相对 27 号改动的 3 处**（N4 拦截点前移避免孤儿批次 / N2 限流后移到入参校验之后 / N2 改按 `code` 字符串合并）· 上线须知 · **本轮没做的**（N1 / N7 / N6④ / N6-b / N3 类型 5，各带原因）· 顺带发现。
- **🔴 最要紧的一条（本条目存在的主要理由）**：原先备好的 `nz315-ycdb-1c6730a.tar.gz`（875,337 B / SHA256 `5b6649c5…92495`）**只到 `1c6730a`，不含本轮这 5 个提交（其中 4 个改动运行代码）** ⇒ **照它部署等于本轮白干**。⇒ **必须先以当前 `ycdb` HEAD 重新 `git archive` 打包，并同步更新 24 号执行单里的包指纹**（建议顺手加 `.gitattributes` 的 `export-ignore` 把 `.workbuddy/memory/` 与 `docs/handover/` 排除出包）。原先「旧包仍可用」的结论作废 —— 它的前提是「`1c6730a` 之后只有纯文档提交」，**本轮打破了这个前提**。
- **★ 上线后额外一件事**：到宝塔「计划任务」加 **N3 的每日 03:00 巡检**（`/usr/local/node22/bin/node /www/wwwroot/nz315/scripts/inspect-daily.mjs --apply >> /www/wwwlogs/nz315-inspect.log 2>&1`，**首次先不加 `--apply` 看量**）。脚本随包上传即可、**不参与 build**。
- **★ 顺带发现（未处理）**：`deploy/nginx-nz315.conf` 的 `proxy_pass` 指向 `127.0.0.1:3000`，而 nz315 跑在 **3100**、**3000 是 cynx** ⇒ **照这份仓库模板部署会把 nz315 流量打到 cynx 上**（线上目前是通的 ⇒ 服务器实际配置与仓库这份不一致，应是部署时手工改过）。建议下次上服务器时 `nginx -T | grep -A2 nz315` 核对，并把仓库模板同步改成 3100。
- **★ AGENTS.md 同步了 5 处**：① 顶部指针改指 28 号（并标注 25 号标题里的「上线包已备」**已被推翻**）；② 27 号条目由「方案未执行」改为「**已全部执行**」并补记用户四项裁定；③ 归属判定法补上「**该名单会漂移（7→15 个文件）**」与「**已修 ≠ 已上线**」两条；④ 分支规模改为实测值（`28387c2` = master + 41 提交 / 52 文件 / +6,430 −138）；⑤ 上线包块整体改写为「**已过期须重打**」。**「项目进度」段**补一条 N2–N6 完整条目、标题日期改 2026-09-23；**「踩坑记录」表**新增 4 行（已修≠已上线 / CDP 点击须等 hydration / `ui-shot.js --js-file` 是表达式 / 同文件 Edit 不可并行 + `node --check` 不查未声明引用）。
- **修改文件**：**新增** `docs/handover/28-….md` · **修改** `AGENTS.md` · `PROJECT_LOG.md`。**零 DDL / 零依赖 / 零 nginx / 零 `.env`**。
### 2026-09-23 | feat：N3 —— 每日定时巡检脚本（PRD 8 类异常 3/4/6 首次拥有触发路径）
- **结果一句话**：新增 `scripts/inspect-daily.mjs`。此前**「每日定时巡检」机制整体不存在**（全仓库无 cron / setInterval），`triggerAlert` 全项目仅 3 处调用点 ⇒ **类型 3（登记证号不存在）与类型 6（生产厂家不符）没有任何触发路径**；类型 4 只在"有人扫码时"触发 ⇒ **没人扫就永远发现不了过期产品**（而巡检的意义正是"不依赖扫码"）。**零 DDL / 零依赖 / 零 nginx / 零 `.env` / 不需要 build**。
- **★ 本机实测（dry-run + 连跑两次 apply）**：
  | 步骤 | 结果 |
  |---|---|
  | `node scripts/inspect-daily.mjs`（默认 dry-run） | 命中 4 条（类型3×2 / 类型4×1 / 类型6×1），冷却期内跳过 1 条，**未写任何数据** ✅ |
  | 第一次 `--apply` | 写入 3 条（`risk_alert.id = 19/20/21`，全部 inserted）✅ |
  | 第二次 `--apply` | **冷却期内跳过 4 条、待写入 0 条、数据库未变更** ⇒ **幂等** ✅ |
  （顺带把本机「产品 #1 的登记持有人 `山东绿丰生物科技有限公司` vs 登记库 `东莞市瑞德丰生物科技有限公司`」这条**真实不一致**验了出来 —— 说明类型 6 的比对确实在工作。）
- **★ 三条硬约束（写进文件头）**：① 🔴 **刻意不设 `DB_HOST` 本机白名单** —— 与造数脚本 `seed-abnormal-demo.mjs` 的取向**相反**（线上服务端 `DB_HOST` 正是 `127.0.0.1`，设了白名单等于永远跑不起来），它的安全闸是**「默认 dry-run、必须显式 `--apply`」**；② **只读业务表 + 只写 `risk_alert`** —— 绝不改 `product` / `trace_code`、绝不自动作废任何码；③ **30 天冷却**：`triggerAlert` 对"已处理"的会新建 ⇒ 每天巡检会让 `risk_alert` 随天数线性膨胀，故同一 `product_id + alert_type` 在 N 天内已有记录（**无论处理状态**）就跳过（`--days` 可调）。
- **★ 首版不做类型 5（产品名称不符）**：按用户 D-3 决策 —— P1-5 已证该口径（`normalizeProductName` 只剥 `\d+%`）会误报，一次性灌入大量假预警；等口径定了再加。
- **★ 两个刻意的设计选择**：① **默认不发站内信**（需 `--notify`）：实时扫码预警才该即时打扰企业，巡检是"后台可见的记录"，且**首跑会一次性产生一批历史预警**，全发等于给企业倒垃圾消息；② **类型 6 的比对放在 JS 侧做**（SQL 无法复用 `normalizeOrgName` 的规则，写了必然漂移）⇒ 脚本内**内联**了同款实现，并在注释里标明「与 `server/utils/regdata.ts` 保持同步，改一处务必改另一处」。
- **★ 巡检用的是登记库快照**：`pesticide_reg` 是静态导入表 ⇒ 类型 3 命中**也可能是"登记库该更新了"，不一定是企业造假**，文案里已带上这个可能（与公众端 `not-found` 分支的"多种可能原因"同一思路）。
- **★ 服务器部署（不参与 build）**：脚本随上线包落到 `/www/wwwroot/nz315/scripts/`，宝塔「计划任务」加一条 **每天 03:00**：
  `/usr/local/node22/bin/node /www/wwwroot/nz315/scripts/inspect-daily.mjs --apply >> /www/wwwlogs/nz315-inspect.log 2>&1`
  ⚠️ **必须用 `/usr/local/node22/bin/node` 绝对路径**（系统 `node` 是 v20、cynx 在用那套；与 PM2 per-app interpreter 保持同一解释器最稳）。⚠️ **首跑前先 dry-run 看量**（线上有多少"过期登记证 / 证号缺失"的产品），量很大时先决定是"全量落库"还是"只记日志不上预警"。
- **修改文件**：**新增** `scripts/inspect-daily.mjs` · 本条目。**零 DDL / 零依赖 / 零 nginx / 零 `.env`**；**不需要 build / reload**。

### 2026-09-23 | feat：N2 —— 公众端「信息有误，点此反馈」入口真正可用（复用 risk_alert，零 DDL）
- **结果一句话**：新增公众可写接口 `POST /api/feedback` + 新组件 `app/components/TraceFeedback.vue`，把反馈入口接到**正品页与异常页**。此前 `TraceAlert.vue` 的按钮门设在 `resultType === 'mismatch'`（而 `trace.get.ts` **从不产出**该值）⇒ 入口永不出现；且就算出现，点开只弹「信息反馈功能建设中，敬请期待」。**零 DDL / 零依赖 / 零 env**。
- **★ 端到端验收（本机 3100 真打，全部实测）**：
  | 场景 | 结果 |
  |---|---|
  | 码位数不足（31 位） | 400「追溯码格式不正确」✅ |
  | 内容过短（<10 字） | 400「反馈内容请填写 10–500 字」✅ |
  | 合法提交 | 200 `{"ok":true}`，落 `risk_alert(alert_type=7)`，evidence 含 `source / resultType / content / contact / scanTime / ip` ✅ |
  | 同码 5 分钟内重复 | 429「该追溯码刚提交过反馈，请稍后再试」✅ |
  | 合法提交 6 次（不同码） | 前 5 次 200、**第 6 次 429**「反馈提交过于频繁」✅ |
  | 页面层 SSR 断言 | 正品页 **有**入口 ✅ / 登记证过期页 **有**入口 ✅ / **作废页无入口** ✅ |
- **★ 真浏览器验证（按项目铁律，UI 变更必须真浏览器点一遍；`ui-shot.js` + CDP 探针实测三条）**：
  | 页面 | 结果 |
  |---|---|
  | 正品页（genuine） | 入口「信息与包装标签不一致？点此反馈」可见；点击 → `[role="dialog"]` + `[data-slot="overlay"]` 出现、弹窗含 1 个 `textarea`；组件实例 `open=true` ✅ |
  | 登记证过期页（reg-expired） | 入口「信息有误，点此反馈」可见；点击 → 弹窗打开、含 textarea、**空内容时「提交」按钮 `disabled=true`**（前端校验生效）✅ |
  | 作废页（voided） | 页面上只有「复制」「返回」两个按钮，**无反馈入口** ✅ |
- **★ 验证手法踩坑（两次假阴性后才定位，值得记）**：CDP `Runtime.evaluate` 里 `el.click()` **必须在 hydration 完成后才有效** —— 过早点击会落在「Vue 事件监听还没挂上」的按钮上，**静默无效果、无任何报错**（DOM 无变化、`console.error` 干净），极易被误判成「弹窗打不开 / 组件写错了」。可靠判据**不是等固定时长，而是等目标按钮已挂到对应组件实例**（`btn.__vueParentComponent` 向上找到 `type.__name === 'TraceFeedback'`）。另：`ui-shot.js` 的 `--js-file` 是把文件内容**当表达式直接执行**（`Runtime.evaluate({expression})`）⇒ **不能有顶层 `return` / `await`**，必须写成 `(async () => { … })()` IIFE，否则 SyntaxError 被静默吞掉（连 `JS>` 都不打印）。
- **★ 实施中发现并修正的两个问题（都不是照抄 27 号方案）**：
  1. **限流位置错了**：27 号把限流写在 Handler 最前 ⇒ 实测发现**连续几次 400 校验失败也会吃掉「5 次/小时」额度**，用户还没成功提交过一次就被锁 1 小时。⇒ 改为**放在入参校验之后**（400 路径**无任何副作用** —— 不落库、不发站内信、不打外部调用，不需要限流保护），并复验「连续 6 次校验失败全部 400 且额度未被消耗」✅。
  2. 🔴 **`triggerAlert` 的合并键对非本平台码是错的**：它的合并条件是 `code_id <=> ?`，而**非本平台码的 `code_id` / `product_id` 恒为 NULL** ⇒ 所有非本平台码的反馈会被并成**同一条**记录（实测：6 个不同码 → 1 条记录 / `repeat_count=6`，且 `evidence` 被逐次**覆盖** ⇒ 后台既看不出有几个码被反馈、也看不到各自的反馈内容）。⇒ 改为**按 `code` 字符串合并**（`JSON_UNQUOTE(JSON_EXTRACT(evidence,'$.code'))`），本平台码与非本平台码一视同仁；**不动共用的 `triggerAlert`**（其他调用点各自有正确的区分键，改了反而引入风险）。复验：两个不同的非本平台码 → **两条独立记录** ✅；同一码跨 IP 再反馈 → **合并为 `repeat_count=2`** ✅。
- **★ 三道业务边界（写进文件头）**：① **消费者提交的内容 = 线索，不是结论** —— 绝不自动把码标成"存疑/作废"，处理动作留在后台由人点（现有「已核实合规 / 已确认违规」）；② **非本平台码也允许反馈** ⇒ 落 `enterprise_id = null` 的预警；已核 `alerts.get.ts` 的 `platform_admin` 分支**不加企业过滤** ⇒ **平台管理员能看见（不是黑洞）**；③ **站内信骚扰风险**：同码合并 + 限流缓解，但攻击者可"换着码刷"（每个新码建一条预警 + 一条站内信）⇒ **限流是唯一防线**，若日后成灾再加"全局每小时上限"（本次不做）。
- **★ 顺带的安全核查**：`deploy/nginx-nz315.conf:87` 有 `proxy_set_header X-Real-IP $remote_addr;` ⇒ **nginx 会覆盖客户端自带的 `x-real-ip`**；配合 `clientIpOf` 优先读 x-real-ip 的设计 ⇒ **生产环境限流无法靠伪造请求头绕过** ✅（本机 dev 无 nginx，可伪造头，属预期）。
- **★ 保留 `'mismatch'` 类型但加警告注释**：`shared/types/trace.ts` 里该类型**没有任何产出方**，但为对齐 PRD 8 类异常清单保留；已就地加注释说明「别据此写 `v-if` 门 —— N2 缺陷就是被这一行骗的」。
- **修改文件**：**新增** `server/api/feedback.post.ts` · **新增** `app/components/TraceFeedback.vue` · `app/components/TraceAlert.vue`（删死按钮与 stub、接真入口）· `app/components/TraceResult.vue`（正品页加入口）· `shared/types/trace.ts`（警告注释）· 本条目。**零 DDL / 零依赖 / 零 nginx / 零 `.env`**；需 build + reload。

### 2026-09-23 | fix：N4 —— 「登记证已过期 ⇒ 暂停绑定批次」（PRD 8 类异常-4）
- **结果一句话**：新增**公共守卫** `server/utils/product-guard.ts` 的 `assertProductBindable(productId)`，插入 **3 个文件 / 4 处**绑定入口。此前 `registration_expire` 全仓库只出现在 4 处（`trace.get.ts` 只读判断 + `products.post.ts` / `products/[id].patch.ts` 写入），**4 个绑定入口全无该字段校验** ⇒ 已过期的登记证照样能绑批次，消费者扫码才看到红字。
- **★ 端到端验收证据（双向，本机 3100 真打）**：
  | 场景 | 结果 |
  |---|---|
  | 过期产品（`id=22` `PD20990002`，expire=**2020-01-01**）走单码换绑 | **400「该产品登记证（PD20990002）已于 2020-01-01 到期，不可绑定生产批次，请先更新登记证有效期」** ✅ |
  | 未过期产品（`id=21`，expire=**2029-12-31**）走同一入口 | 守卫**放行**，被紧随其后的一致性校验拦住（「所选批次产品与当前追溯码产品不一致」）—— **文案不含"到期" ⇒ 证明不误拦** ✅ |
  | 另两个改动文件的编译加载 | `batch-correct` / `upload-batches/[id]/correct` 未认证均返 **401「未登录」**（而非 500 编译错）⇒ 守卫 import 与调用无问题 ✅ |
- **★ 四处插入点（均为「绑定动作」发生前）**：`codes/batch-correct.post.ts:47`（批次查出后、产品一致性校验前）· `codes/[id]/correct.post.ts:53`（传 `code.product_id ?? batch.product_id`）· `codes/upload-batches/[id]/correct.post.ts:66`（**新建批次模式的分支开头**）与 `:149`（重绑前）。
- **★ 实施时对 27 号方案做了一处主动改进（不是照抄）**：27 号原写「新建批次那处插到 `:111-113` 之间」（即 batchId 已确定、UPDATE 之前）—— 但那个位置**在半路**：`exist` 未命中时 `:99-101` 已经 `INSERT INTO batch` 建了新批次，此时才抛 400 ⇒ **库里会留下一行没有任何码引用的孤儿 batch**。⇒ 实施时**前移到分支开头**（查 unbound 与建批次之前），理由已写进代码注释。
- **★ 五条边界（已写进 `product-guard.ts` 文件头）**：① **历史数据不回溯**（已绑定码不回收、不改变，只拦新的绑定动作）；② **只拦绑定、不拦生成码**（严格按 PRD 处置层级"暂停绑定批次"；生成码是码池入库、不代表生产行为）；③ **不拦编辑批次与字段修正**（那是**纠错**场景，拦了历史数据永远修不回来）⇒ **明确不加到 `batches/[id].patch.ts`**（它不是绑定入口，只同步冗余列）；④ **`registration_expire` 为空的产品不拦**（保持既有数据可操作；代价是留了个"后门"，要堵得把它改成必填，属产品决策、本次不做）；⑤ ⚠️ **日期比较刻意沿用项目既有 UTC 口径** `new Date().toISOString().slice(0,10)`（与 `trace.get.ts` 一致）⇒ 东八区凌晨 00:00–08:00 之间 UTC 日期还是前一天，**到期当天凌晨会多放行 8 小时**。本次**刻意保持一致**（引入第二套口径 = 两处判断打架更糟）；若某天要统一修，应**连同 `trace.get.ts` 一起**改成按北京时间，那是独立一条、别混进别的改动。
- **★ 上线影响面提示**：上线后会出现「以前能绑、现在被拦」——**这是预期行为**（正是本修复的目的）。建议上线前先量：`SELECT COUNT(*) FROM product WHERE registration_expire IS NOT NULL AND registration_expire < CURDATE();`
- **修改文件**：**新增** `server/utils/product-guard.ts` · `server/api/admin/codes/batch-correct.post.ts` · `server/api/admin/codes/[id]/correct.post.ts` · `server/api/admin/codes/upload-batches/[id]/correct.post.ts` · 本条目。**零 DDL / 零依赖 / 零 nginx / 零 `.env`**；需 build + reload（并入 ycdb 一次上线）。

### 2026-09-23 | fix：N6 ①②③ —— 附近门店接口纯防御加固（缓存封顶 / 坐标校验 / 同 IP 限流）
- **结果一句话**：按用户决策**只做 ①②③ 三项纯防御**（**N6④ 独立高德 key、N6-b 搜索框一并暂缓** —— 用户明确「附近门店模块后续可能下架、改为类微信支付的农资记账功能」，不值得给一个可能被删的模块投成本）。改 `server/api/stores/nearby.get.ts` + **新增** `server/utils/rate-limit.ts`（通用进程内限流器，N2 的 `/api/feedback` 要复用）。
- **★ 三项加固的实测证据（本机 3100 真打）**：① 非法坐标 `lng=999&lat=999` → **`200 {"located":false,"rows":[]}` / 38ms**（改前只判 `Number.isFinite`，同样能推动 **2 次高德调用**）；② 无参数 → `located:false`；③ 合法坐标（济南）→ `200 rows=20` / 216ms，**同坐标再打仅 4ms**（缓存命中，证明既有缓存未被改坏）；④ 连打 40 次非法坐标 → **第 27 次起 `429`**（前序已用 4 次，4+27=31>30，**阈值精确**）。
- **★ 三个反直觉的设计点**：① **非法坐标返回 `located:false` 而不是 400** —— 保持既有响应契约（前端 `stores = data.rows || []`，`located:false` 走「未定位」引导分支）；改成 400 会让页面进 error 态、属**不必要的体验退化**。② **限流阈值刻意宽松（30 次/分钟）** —— 同一出口 IP 背后可能是公司/校园 NAT 或运营商 CGNAT 下的大量正常用户，**宁可放过也不让正常用户看到 429**（正常用户靠 1km 网格缓存远达不到）。③ **限流放在坐标校验之前** —— 非法请求也计入，防止有人拿非法坐标探测刷日志。
- **★ 为什么进程内限流就够 + 它的天花板**：本项目 PM2 是 **fork 单实例** ⇒ 进程内计数即全局计数。⚠️ 已在代码注释写明：**若将来改 cluster，限流会按实例数成倍放宽，那时必须换成共享存储（Redis/MySQL）**。限流器自带桶数上限 10000 + 定期清理，避免自身变成内存增长点（与 `ip-geo.ts` 的 `CACHE_MAX` 同一取向）。缓存加固照抄 `ip-geo.ts` 既有写法（满则丢最早一半），保持项目风格一致。
- **★ 明确未做的两条（留档，避免下轮重复判断）**：**N6④** 拆分高德 key —— 现与 `ip-geo.ts` **共用 `amapWebKey`** ⇒ POI 配额被打爆时 `ip-geo` 仍会静默返 null、「重复查询」重新退化（**该耦合风险依然存在，只是本次不修**）；**N6-b** 搜索框 —— 服务端**从未读取 `keyword`**（写死「农药」「农资」）⇒ 页面输入仍无任何效果。两条都已在文件头注释里标注「已知未做 + 原因」。
- **修改文件**：`server/api/stores/nearby.get.ts`（改写加固）· **新增** `server/utils/rate-limit.ts` · 本条目。**零 DDL / 零依赖 / 零 nginx / 零 `.env`**；需 build + reload（并入 ycdb 一次上线）。

### 2026-09-23 | fix：N5 —— 首页统计改为真实计数（清除公网展示的伪造数字 128630/42）
- **结果一句话**：用户对 27 号方案的 4 个口径拍板（**D-1 按建议** / **D-2 N2 真做** / **D-3 N3 不含 type 5** / **D-4 N6④ 暂缓**；并补充「附近门店模块后续可能整体下架、改为类微信支付的农资记账功能」⇒ **N6-b 与 N6④ 一并暂缓**），据此开始逐条实施。本条是最敏感的第一条：把 `server/api/stats.get.ts` 由**全文 8 行硬编码**改为两个真实 `COUNT(*)`。**实测**：本机 `GET /api/stats` 由 `{"totalQueries":128630,"abnormalClues":42}` 变为 `{"totalQueries":213,"abnormalClues":12}`（真值，随业务变化）。
- **★ 口径（按用户 D-1 决策，已写进代码注释）**：① **累计查询 = `scan_log` 全表行数** —— ⚠️ **只统计本平台签发的码**（扫到非本平台码走登记库只读兜底分支 `external-reg`，该分支**刻意不写 `scan_log`、不触发预警**）⇒ 该数字天然**低于**真实扫码总量，**属设计使然，不是 bug**；② **异常线索 = `risk_alert` 全量行数**（含已处理）——若某天要改成"待处理"，在 SQL 上加 `WHERE handle_status = 0`（口径不同但仍是真数）。
- **★ 为什么要 60s 进程内缓存**：首页是**公众高访问路径**，不能每次请求都 COUNT 全表。本项目 PM2 是 **fork 单实例** ⇒ 进程内缓存有效（将来若改 cluster，各实例各缓存一份，可接受）。
- **★ 关键设计：查询失败返 `null`，绝不返假数**：`catch` 里返回 `{totalQueries:null, abnormalClues:null}` —— 前端 `app/pages/index.vue` 本就有 `stats?.totalQueries || '--'` 兜底、会自动显示 `--`。**这条正是本缺陷的教训：宁可不显示，也绝不显示编造的数字。**（接口**继续保持无鉴权**——首页是 SSR 公众页，加鉴权会白屏；两个数字是总计数，不含任何企业/用户信息。）
- **★ 顺带**：精简 `.workbuddy/memory/MEMORY.md`（已超出注入上限被截断；细节全部指向 `docs/handover/`，只留「改错了会出生产事故」的硬约定）。
- **修改文件**：`server/api/stats.get.ts`（改写）· 本条目 · `.workbuddy/memory/MEMORY.md`。**零 DDL / 零依赖 / 零 nginx / 零 `.env`**；**需 build + reload**（并入 `ycdb` 那一次上线，不单开窗口）。

### 2026-09-23 | docs：新增 27 号 N2–N6 修改方案（含对 26 号 N4 拦截点清单的更正）
- **结果一句话**：用户要「N2–N6 给我修改方案，明确影响和边界还有修改后的情况」。出 **`docs/handover/27-N2-N6修改方案（待确认·2026-09-23）.md`**，每条按「方案 → 影响 → 边界 → 修改后的情况」四段写，**附件级精确到文件与行号**。**方案文档，未改任何代码、未部署。**
- **★ 先更正 26 号的一处错误（本轮回读代码发现）**：26 号把 `server/api/admin/batches/[id].patch.ts` 列进了「绑定批次接口」，**错的** —— 它只把批次三要素**同步到已绑定码的冗余列**（`.patch.ts:40-43`），**不产生新绑定**。⇒ 真正的绑定入口只有 **3 个文件 / 4 处**：`codes/batch-correct.post.ts:52-54` · `codes/[id]/correct.post.ts:55-66` · `codes/upload-batches/[id]/correct.post.ts:113-115`（新建后绑定）与 `:142-144`（重绑）。26 号已就地更正并标注更正日期。
- **★ 顺带挖出第 8 条功能漏洞（N6-b，本轮新发现）**：**附近门店页的搜索框是装饰品**。`app/pages/nearby-stores.vue:172-178` 有输入框（placeholder 原文「搜索门店名称 / 地址」）与「搜索」按钮，`:31` 把 `keyword` 传给了服务端 —— 但 `server/api/stores/nearby.get.ts` **从头到尾没用过 `keyword`**（`:66-69` 写死关键词「农药」「农资」）⇒ **用户输入任何内容都无效**。已并入 27 号 §2 的 N6-b。
- **★ 五条方案的关键设计决策（都不是照搬直觉）**：
  - **N2 复用 `risk_alert` ⇒ 零 DDL、不新建后台页面**：PRD 要的「核实工单」，后台**风险预警中心就是现成的工单系统**（列表/详情/证据/"已核实合规""已确认违规"动作/导出），消费者反馈直接落 `risk_alert(alert_type=7)`、复用 `triggerAlert` 的同码合并语义。⇒ 只需 **1 个公众写接口 + 2 个 vue**。并指出**入口必须加到 `TraceResult.vue`（正品页）**：消费者要发现"信息与标签不符"，必须先在页面看到产品信息，而产品信息**只在正品页展示**——只放异常页等于把最该反馈的人挡在外面。
  - **N3 不走 HTTP 接口，改独立脚本 + 宝塔 crontab**：因为 nginx 反代后**连 socket 都是 127.0.0.1**，而 `clientIpOf` **优先信头** ⇒ "只允许本机"的守卫必须同时判「socket 回环 **且** `x-real-ip` 为空/回环」，脆弱且易写错；独立脚本**没有任何 HTTP 攻击面**，还顺带**零新 env、零 rebuild**。⚠️ 并明确其安全闸取向**与 `seed-abnormal-demo.mjs` 相反**（那个要 `DB_HOST` 白名单，这个**绝不能设** —— 服务器 `DB_HOST` 正是 `127.0.0.1`，设了永远跑不起来），防护改为「**默认 dry-run、必须显式 `--apply`**」。另指出**预警表增长边界**：`triggerAlert` 对"已处理"的会新建 ⇒ 每天巡检会线性膨胀，**必须在巡检侧加 30 天冷却**。
  - **N4 五条边界**：① 历史数据不回溯（已绑定码不变，并给出"上线前先量影响面"的 SQL）；② 只拦绑定**不拦生成**（严格按 PRD 处置层级）；③ **不拦编辑批次/字段修正**（那是纠错场景，拦了历史数据永远修不回来）；④ **`registration_expire` 为空不拦**（保持既有数据可操作，代价是留了个后门）；⑤ 日期比较**刻意沿用项目既有 UTC 口径**（与 `trace.get.ts:181` 一致）⇒ 东八区凌晨多放行 8 小时，要统一改应**连同 `trace.get.ts` 一起**，别混进本次。
  - **N6 四项加固 + 关键反直觉点**：② 非法坐标用 `located:false` 而**不是 400**（保持既有响应契约，避免前端进 error 态）；③ 限流阈值要**宽松**（30/min），防 NAT 误伤；④ 高德 key 拆分是**唯一需要 `.env` 变更**的一条 ⇒ **必须先改 `.env` 再 build**（铁律第 4 条）。**N6-b 的关键约束：绝不把用户输入直接当高德 `keywords` 透传**（那会把配额口子开得更大，与 ④ 初衷相反），改为「先本地过滤 → 必要时才打一次高德」。
  - **N5**：给的是可粘贴的 8 行实现（真数 + 60s 进程内缓存 + 失败返 null ⇒ 前端已有 `|| '--'` 兜底会自动显示 `--`）；并明确 **没有"零部署"的止血办法**（数字是 SSR 期算出的）⇒ **要么并入 ycdb 上线，要么单独热修一次**（成本与上线同）。
- **★ 待用户拍板的 4 个口径**（写在 27 号 §0，不定就没法动手）：**D-1** N5 真数定义（异常线索用"全量"还是"待处理"）· **D-2** N2 做还是豁免 · **D-3** N3 首版是否含 type 5（**建议不含**，P1-5 已证该口径误报）· **D-4** N6④ 是否申请独立高德 key（**建议做**）。
- **★ 上线方式建议**：五条**全是服务端/脚本代码** ⇒ 都要 build（N3 脚本除外）⇒ **强烈建议 N2/N4/N5/N6 并入 `ycdb` 那一次 build + `pm2 reload nz315`**，不要为它们单开部署窗口。
- **修改文件**：新增 `docs/handover/27-N2-N6修改方案（待确认·2026-09-23）.md`；修改 `docs/handover/26-功能漏洞复查（线上已存在·ycdb追加·2026-09-23）.md`（N4 拦截点清单更正）· 本条目 · `.workbuddy/memory/`。**代码零改动，未部署服务器。**

### 2026-09-23 | docs：新增 26 号功能漏洞复查（挖出 6 条**线上正在发生**的新缺陷）
- **结果一句话**：用户要「根据 25 号手册继续工作，看看还有什么功能性漏洞」。做了一轮**以实测为准**的增量复查，出 **`docs/handover/26-功能漏洞复查（线上已存在·ycdb追加·2026-09-23）.md`**，新增 **N1–N7** 共 7 条（其中 **N1–N6 是【线上已存在】、N7 仅 ycdb**）。**代码零改动、未部署。**
- **★ 本轮最重要的一条口径（决定了严重性排序）**：逐条核对了「问题属于线上还是仅属于未部署的 `ycdb`」——`git diff --stat master..ycdb -- server/` **只动了 7 个文件**（`external-verifications.get.ts`/`external-verify.post.ts`/`trace.get.ts`/`external-verification.ts`/`ip-geo.ts`/`registry-lookup.ts`/`risk-alert.ts`）⇒ **凡不在这 7 个文件里的问题，线上（09-19 构建的 master 产物）都已经存在**。⇒ **23 号的 P1-3/P1-4/P1-5 是「上线才引入的风险」，而 N1–N6 是「现在就在线上的洞」。**
- **★ N1【P1·线上】产品建档不校验登记证号是否存在**（PRD 8类异常-3 要求「建档时阻断」）。**实测端到端**：先用库确认 `PD99999999` 在 `pesticide_reg` **0 条**，再以 `lvfeng` 登录 `POST /api/admin/products` → **HTTP 200 `{"ok":true,"id":23}`**，`product` 表**真的落了 1 行**；验证后当场删除（`product_original` 1 行 + `product` 1 行，残留复核 **0**）。源码：`products.post.ts:25` 只校验非空、`:38` 只查系统内重复，**从不查 `pesticide_reg`**；前端输入框占位符原文「选中产品自动带出，**可修改**」（自由文本）；**全仓库零处 `triggerAlert(alertType=3)`**。
- **★ N2【P1·线上】公众端「信息有误，点此反馈」入口不可达 + 功能是 stub**（PRD 8类异常-7 要求「扫码页入口 + 核实工单」）。三段闭合证据：① `shared/types/trace.ts:11` **声明了** `'mismatch'`；② `trace.get.ts` 全部产出只有 8 个值（`not-found`/`external-reg`/`voided`/`frozen`/`reg-expired`/`expired`/`repeat`/`genuine`），**`mismatch` 一个都不产出**；③ `TraceAlert.vue:145` 按钮门在该值上、`:64-66` 只弹「信息反馈功能建设中，敬请期待」。**master 版本实测**：`master:shared/types/trace.ts 含 mismatch = true`、`master:app/components/TraceAlert.vue 含 resultType === 'mismatch' = true`、`master:server/api/trace.get.ts 含 'mismatch' = false` ⇒ **线上同样如此**。
- **★ N3【P1·线上】「每日定时巡检」机制整体不存在**。全仓库（排除 node_modules）无 `cron`/`setInterval`/Nitro 定时任务；`server/` 唯一的 `setTimeout` 在 `ip-geo.ts:75`（限速等待）。`triggerAlert` **全项目仅 3 处调用点**：`trace.get.ts:184`（类型4）、`:211`（类型1）、`external-verify.post.ts:27`（人工核验映射 3/5/6/7）⇒ **类型 3、6 没有任何自动触发路径**；类型 4 改为扫码时触发 ⇒ **没人扫就永远发现不了过期产品**（而巡检的意义正是「不依赖扫码」）。
- **★ N4【P1·线上】「登记证已过期 ⇒ 暂停绑定批次」未实现**。源码：`registration_expire` 全仓库只出现在 3 处（`trace.get.ts:182,186` 只读判断 / `products.post.ts:66` 与 `products/[id].patch.ts:46` 写入），**4 个绑定批次接口全无该字段校验**（`codes/batch-correct.post.ts:53` · `codes/[id]/correct.post.ts:56` · `codes/upload-batches/[id]/correct.post.ts:114,120,143,149,186` · `batches/[id].patch.ts:41`），且这 4 个文件与 master **逐字节相同**。
- **★ N5【P1·线上·公网可见】门户首页在展示伪造统计数字**。**实测**：本机 `GET /api/stats` → `{"totalQueries":128630,"abnormalClues":42}`；**公网 `https://www.nz315.cn/api/stats` → 同样的假数字，http=200**；**公网首页 `https://www.nz315.cn/` → http=200 / 25,151 B / 输出中含 `128630`**。源码：`server/api/stats.get.ts` **全文 8 行硬编码**，注释原文「演示统计接口…后端需求确认后替换为真实统计」；消费方 `app/pages/index.vue:8,99,108`。两个文件均**不在** `master..ycdb` 改动清单 ⇒ **线上就是这个版本**。⇒ **防伪追溯平台的公众首页把编造的业绩当真数据展示，且接口无鉴权无缓存**。
- **★ N6【P1·线上】`/api/stores/nearby` 匿名可用 + 缓存无上限 + 与 `ip-geo` 共用高德 key**。**实测**：不带 cookie → **http=200**。源码四问题叠加：① `cache` Map（`:16`）**无条数上限**（对照 `ip-geo.ts:29` 5000 / `registry-lookup.ts:49` 500）；② 缓存键是 0.01° 网格（`:18-19`）⇒ **换坐标即换键**，缓存可绕过；③ `:50` 只查 `Number.isFinite`，**坐标无范围校验**；④ `:66-69` 每次未命中打 **2 次高德**。⇒ 影响两条：**内存无界增长**（线上 PM2 `max_memory_restart` 仅 800M ⇒ 周期重启）；🔴 **高德配额可被匿名刷爆并连带绞杀 P1-1** —— `ip-geo` 与它**共用同一把 key**，而限流时高德**HTTP 仍 200、只返 `status:'0'`** ⇒ `ip-geo` 静默返 null ⇒ **`scan_log.province/city` 又写不进去，「重复查询」重新退化成死分支**。⇒ **P1-1 的修复依赖一个可被匿名刷爆的外部配额。**
- **★ N7【P2·仅 ycdb】`registry-lookup.ts` 注释与实现相反**：注释写「先按类别过滤再截断」，实际 SQL 先 `LIMIT 20` 再在 JS 过滤（`external-verification.ts:280` 更连 LIMIT 都没有）。**我原本怀疑这里会「静默丢候选」并准备报 P1，被数据否掉**：复刻该 SQL 跑真实库，**单个后六位最多 6 行**（`3-2000`），远低于 20 ⇒ **当前永不触发截断** ⇒ 降级为「注释失真 + 未来隐患」。
- **★ 顺带实测数据（可并入 23 号 §D 口径）**：`pesticide_reg` **97,471** 条（与 D-1 一致 ✅）；后六位**重复** **13,010** 组；其中**双类别并存 4,389** 组 ⭐ —— 这组数正是「**必须先按类别过滤**」的存在意义（双类别并存时不过滤会给出**错误类别的候选**）。与 D-2 的「同类别多候选 11,921/11,912」**口径不同、不矛盾**。
- **★ 复核后不成立的三条（留档，避免下轮重复劳动）**：① 上述 N7 的截断假设（数据否掉）；② `firstQuery` 在**任何 `.vue` 里都没被使用**，非本平台码分支把它写 false 不会造成显示错误；③ 非本平台码 `queryCount: 0` 无显示消费方，非缺陷。
- **★ 明确没做的事**：**未改任何业务代码、未部署**。N1 的验证往**本机开发库**写了一条产品记录（`product.id=23` + 1 行 `product_original`），**已当场删除并复核残留 = 0**；验证脚本内置 `DB_HOST` 白名单（非 `127.0.0.1/localhost/::1` 直接拒绝），**未触碰线上库**。诊断脚本与中间产物（`C:/shots/nz315-check-20260923/`）**留在仓库外**，未进 git。
- **修改文件**：新增 `docs/handover/26-功能漏洞复查（线上已存在·ycdb追加·2026-09-23）.md`；修改本条目 · `.workbuddy/memory/`。**代码零改动，未部署服务器。**

### 2026-09-23 | docs：新增 25 号交接手册（新对话接续）+ 同步 AGENTS/README 指针
- **结果一句话**：用户要「一份用于打开新对话的记忆文档」。新增 **`docs/handover/25-交接手册-新对话接续（ycdb·P1-1已修·上线包已备·2026-09-23）.md`**（自包含，**取代 21 号**）。照本项目的老规矩——**先把现状实测出来再写**——本轮实测又挖出**一条状态更正 + 两条全新待决项**。**代码零改动、未部署。**
- **★ 状态更正一：P1-1 的「未修」结论作废。** 21 号 §2.4 与 AGENTS 顶部旧指针都写着「`scan_log.province`/`city` 全仓库只读无写、未修」；实际**已于 09-22 修复**（**`66b0f6b`**，新增 `server/utils/ip-geo.ts` 走高德 IP 定位）。25 号把它改写为「✅ 已修复」并保留两条高德硬约束（**限流时 HTTP 仍 200**、**未命中返空数组 `[]` 而非空串**）。
- **★ 状态更正二：`ycdb` 规模已从 21 号的「+15」涨到「+30」。** 09-23 08:5x 实测：`ycdb @ a462a58` = master + **30 提交 / 37 文件 / +4,350 −116**。⚠️ 该数字**每次提交都在动**（21 号记 +15、23 号初版记 +17、23 号订正记 +25，**全都偏低**）⇒ 手册里写明**用前现测**。
- **★ 实测复核（写进手册，省下一轮重复劳动）**：
  | 项 | 09-23 实测结果 |
  |---|---|
  | 上线包指纹 | `nz315-ycdb-1c6730a.tar.gz` = **875,337 字节** / SHA256 **`5b6649c5309f95437b458280344b7f7fb06ee8cf50c4440186a8744166692495`** —— 与 09-22 记录**逐字节吻合** ✅ |
  | 线上构建产物 | `/_nuxt/builds/latest.json` 的 `timestamp=1789812536370` → **2026-09-19 18:08:56** ⇒ **仍未部署**（生成上限仍 1 万） |
  | 恶意前缀 Origin 登录 | **403** ⇒ 09-19 安全加固在线 ✅ |
  | 裸域名 `https://nz315.cn/login` | **301 → www**，路径与 query 保留 ✅ |
  | 上线 before/after 判据（同一条 URL） | 部署前 = `not-found`（含「未查询到」，约 27 KB）；部署后应为 `external-reg`（含「不是农资315签发」「农药登记资料库」「PD20092927」） |
  | 本地 dev 服务 | 3100 **跨夜存活**；三项探针（`external-reg`+`PD20092927` / 恶意 Origin→403 / SSR 含「不是农资315签发」）08:5x 与 17:3x **两次全绿** |
- **★ 新挖出的待决项一：`git archive` 打的上线包**把**内部文档**也带进去了。实测（`core.quotePath=false` 精确统计）：包内 190 文件里含 **`.workbuddy/memory/` 9 个**（项目工作日志/长期记忆）+ **`docs/handover/` 25 个**（全部交接手册与执行单）⇒ 解包后会一并落到服务器目录。**已实测确认包内无真 `.env`（只有该带的 `.env.example`）**，⇒ **不构成凭据泄露**，但属内部信息不必要外溢。建议加 `.gitattributes` 的 `export-ignore` 把 `.workbuddy/` 排除后重打包（**记得同步 24 号执行单的包指纹**）。**待用户定，未执行。**
- **★ 新挖出的待决项二：「产品内容不符」在公众端没有提示位。** 公众端 `/api/trace` 输入只有「32 位码 + IP」，**刻意不抓外部平台页面** ⇒ 那条链路**拿不到产品内容**，因此消费者侧能显示的"问题"只有 4 种（结构非法 / 登记证过期 / 后六位撞车 / 登记库无此证），全部来自**码本身 + 国家登记资料库**；**逐项"内容比对"只在后台「外部二维码核验」页可见**。若产品上确实要公众端也提示，唯一低成本路径是让消费者**手动输入包装上的产品名**做归一化比对——但那会**新增一个公众可写判定入口，必须防刷**。**拟作 P2 产品待决项，等用户拍板。**
- **★ 另一处上游细节**：包基线 `1c6730a` 之后又进了 3 个提交（`35f8b95`/`d248c87`/`a462a58`），与 HEAD `a462a58` 差 **7 个文件**，**全是文档与项目记忆、零运行代码** ⇒ **部署行为完全一致，旧包可用**；要绝对干净就在 `a462a58` 重打。
- **手册结构（沿用 21 号被验证好用的骨架，共 10 节）**：0 60 秒必读 → 1 三条线地图 + 分支现状实测 → 2 三件事 + §2.4 **P1-1 修复详情** + §2.5 新待决项 → 3 master 那笔活儿（含三条警告）→ 4 线上状态实测表 → 5 上线（包指纹 / 与 HEAD 差异 / **包带内部文档** / 比 19 号多做什么）→ 6 铁律 **12 条**（新增「`seed-abnormal-demo.mjs` 严禁在生产跑」）→ 7 踩坑（**新增两条**：临时脚本存 `.mjs` 却用 `require` 报 `ReferenceError`；`git ls-tree` 中文路径被 `quotePath` 转义导致按前缀过滤**漏统计**）→ 8 待办 → 9 文档索引 → 10 一句话总结。
- **同步更新（文档一致性纪律）**：`AGENTS.md` 顶部「当前状态指针」改为**五条要点**指向 25 号（+30 提交 / P1-1 已修 / master 那笔活儿 / 线上 09-19 / 包与执行单已备 + 包带内部文档的风险）；`docs/handover/README.md` 两处索引补 25 号、把 21 号降级为「上一版（P1-1 未修、上线待拍板 两条已被推翻）」；`.workbuddy/memory/MEMORY.md` **同日已瘦身**（`+46 −50`，删与 `docs/handover/` 重复的历史叙述与易漂移数字，硬约定逐条保留）。
- **修改文件**：新增 `docs/handover/25-交接手册-新对话接续（ycdb·P1-1已修·上线包已备·2026-09-23）.md`；修改 `AGENTS.md` · `docs/handover/README.md` · 本条目 · `.workbuddy/memory/`。诊断脚本与中间产物（`logs/_state-*.txt` / `logs/_archive-audit.txt` / `logs/_online-probe.txt` / `logs/_ycdb-commits.txt`）**用完即删**。**代码零改动，未部署服务器。**

### 2026-09-22 | fix：补齐 scan_log.province/city 写入，修复「重复查询」在真实链路永不触发（缺陷清单 P1-1）
- **结果一句话**：用户定「走 ycdb」后修 **23 号缺陷清单 P1-1**。原问题：`scan_log.province` / `city` **全仓库只有读、没有写**（`trace.get.ts` 的 INSERT 里根本没有这两列），而「重复查询」的判据是 `queryCount>=3 && COUNT(DISTINCT province)>=2` ⇒ **该分支在真实扫码链路上永远触发不了**（线上一直如此），PRD「8 类异常-1」是死分支。现补齐写入，**14 项断言全通过**。提交 **`66b0f6b`**（`ycdb`，2 文件 / +185 −4）。**零 DDL / 零新依赖 / 零 nginx 变更；未部署服务器。**
- **★ 修法：新增 `server/utils/ip-geo.ts`（IP → 省市）**。数据源**高德 IP 定位 `restapi.amap.com/v3/ip`**，复用 `runtimeConfig.amapWebKey`（与 `stores/nearby.get.ts` 同一个 key、同一套调用范式）⇒ **零新依赖**。模块自带 **24h 成功缓存 / 10min 负缓存 + 全局限速（≈3 QPS）+ 单飞去重 + 内网与保留地址直接跳过 + 任何异常静默返 `null`** —— 本模块**不参与任何判定，只补充字段**，扫码结果永不受其影响。
- **★ 两条本机实测硬约束（写进文件头，改这个文件前必看）**：① **限流/配额用尽时 HTTP 仍是 200** —— 实测**连续第 4 次调用**即返 `{"status":"0","info":"CUQPS_HAS_EXCEEDED_THE_LIMIT","infocode":"10021"}`，只看 HTTP 码会把限流当成功 ⇒ 必须显式判 `status === '1'`；② **未命中时返回的是空数组而非空字符串** —— 内网 IP（127.0.0.1）与境外 IP（8.8.8.8）实测都返 `"province":[], "city":[]`，直接 `String()` 会把 `[]` 拼进库 ⇒ 按 Array 处理。
- **★ 写入时机取「缓存命中即当场写、首见新 IP 后台异步补齐」而不是同步解析**：公众端是**唯一被陌生人高频打的路径**，而高德 IP 定位 QPS 极小（约束 ①），**绝不能把外部调用压进扫码主链路**。同步解析会让每个新 IP 的扫码多等几百毫秒、且容易打爆配额。异步补的代价只是"该 IP 首次出现时这一行的省市晚几百毫秒落库"，而重复查询判据用的是**历史统计**（≥3 次且 ≥2 省），无所谓滞后一次。缓存命中率在真实场景很高（同城/同运营商 IP），**跨省判定基本不存在延迟**。
- **★ 顺带修掉一处安全隐患：原 IP 取自 `x-forwarded-for` 的第一个值，可被客户端伪造。** nginx 的 `$proxy_add_x_forwarded_for` 会把**客户端自带**的该头拼在真实 IP **前面**，取 `split(',')[0]` 等于采信客户端自报的归属地 ⇒ **「重复查询」的省份可以被任意刷**。已改走 `clientIpOf(event)`（优先 `x-real-ip`，不可伪造）。实测：伪造 `x-forwarded-for: 1.2.3.4` + 真实 `x-real-ip: 221.216.1.1` ⇒ 落库 `ip_location = 221.216.1.1`，伪造值未被采信。
- **★ 验收（14 项断言，全过）**——刻意不验"列写进去了"，而验"**分支真的能触发**"：内网 IP（192.168.1.7）不发外部请求且省市为 null · 伪造 `x-forwarded-for` 不被采信 · 异步补齐落 `北京市/北京市` · 同 IP 二次扫码走缓存**当场写入（12ms，无滞后）** · 第二个省份 `上海市`（101.226.4.6）落库 · **核心一项：不给任何预置数据，走真实 `/api/trace` 链路即得到 `resultType='repeat'`、`reasons=["该追溯码已被查询 22 次，超过 3 次阈值","查询地域跨 2 个省份（北京市、上海市）"]`，并生成 `risk_alert(alert_type=1)`** · 收尾清理 5 条 `scan_log` + 1 条 `risk_alert`，码回到 `genuine`。
- **★ 残留边界（不是缺陷）**：本机开发环境扫码请求的 `x-real-ip` 往往是 `127.0.0.1`（内网 ⇒ 查不出省市），是**环境使然**；线上经 nginx 反代后 `X-Real-IP` 才是真实公网 IP（14 号手册 §2.3 已确认 `nz315.conf` 带 `proxy_set_header X-Real-IP $remote_addr`）。⇒ **线上验证这条功能必须用公网 IP 打**，本机只能靠伪造头模拟。
- **★ 影响面（为什么这条改动很"轻"）**：**零 DDL** —— `scan_log` 的 `province` / `city` 两列与索引**本已存在**（此前只是没人写），故**上线不需要任何额外迁移**；**零依赖变化**（无 package.json/lock 改动）；**零 nginx 变更**（`X-Real-IP` 头本来就在传）。行为变更仅一处：`scan_log` 的两列开始有值 ⇒ 「重复查询」这一 PRD 分支从死代码变为可用（**未改任何判定口径**）。
- **修改文件**：新增 `server/utils/ip-geo.ts`；修改 `server/api/trace.get.ts` · `docs/handover/23-缺陷清单（2026-09-22 整理）.md` · 本条目 · `.workbuddy/memory/`。临时验收脚本用完即删（`scripts/_tmp-*`，且该模式已在 `.gitignore`）。**未部署服务器**（线上仍停在 09-19 构建产物）。
- **顺手订正的数字**：`ycdb` 相对 master 的规模，21 号记「+15」、23 号初版记「+17」**均偏低**；以 2026-09-22 18:0x 实测为准 —— `ycdb @ 66b0f6b` = master + **21** 提交 / **35** 文件 / **+3,624 −114**（取数命令已写进 23 号 §P0-3，避免后续再靠记忆写数字）。

### 2026-09-22 | docs：新增 21 号交接手册（新对话接续）+ 顺手把「裸域名 443」这条 P0 销掉
- **结果一句话**：用户要「一份用于新对话的记忆文档」。新增 **`docs/handover/21-交接手册-新对话接续（ycdb分支·裸域名已修复·待部署清单）.md`**（自包含，取代 20 号）。照 20 号的规矩——**先把现状实测出来再写**——本轮实测又挖出**一处状态更正 + 一处分支漂移**，都是照着旧文档会踩空的。**代码零改动。**
- **★ 状态更正（最重要）：裸域名 `https://nz315.cn` 已经修好了，20 号那条 P0 是错的。** 20 号（同日 15:4x 写）把「裸域名证书不匹配、落到 cynx 的 server 块、修法未执行」列为 P0 待办。**17:2x 实测已不成立**：
  | 探测 | 结果 |
  |---|---|
  | `https://nz315.cn/` | **301** → `https://www.nz315.cn/` |
  | `https://nz315.cn/login` / `/trace?code=1` | **301**，**路径与 query 均保留** |
  | `http://nz315.cn/` | **301** → `https://www.nz315.cn/` |
  | `tls.connect(SNI='nz315.cn')` | CN=`www.nz315.cn`、issuer **DigiCert**、`SAN=DNS:www.nz315.cn, DNS:nz315.cn`、到期 2026-12-16 |
  | **`rejectUnauthorized:true` 严格校验** | ✅ **握手成功** |
  | 对照 `SNI='www.cynx.cn'` | CN=`www.cynx.cn`、issuer **Let's Encrypt** ⇒ 两者证书不同，**证明裸域名走的是 nz315 自己的 server 块** |
  ⇒ 修法当时给的就是「补 `server_name nz315.cn` 的 443 `return 301` 块」（因证书 SAN 已含裸域名），**用户已执行完**。
- **★ 分支漂移：`ycdb` 从 master + 8 变成 master + 15**（差异从 `19 文件 / +855 −21` 变为 **`31 文件 / +2,599 −38`**）。新增 6 个提交全在 20 号写完之后：外部核验**统一码提取规则**（`shared/utils/trace-code.ts`）、**公众端扫码接入登记资料库比对**（新结果类型 `external-reg` + `shared/utils/unit-code.ts` + `server/utils/registry-lookup.ts` + `TraceExternal.vue`）、**异常场景扫码测试码脚本**（`scripts/seed-abnormal-demo.mjs`）。⇒ **20 号的「ycdb = +8」已过时**。
- **★ 顺手核实的三件事（都写进手册，省下一轮重复劳动）**：① **`ycdb` 上线仍是「有 DDL 但零依赖」**——`git diff master..ycdb -- package.json package-lock.json nuxt.config.ts` **实测为空**；DDL 具体为**新增表 `external_verification`** + **`risk_alert` 补列 `external_verification_id`** + **补索引 `idx_external_verification`**（三条都是幂等迁移，已读 diff 确认）；② **待部署包指纹复核一致**：`nz315-master-68163bb.tar.gz` = **742,206 字节 / SHA256 `5d2135c6…c9c65d46`**（与 20 号记录逐字节吻合）；③ **master 那笔活儿的三处分布未变**：`stash@{0}` 仍在、工作区仍是 **30 项 + 脚本 13,507 字节**、备份目录仍是**过时的 11 项 + 7,221 字节**。
- **★ 新增一条 P1 架构缺陷进待办**：**`scan_log.province` / `city` 全仓库只有读没有写**（`trace.get.ts` 的 INSERT 无这两列）⇒「重复查询」判据 `≥3 次且 ≥2 省` 在**真实扫码链路上永远触发不了**。实测证据：本机 `scan_log` 182 行里 `province` 非空的**只有 3 行，且全是测试脚本预置的**。
- **手册结构（沿用 20 号被验证好用的骨架）**：0 60 秒必读 → 1 三条线地图 + 分支现状实测 → 2 **本轮新增的两条线**（公众端登记库比对 / 异常场景测试码）+ §2.4 架构缺陷 → 3 master 那笔活儿（含三条警告）→ 4 线上状态实测表（含裸域名修复证据）→ 5 ycdb 上线比 19 号多做什么（逐维度对照表）→ 6 铁律 11 条 → 7 踩坑（含本轮新增的「raw mysql2 解构」「32 位码手抄」两条）→ 8 待办（P0/P1/P2，**已把裸域名那条划掉**）→ 9 文档索引 → 10 一句话总结。
- **同步更新（文档一致性纪律）**：`AGENTS.md` 顶部「当前状态指针」改为指向 21 号并把四条要点写全（ycdb +15 / 零依赖 / 裸域名已修 / province 缺陷）；`AGENTS.md` 里「阿里云上线部署」块的**剩余待办 ① 划掉并附实测证据**；`docs/handover/README.md` 两处索引补 21 号、把 20 号降级为「上一版」；**给 20 号顶部加「已被取代」横幅并逐条写明**它哪两句被推翻（防止有人直接翻旧版被误导）。
- **修改文件**：新增 `docs/handover/21-交接手册-新对话接续（ycdb分支·裸域名已修复·待部署清单）.md`；修改 `AGENTS.md` · `docs/handover/README.md` · `docs/handover/20-交接手册-新对话接续（ycdb分支与待部署清单）.md` · 本条目 · `.workbuddy/memory/`。临时探针脚本与诊断日志用完即删。**代码零改动，未部署服务器。**

### 2026-09-22 | feat：新增异常场景扫码测试码生成脚本（9 张真能扫的码，覆盖 /trace 全部分支）
- **结果一句话**：用户要「几张异常情况的二维码供扫描测试」（点名"同码多地多次扫描"和"过期"）。新增 **`scripts/seed-abnormal-demo.mjs`**，一条命令造出 **9 张 zxing 可反解的二维码 + 配套测试数据 + 手机对屏扫的总览页**，覆盖公众端 `/trace` 的**全部分支**：正常(对照) / 重复查询(跨3省) / 产品已过有效期 / 已冻结 / 已作废 / 登记证已过期 / 查无此码 / 编码结构非法 / 外部平台码(登记资料库命中)。**三层自证全绿（zxing 反解 9/9 · 接口 resultType 9/9 · 结果页 SSR 文案 9/9）**。提交 `23e3c74`，分支 `ycdb`，`master` 未动、未部署。
- **★ 为什么需要脚本而不是手改库**：异常分支此前只能手工改库来验（`abnormal_flag` 置 1/2、把批次有效期调到过去…），改完还得记得改回去；更要命的是**扫码验收必须有"真能扫出来"的图**。手改 + 手造码 = 每次验收重来一遍，且极易在库里留下垃圾。现在 `--clean` 一键清干净。
- **★ 三层自证（刻意做成三层，各自能抓不同的错）**：
  | 层 | 查什么 | 抓得住什么 |
  |---|---|---|
  | ① zxing 反解每张 PNG | 图能扫、内容 === 期望 URL | 矩阵转置、参数写反这类"图生成了但扫不出"的错 |
  | ② 真打 `/api/trace` | 返回的 `resultType` === 预期 | 数据串起来没走对分支（`abnormal_flag` 没写、有效期没设对） |
  | ③ 抓 SSR 结果页 | 页面含该分支的关键文案 | 白屏、组件没挂上、渲染了**错误**的组件 |

  只做 ① 会漏分支错，只做 ② 会漏白屏，只做 ③ 会漏"渲染了对的组件但分支错"。三层缺一不可。
- **★ 本轮踩的两个坑（都已写进脚本注释）**：
  1. **`raw mysql2` 的解构口径** —— `conn.query()` 返回 `[rows, fields]`，而项目封装的 `server/utils/db.ts` 的 `query()` 返回**行数组本身**。混用后 `const [row] = await conn.query(...)` 拿到的是数组、`row.id` 恒 `undefined`，**而 `if (row)` 对空数组居然是真** ⇒ 静默走进错误分支，报错点漂到几十行之外。已统一收口到 `firstRow()` helper。**这是本项目第三次同类踩坑**（前两次在业务代码里）。
  2. **32 位码手抄必错** —— 我用临时脚本硬编码码值做页面校验时，把第 6 个码的 `990002` 抄成 `990001`（即另一张正常产品的登记证尾号），该码在库里查不到 ⇒ 页面渲染成"未查询到"。更坑的是：**两个 `TraceNotFound` 页面恰好字节数完全相同（30036B）**，而我恰好是把它放在第 6 个位置请求的，于是现象看起来像"服务端结果随请求顺序翻转"。最终靠"从库里取码 + 逐字节比对脚本内字面量"的探针才定因。**结论：脚本产物里增加 `manifest.json`，任何人要写后续校验一律从它取码，不再手抄。**
- **★ 一处真实的架构缺陷（本轮一并挖出并记录，未修）**：**`scan_log.province` / `city` 全仓库只有读、没有写**。`trace.get.ts` 的 INSERT 语句里根本没有这两列（前端不上送位置、服务端不解析 IP），故两列**恒为空串**。而"重复查询"分支的判据是 `queryCount>=3 && COUNT(DISTINCT province)>=2` ⇒ **真实扫码永远触发不了该分支**（线上一直如此）。本脚本的应对是**预置 3 条跨省 `scan_log`**（山东济南/河南郑州/广东广州）让验收能跑通；**根治需从 IP 解析（或前端上送位置）补齐这两列**，列为待办。
- **安全与隔离（本项目对"往库里写演示数据"过敏，故做足）**：① **硬安全闸** —— `DB_HOST` 不是 `127.0.0.1/localhost/::1` 直接 `exit(2)` 并说明理由（本项目 `.env` 曾指向服务器库，而 `db-init.mjs` 不带 `--migrate-only` 会 seed 演示企业的教训还热着）；② **数据隔离** —— 演示企业/产品/规格名统一带 `【测试】` 前缀，`--clean` 按企业名精确删除（先删 `scan_log`/`risk_alert`/`trace_code`，再删 `product_original`→`batch`→`product`→`product_spec`→`enterprise`）；③ 造数全部走 **upsert**，幂等可重跑。
- **产物**：`qr-test/` —— 9 张 410px PNG · `index.html`（一屏看全 9 个场景 + 每张的码值/扫码地址/本机打开链接/预期结果/自证结论）· `manifest.json`（机器可读）。已加进 `.gitignore`（可再生产物不入库）。
- **怎么用**：`node scripts/seed-abnormal-demo.mjs --verify`（造数 + 出图 + 三层自证，需 dev 服务在 3100）。手机与本机同 Wi-Fi 后扫 `index.html` 上的码即走真机链路；本机浏览器要在 `localhost` 下才有相机权限。清理：`node scripts/seed-abnormal-demo.mjs --clean`。
- **修改文件**：新增 `scripts/seed-abnormal-demo.mjs`；修改 `.gitignore`；本条目；`AGENTS.md`；`.workbuddy/memory/`。临时探针脚本与诊断日志用完即删（`scripts/_tmp-*`、`logs/_*`）。

### 2026-09-22 | feat：公众端扫码也能和登记资料库比对了（扫到别人平台的码不再只回「未查询到」）
- **结果一句话**：用户实测「微信直接扫有数据显示，走 www.nz315.cn 却查不到」，并明确要求**用户端也要和登记库比对**。查明：公众端 `/api/trace` **只查本平台 `trace_code` 表**，登记库比对（`pesticide_reg`）此前**只存在于后台外部核验页**（且该页 `writeOnly`，viewer 都看不到）。已把登记库兜底比对接进公众端，新增专门的消费者结果页；接口回归 6/6、SSR 直出 3/3、真浏览器 4/4（零控制台错误）全绿。**7 个文件（6 改 3 新）；`master` 未动，未部署服务器。**
- **★ 为什么微信有数据、我们没有（根因）**：消费者扫到的码**不是我们签发的**（第三方平台/别的企业自建系统）。微信扫码会**直接打开该码所属平台的 H5**（`mashangzhuisu.com` / `wla1.cn` 之类），数据来自**人家自己的库**；而我们的 `/trace` 拿到 32 位码后**只在 `trace_code` 里找**，找不到就统一回 `resultType='not-found'` + 原因「该追溯码未在追溯系统中登记」——**信息量为零**，用户只能自己猜是假货、还是别的平台。
- **★ 破局点：32 位单元识别代码是全国统一结构**（农业农村部公告第1049号）。第 1 位=类别（1=PD/2=WP）、第 2-7 位=**农药登记证号后 6 位**、第 8 位=生产类型（1 自产/2 委托加工/3 委托分装）。⇒ **前 8 位可以直接拿去国家农药登记资料库比对**，与本平台有没有这个码无关。这条推理有实测支撑：真实第三方码前 8 位 `1-092927-2` 命中 `PD20092927` 硝钠·萘乙酸 / 河南欣农化工有限公司。
- **修法（新增一条「未命中 → 登记库兜底」分支，其余链路零改动）**：
  1. **新增 `shared/utils/unit-code.ts`**：`parseUnitCode` + `isUnitCodeStructureValid` + 两段展示文案。**为什么放 shared**：解析规则要被三处共用（后台外部核验 / 公众端兜底 / 两个前端结果页），任何一处自写一套就会再次漂移 —— 本项目前后端规则漂移已经踩过一次（见 09-22 上一条）。`external-verification.ts` 里原来的 `parseExternalCode` 改为引用它。
  2. **新增 `server/utils/registry-lookup.ts`**：按前 8 位查 `pesticide_reg`（**先按类别过滤**：第 1 位=1 只认 PD/PDN/LS/EX，=2 只认 WP/WPN/WL —— 否则别的类别撞后六位会给出错误候选），再复用 `findOriginalCandidates` **推导原药（母药）登记证号与生产企业**（1049 六项里的两项）。带**进程内 LRU 缓存**（500 条 / 10 分钟）。
  3. **`/api/trace` 未命中分支**：命中登记资料 ⇒ `resultType='external-reg'` + 候选登记资料；未命中 ⇒ 仍是 `not-found`，但原因**分清两种**（结构非法 ≠ 结构合规但登记库没这个证）。**只读、不写 `scan_log`、不触发风险预警**（不是本平台的码，不该污染本平台统计与预警）。
  4. **新增消费者结果页 `app/components/TraceExternal.vue`**：橙色横幅「该码不是农资315签发的」+ 编码结构解析 + 登记资料比对（唯一候选给表格、**多候选逐条列出并要求按标签核对**）+ 原药（母药）信息 + 「必须注意的三点」。`TraceNotFound.vue` 同步补「前 8 位结构解析」卡与接口动态原因。
  5. **`/scan` 不再静默丢弃非本平台二维码**：原实现扫到非追溯码内容**什么都不做**（用户看到的是"扫了半天没反应"）。现改为 `onRawResult` 里**尽力从内容中抠 32 位码**（外部平台链接里通常带码）→ 抠到就送 `/trace` 走登记库比对；抠不到才明确提示，并重启扫描（含**同内容去抖**，避免同一张码在镜头里反复弹提示）。
- **★ 合规边界（刻意写进页面，不能越界）**：① **登记资料命中 ≠ 产品是正品** —— 登记证号是公开信息，仿冒品照样能印一个真实存在的证号；② **生产日期 / 生产批次本平台给不了** —— 只存在于包装标签实物与该码所属平台，页面明确写"请以瓶身标签印刷值为准"；③ 静态「可能原因」里那条"不符合编码规则"**按结构是否合规切换说法**（否则会出现"结构卡说合规、原因列表说不合规"的自相矛盾，实测踩到）。
- **★ 性能取舍（有实测数据）**：`RIGHT(registration_no, 6) = ?` **不可用索引**（`EXPLAIN` = 覆盖索引全扫 95,386 行），本机实测 **26-32 ms/次**。公众端是唯一一条会被陌生人高频打的路径，故加进程内缓存兜住"同码反复扫 / 拿随机码刷接口"。若要常态化更快，可加**生成列 `reg_last6` + 索引**（属 DDL，需 `--migrate-only`，本轮**未做**，列为可选项）。
- **验证（4 项全绿）**：① 接口回归 **6/6** —— 外部码命中登记库（含 3 条原药候选）· 结构合规但登记库无 · **结构非法** · 位数不足 · **WP 类码不会命中 PD 类登记证**（类别过滤生效）· **本平台真实码仍走 `genuine` 且不返回登记候选**（原有链路未被破坏）；② SSR 直出 **3/3**（外部码页 7/7 关键词、结构非法 3/3、结构合规无证 3/3）；③ **真浏览器 4/4**（含 `reject` 反向断言防文案矛盾），**控制台零 error/warning、零未捕获异常**，截图 `C:/shots/trace-external-reg.png` 等 4 张；④ 临时脚本用完即删。
- **修改文件**：新增 `shared/utils/unit-code.ts` · `server/utils/registry-lookup.ts` · `app/components/TraceExternal.vue`；修改 `server/api/trace.get.ts` · `server/utils/external-verification.ts` · `shared/types/trace.ts` · `app/components/TraceNotFound.vue` · `app/pages/trace.vue` · `app/pages/scan.vue` · `AGENTS.md` · 本条目 · `.workbuddy/memory/`。**未部署服务器**（线上仍停在 09-19 构建产物）。
- **本轮未做（仍待办）**：① 上一轮记下的外部核验四条边界（真实平台产品名误报并落 `risk_alert` / SSRF 正则 `$` 放行内网 IPv4 / 单空格分隔字段提取失败 / 「见瓶身喷码」占位词漏网）**本轮未动**；② 公众端**不抓外部平台页面**，因此拿不到生产日期与生产批次（若要"和微信一样全"，得让服务端去抓外部站点 —— 延迟、封禁、SSRF 面都要另做评估，**建议先不做**）；③ 登记资料命中后**要不要给企业/平台留下线索**（当前只读不留痕）。

### 2026-09-22 | feat：外部二维码核验「扫任意平台二维码」终于能用 —— 统一码提取规则 + 非网址输入容错
- **结果一句话**：用户要求「先把扫描外部二维码的功能跑通」。查出的头号障碍是**扫码入口在外部核验页上根本不落地**：扫到别人平台的**纯 32 位裸码**时页面毫无反应（不填值、不提示、不报错，相机却已经停了）。已修复并跑通，真浏览器端到端 + 7 种扫码内容落地断言全部通过。**代码改动 3 个文件，`master` 未动。**
- **★ 根因（前后端两套规则漂移）**：前端 `useQrScanner` 的 `traceCodeOf` 只认「`^\d{32}$` 或本站 `trace?code=`」并判为「本站码」→ 走 `hitCode` 分支；而后端 `extractExternalCode` 认「32+ 位 + URL 参数」。**外部核验页只注册了 `onRawResult`、没注册 `onResult`** ⇒ `hitCode()` 里的 `if (resultCb)` 直接跳过 —— 相机已停，页面**不填值、不提示、不报错**（同一个码手输却能核验，这种不对称最要命）。33 位裸码则被判为外部内容填进「来源链接」框 → 后端 `assertSafeUrl` 抛 **400「二维码内容不是有效网址或追溯码」**。
- **修法四处**：
  1. **新增 `shared/utils/trace-code.ts`**，把「从任意文本/链接提取 32 位追溯码」收敛为**前后端唯一规则来源**：`extractTraceCode`（三路兜底：常见参数名 `?code/?id/?sn/?traceCode` → 任意查询参数值为纯码 → 文本中首段 ≥32 位数字）、`isTraceCode`、`isHttpUrl`。后端 `extractExternalCode` **删除**，`verifyExternalCode` 直接调用 shared，杜绝再次漂移。
  2. **页面补注册 `onResult`**，并用统一的 `applyScan` 落地：**能提码就填码值框，内容本身是网址再顺带填来源链接框**，四类情况各给可操作 toast（含「链接里没有追溯码，请手动补充码值」）。
  3. **后端容错**：来源链接不是 http(s) 网址时**不再 400**，按「未提供来源页面」正常完成编码结构与登记库核验，并给出明确 warning（**手工把裸码粘进链接框是很常见的操作，不该被 400 堵死**）。
  4. `fetchWla1` 由 `redirect:'error'` 改 `follow`（来源站 http→https 时旧写法会当场抛错变 500）；warnings 里「已粘贴内容却提示去复制内容」的误导文案按**是否粘贴**分流。
- **★ 定因手法（比真浏览器更快，值得复用）**：**带 cookie 直接请求 SSR 页面**（`fetch /admin/external-verify`，带 `accept: text/html`）**几秒内就能拿到 setup 的错误堆栈** —— 本轮它一眼指出 `onResult is not defined\n at setup (…/external-verify/index.vue:118:3)`。真浏览器那边只会表现为「路由变了但页面没切换」，极易误判成 dev 冷编译慢。
- **★ 我这次踩的坑（本项目第三次同族）**：加了 `onResult((raw) => applyScan(raw))` 调用，**却忘了在解构里加 `onResult`** → `onResult is not defined`，**SSR 直接 500**。`node --check` / SFC 编译 / tsc **全部静默通过**（与 09-22 那次模板里 `router` 未声明同源）。⇒ **改页面时"改逻辑"和"改解构"是两件事，改完必须真跑一遍。**
- **验证（4 项全绿）**：① `shared/utils/trace-code` 单测 **23/23**，含与改动前 `extractExternalCode` 的行为**逐一比对**（34 位超长、字母混排、31 位、20 位、空串、`undefined` 等边界完全一致）⇒ 证明"换实现"没有改变既有行为；② 接口回归 **6/6**：裸 32 位码与 34 位码填进链接框由 **400 → 200**；仅码值、粘贴正文+码、wla1 真实外网**回归通过**；**粘贴正文但正文里没有码时仍 400**（码提取是硬前置，这条**有意保留**）；③ **SSR 直出 200**（HTML 含标题 / 页面说明 / 扫码按钮）；④ **真浏览器端到端**：同一会话内真登录 → SPA 导航到该页 → 7 种扫码内容落地断言（裸 32 位码→码值框、裸 34 位码→码值框、外部链接含码→两框都填、本站追溯链接→两框都填、无码链接→只填链接、无码文本→清空）→ 点【开始核验】出结果，`console` **零错误**。截图 `C:/shots/ext-verify-scan.png`。
- **本轮未做（用户明确「先跑通再说」，四条均已实测取证，待下轮）**：① **产品名判定对真实平台误报** —— wla1 正常码 `15%精草铵膦可溶液剂-2` vs 登记库 `精草铵膦` 判 mismatch **并落 `risk_alert`**（`normalizeProductName` 只剥了含量，没剥剂型与平台自编号后缀）；② **SSRF 正则末尾 `$` 使点分内网 IPv4 全部放行**（实测 127.0.0.1 / 10.0.0.5 / 192.168.1.1 / 172.16.0.1 / 169.254.169.254 全放行，且 `127.0.0.1` 实测可被抓取返回 200）；③ **单空格分隔标签提取失败**（`农药名称 硝钠·萘乙酸` 三项字段全空）；④ **「见瓶身喷码」占位词漏网**（现有正则只拦"见"+单一词）。四条细节与复现步骤见 `.workbuddy/memory/2026-09-22.md`。
- **修改文件**：新增 `shared/utils/trace-code.ts` · `server/utils/external-verification.ts` · `app/pages/admin/external-verify/index.vue` · `AGENTS.md` · 本条目 · `.workbuddy/memory/2026-09-22.md`。临时诊断脚本与探针用完即删。**未部署服务器。**

### 2026-09-22 | 按厂家实际截图重做后台使用说明（按钮箭头 + 生成/新增/码库流程）
- **结果一句话**：根据用户提供的 9 张后台截图，重做 `docs/厂家后台使用说明/`，每张截图都用红色编号箭头指向实际按钮，并补齐厂家从新增产品、规格维护、生成追溯码、上传校验到码库管理和生产批次绑定的操作流程。
- **重点覆盖**：产品管理「新增产品」·规格管理「新增规格/批量导入」·追溯码生成「选择产品/数量/生成追溯码/导出/下载离线工具」·追溯码上传「选择文件/解析校验」·码库管理「查询/详情/冻结/新建批次并绑定/修正/删除」·生产批次「三要素自动建档」·扫码统计与系统设置。
- **产物**：新增 9 张原图、9 张带箭头的 SVG 标注图、`农资315-厂家后台使用说明.html` 和 `农资315-厂家后台使用说明.pdf`；生成脚本仍为 `scripts/generate-user-guide.mjs`，现改为读取用户提供的临时截图并生成标注成品。

### 2026-09-22 | docs：新增 20 号交接手册（新对话接续）+ 用公网实测把线上状态钉死
- **结果一句话**：用户要「一份用于打开新对话的交接文档」。新增 **`docs/handover/20-交接手册-新对话接续（ycdb分支与待部署清单）.md`**（自包含，取代 16 号成为「先读这个」），内容不是复述文档，而是**先把现状实测出来再写**——顺手挖出三个此前文档里没有或写错的结论。**代码零改动。**
- **★ 实测挖出的三个结论（本机直连公网，2026-09-22 15:4x）**：
  | # | 结论 | 证据 |
  |---|---|---|
  | ① | **线上构建产物是 2026-09-19 18:08:56，19 号执行单（生成上限 50 万）根本没执行** | `GET /_nuxt/builds/latest.json` → `timestamp 1789812536370` → 换算 **2026-09-19T10:08:56.370Z = 本机 09-19 18:08:56**。客户端构建 id 的生成时间戳只会随 `nuxt build` 更新 ⇒ 09-21 之后**没有发生过构建**。**⇒ 线上生成上限仍是 1 万，不是 50 万。** |
  | ② | **微信校验文件已可公网访问（状态变了）** | `GET /MP_verify_OUOoNSqTrpZkfWli.txt` → **200**（此前一直是 404）⇒ 用户已把文件放到 `/www/server/nginx/html/`。**但「网页授权域名是否已在微信后台保存成功」公网探测看不到**，需问用户。 |
  | ③ | 线上加固与工具包状态与前文一致（非新结论，作交叉验证） | 恶意前缀 Origin 登录 → **403**「跨站请求被拒绝」；`/tools/nz315-qr-tool-v1.2.0.exe` **200 / 95035957**；`v1.1.0` **404** ⇒ 服务器基线仍 = `02f4d5c` |
- **★ 分支现状被写清楚（此前只在当日记忆里，未进正式文档）**：`git branch -vv` 实测 —— `master` = `ea7dc78`（与 `origin/master` 同步）· **`ycdb` = `9e610a8` = master + 8 提交** · `codex-ycdb` = `ea7dc78`（**冗余分支**）· `ewm` = `92a68ff`（领先 `origin/feature/ewm` 1 提交）。`ycdb` 相对 master 共 **19 文件 / +855 −21**。
- **★ `ycdb` 上线比 19 号多出来的关键差异：它带 DDL**。`scripts/db-init.mjs` 在 ycdb 上新增了**表 `external_verification`** 与 **`risk_alert` 的列 `external_verification_id` + 索引 `idx_external_verification`**（幂等迁移已写好）。⇒ 若把外部核验一起上线，**必须跑 `node scripts/db-init.mjs --migrate-only`（`--migrate-only` 不可省）**。另：依赖零变化（`package.json` / `package-lock.json` 不在差异清单内）、nginx 零变化、无需重传工具包。
- **★ 纠正一处此前的错误判断（我上一轮说错的）**：上一轮我说 `C:/shots/_master-uncommitted-backup-20260922` 是「master 那笔活儿的备份」。**本轮实测比对后发现它只是中途快照、已过时** —— 备份里 `厂家后台使用说明/` 只有 **11 个文件 / 1.74 MB**、脚本 **7,221 字节**；而**工作区**里是 **30 个文件 / ≈2.9 MB**、脚本 **13,507 字节**。⇒ **工作区那份才是最新，绝不能拿备份盖工作区。** 另备份里有个乱码空目录 `鍘傚鍚庡彴浣跨敤璇存槑`（0 子项，非 UTF-8 感知的操作产生），已在文档里标注别被它误导。
- **文档还固化了三件事**：① master 那笔活儿分散在**三处**（`stash@{0}` 只含 PROJECT_LOG 条目 / 工作区两个未跟踪项 / 过时的备份目录），并给出**必须在 master 上 `stash pop`** 的恢复顺序与警告；② 铁律扩充到 10 条（新增「部署顺序：补列→构建→reload」「静态资源清单构建期固化」两条因果型铁律）；③ 待办按 P0/P1/P2 重排，新增两条本轮发现的技术债 —— **`server/utils/risk-alert.ts` 有两行缩进异常**（`21ade81` 带进来的纯格式瑕疵，无功能影响）与**冗余分支 `codex-ycdb`**（清理需用户确认）。
- **同步更新**：`AGENTS.md` 顶部新增「当前状态指针」块（直接指向 20 号 + 三条避免踩空的要点）；`docs/handover/README.md` 索引与「按顺序读」两处补 20 号、并把 16/17 号标注为「状态段已被取代 / 已执行完勿重跑」。
- **修改文件**：新增 `docs/handover/20-交接手册-新对话接续（ycdb分支与待部署清单）.md` · `AGENTS.md` · `docs/handover/README.md` · 本条目 · `.workbuddy/memory/2026-09-22.md`。**代码零改动，未部署服务器。**

### 2026-09-22 | feat：外部二维码核验摆脱「只认 wla1.cn」—— 改为平台无关的通用字段提取 + 页面内容粘贴兜底
- **结果一句话**：拿一瓶真实农药（第三方平台 `mashangzhuisu.com` 出的码）走「外部二维码核验」，原实现**什么都提不出来**。已改为**平台无关的四路通用字段提取**，并新增「粘贴来源页面内容」兜底通道；真浏览器端到端核验通过，结论 **「已核验项目未发现差异」**（六项全相符）。提交 `e0b0203`，分支 `ycdb`，**master 未动**。
- **改前的天花板（为什么非改不可）**：`ycdb` 上外部核验**只对 `wla1.cn` 有专用接口**，其余平台统一落到 `fetchGenericPage` —— **而那个兜底只把页面 `<title>` 当产品名**。第三方平台实测是**纯 JS 渲染**，服务端拿到空壳 HTML、`<title>` 里也没有产品信息 ⇒ 整条链路只能返回"信息不足"。**用户在两方案间明确选了"通用提取"**（另一方案是为该平台写专用适配器——即逆向别人的私有 API，随时会失效，脆弱且不可持续）。
- **通用提取的四路兜底（`extractLabeledFields`）**：① **JS/JSON 键值对**（`"productName":"xxx"`，对 SSR 直出 JSON 的页面有效）② **逐行「标签:值」** ③ **表格相邻单元格**（`stripHtmlToText` 特意把 `td`/`th` 转成制表符，让同行「标签｜值」能拼回一段文本）④ **标签独占一行则取下一行**。配套三件套：`FIELD_ALIASES`（9 字段 × 中英标签/键名别名）· `NOISE_LABELS` 噪声黑名单（使用方法/产品性能/注意事项…，防止把"注意事项"后的长段落误当字段值）· `cleanFieldValue`（拒超长文本 / 链接 / 占位词）。
- **三个实测踩坑（★ 值得记）**：
  - **① `redirect: 'error'` 是"看起来更安全"的反面教材**：`http://mashangzhuisu.com` 会 301 到 `https://`，fetch 当场抛 `unexpected redirect` ⇒ 接口 **500**。改 `fetchSourcePage`：`redirect:'manual'` 自行判断，**同站 http→https 放行一次、跨站跳转拒绝（400）**。
  - **② 「见喷码」被当成生产日期落进结果**：占位词正则原为 `/^(见|未知|无|…)$/`，而真实标签写的是 **"见喷码"** 三个字 ⇒ 溜过闸门。已改为 `/^(见(喷码|包装|标签|瓶身|实物)?|未知|未提供|不详|待补充|待定|无|-|—|\/)$/`。**教训：占位词必须按真实标签怎么写穷举，不能按想象写。**
  - **③ 「2.85%硝钠·萘乙酸」≠「硝钠·萘乙酸」制造假差异**：来源页带含量、登记库不带 ⇒ 严格比对必 mismatch。新增 `normalizeProductName` 剥掉含量段做**宽松比对**；宽松命中结论仍是 `match`，但附备注「仅含量标注写法不同（含量请人工复核）」—— **既不误报差异，也不假装完全一致**。
- **一个刻意的设计决定**：`fetchGenericPage` **不再用 `<title>` 冒充产品名**。`<title>` 常是"XXX公司-追溯查询平台"这类站点标题，拿它当产品名只会制造**比空值更难排查的假差异**；宁可留空，并在 `warnings` 里引导用户粘贴页面内容。
- **兜底通道（纯 JS 渲染平台的唯一解）**：接口新增 `pageText` 入参（`fetchFromProvidedText`），`verifyExternalCode` 同时支持**从粘贴内容里识别追溯码**；后台页新增「在新窗口打开来源页面」入口 + 页面内容粘贴框，并补展示 `剂型 / 毒性 / 有效期至`。⇒ 流程是「开链接 → 肉眼复制正文 → 粘回核验」，**这是设计好的路径，不是缺陷**。
- **验证（接口 3/3 + 真浏览器端到端 1/1）**：① 接口三条路径（仅 URL / URL+粘贴 / 仅粘贴）**全部 200**；② 真浏览器在**同一会话内**完成真实登录 → SPA 跳转 → 填表 → 点【开始核验】，结论 **「已核验项目未发现差异」**，六项核验项（前 8 位编码结构 / 登记证后六位 / 登记证号 / 产品名称 / 登记持有人 / 生产类型）**全部"信息相符"**，来源数据区正确渲染 `2.85%硝钠·萘乙酸` / `500克` / `水剂` / `低毒` / `PD20092927`。截图 `C:/shots/ext-verify-result.png`。
- **业务结论（顺带验证了核验模型的正确性）**：码前 8 位 `1-092927-2`（1=PD + 登记证后六位 092927 + 2=委托加工）命中登记库 `PD20092927` 硝钠·萘乙酸 / 河南欣农化工有限公司；**登记数据存在（`pesticide_reg` 97,471 条），但我方无该产品** ⇒ `localProduct` 为空。**这正是"外部核验"应有的形态**：以国家登记库为基准核验他人的码，而非要求对方是本平台租户。
- **给下一个 Agent 的提示**：① 该页现有**三个输入**（来源链接 / 码值 / 页面内容），校验逻辑是"三者至少填一"，改的时候别只改两个；② 会话 Cookie **不跨 CDP 浏览器实例保存** ⇒ 真浏览器验证必须"登录 + 跳转 + 操作 + 断言"在**同一个会话**里跑完，否则会误判成"被踢回登录页"。
- **修改文件**：`server/utils/external-verification.ts` · `server/api/admin/external-verify.post.ts` · `shared/types/external-verification.ts` · `app/pages/admin/external-verify/index.vue` · 本条目 · `.workbuddy/memory/2026-09-22.md`。临时验证脚本（`C:/shots/_tmp-*`）用完即删。

### 2026-09-22 | fix：扫「未登记码」时三个按钮全是死的 —— 三处 `router` 未声明
- **结果一句话**：用户拿一瓶真实农药扫码验收结果页，发现扫到的码未登记。顺手真浏览器点了一遍未登记页的按钮，**点【重新查询】毫无反应**，控制台抛 `TypeError: Cannot read properties of undefined (reading 'push')`。根因是**模板里用了 `router`，`<script setup>` 里却没 `const router = useRouter()`**；全仓库排查出**同类三处**，已全部补上声明。
- **复现与定因（真浏览器 + CDP，非静态推断）**：访问 `/trace?code=<未登记码>` → 劫持 `console.error/warn` + `unhandledrejection` → 原生 `click()` 点【重新查询】→ 拿到 **`rejection: TypeError: Cannot read properties of undefined (reading 'push')`**，且 `location` **停在原 URL 完全没变**（按钮彻底失效，不是"跳得慢"）。
  - **为什么 `router` 会是 undefined**：实测该页 `#__nuxt.__vue_app__.config.globalProperties` 只有 **`$router` / `$route` / `$head` / `$unhead`** 四个键，**没有裸的 `router`** —— 所以模板里写 `router.xxx` 不会 fallback 到全局属性，直接拿到 `undefined`；组件 setup 里也没声明 → 必然炸。
  - **为什么静态检查抓不到**：`router` 只是模板表达式里的自由变量，**编译期合法**（`node --check` / SFC 编译 / TS 检查全静默通过），只有真点下去才炸。又一次印证本仓库既有结论：**改了模板/`setup()` 引用就必须真浏览器点一遍**。
- **同类三处（全仓库 grep `router.(push|back|replace)` 与 `useRouter` 交叉核对得出）**：
  | 文件 | 失效按钮 |
  |---|---|
  | `app/components/TraceNotFound.vue` | 【返回】`router.back()`、【重新查询】`router.push('/')` |
  | `app/components/TraceAlert.vue` | 【返回】`router.back()` |
  | `app/pages/nearby-stores.vue` | 移动端顶栏【返回】`router.back()` |
  （`TraceResult.vue` / `PageHeader.vue` / `index.vue` / `login.vue` / `scan.vue` / `layouts/admin.vue` 均有正确声明，不受影响。）
- **修改**：三个文件各加**一行** `const router = useRouter()`，位置放在既有 `const toast = useToast()` 之前，与 `TraceResult.vue` / `PageHeader.vue` 的既有写法保持一致。**零逻辑改动、零样式改动。**
- **验证（真浏览器前后对比，Edge headless + CDP）**：① 修复前 = 抛 `TypeError` + URL 不动（上表）；② 修复后未登记页**【重新查询】→ `location` 由 `/trace?code=…` 变为 `/`**、`errors: []`（首次跑因 dev 首编首页慢而 2.5s 内未跳完，预热首页后稳定通过 —— 记一笔：**dev 下验客户端跳转要先预热目标路由**）；③ 修复后异常页【返回】/ 附近门店页顶栏【返回】点击后 **CDP 报 `Inspected target navigated or closed`**，即 `router.back()` 已真实触发导航（未修前这类按钮只会抛错、页面纹丝不动 → 导航本身就是修复生效的证据）。
- **未做**：未为这三处补 e2e 用例（现有 `tools/_verify-*-ui.js` 体系面向后台页，公众端结果页尚无验证脚本）；若后续要防回归，建议按「三个结果分支各点一遍按钮」补一个公众端 UI 验证脚本。
- **修改文件**：`app/components/TraceNotFound.vue` · `app/components/TraceAlert.vue` · `app/pages/nearby-stores.vue` · 本条目 · `.workbuddy/memory/2026-09-22.md`。临时诊断脚本（`scripts/_tmp-*`，已 gitignore）用完即删。

### 2026-09-21 | ycdb 分支新增外部二维码核验首版
- **结果一句话**：新增后台「外部二维码核验」入口，支持相机扫描或粘贴系统外二维码链接，保存来源快照，解析并核验单元识别码第1—8位；第9位以后仅留证不判定，规格/生产日期等仅展示来源页面内容。
- **真实样本适配**：识别 `wla1.cn` 外部平台接口，样本码 `12618401501000000000003780168217` 可获取产品名、完整登记证号、持有人、规格、生产类型和生产日期字段。
- **后台与数据**：新增 `external_verification` 快照表、核验接口和历史查询接口；差异按登记证号/产品名/持有人等类型关联风险预警，外部核验记录不直接写入本平台产品或追溯码。
- **验证**：TypeScript 检查通过；Nuxt 生产构建通过；修改仅在 `ycdb` 分支，未触碰 `master`。
### 2026-09-21 | 追溯码生成上限 1 万 → 50 万：8 处散落限制收敛到单一常量文件 + >20 万二次确认
- **结果一句话**：用户要求「一次最多 50 万条追溯码」。原上限**散在 8 处各写各的数字**（生成链路 5 处 + 写入通道 3 处），已收敛为 `shared/utils/code-limits.ts` **单一事实源**并全部改为 50 万；新增「>20 万条二次确认」弹窗；下游入库/导入/解析的 10 万上限**同步提到 50 万**（否则生成 50 万后无法一次入库）。**服务器未动。**
- **为什么不能只改一个数字**：`10000` 在生成链路上被抄了 **5 遍** —— 引擎守卫（`server/utils/code-generator.ts`）+ 生成接口（`generate.post.ts`）+ 生成页 3 处（提交校验 / `UInput max` / 提示文案）。漏任何一处就是「前端放开、后端 400」或反之，且三处文案会各自漂移。另有 3 处独立的 `单次最多 10 万条码`（`stock-in` / `import` / `parse`）——**不改则 50 万生成后点【入库留档】必 400**，等于白生成。→ 8 处全部改为引用同一常量。
- **集中常量的内容**：`MAX_CODES_PER_BATCH`(50万) · `MAX_CODES_PER_WRITE`(50万) · `LARGE_BATCH_CONFIRM_THRESHOLD`(20万) · 派生文案（`GENERATE_QUANTITY_ERROR` / `GENERATE_QUANTITY_RANGE_TEXT` / `WRITE_QUANTITY_ERROR`，前后端同一份，杜绝 400 与前端提示不一致）· 估算函数 `estimateCodesSizeMb` / `estimateGenerateMs`（供确认弹窗用）；**文件顶部写明四条硬边界依据**（响应体积 / nginx 超时 / MySQL 占位符 65535 / 浏览器内存），让后续改动者一眼看到「为什么不能更大、能大到什么程度是实测出来的」。
- **实测基准（本机真实引擎，1 万 / 10 万 / 50 万三档，全部唯一且 32 位结构合法）**：耗时 **38 / 309 / 1518 ms**；响应 JSON 0.33 / 3.34 / **16.69 MB**（**接口实测 50 万全量响应 19.08 MB**）；urls.txt 0.62 / 6.20 / **30.99 MB**；堆增量 +2.9 / +8.9 / **+58.8 MB**。**结论：引擎不是瓶颈（1.5 秒），真瓶颈是响应体积与浏览器内存** —— 这也是本次要加二次确认的根本原因。另记：`CHUNK=5000 × 11 列 = 55000` 已贴 MySQL 占位符上限 65535，**只能减不能加**（50 万 = 100 块，事务内循环，逻辑无虞）。
- **验证（接口 4/4 + 真浏览器 3/3 + 生产构建 EXIT=0）**：
  - **接口**（临时脚本，本机 dev 3100）：生成 10001 条 → **200**（旧 1 万门槛确认解除）；500001 条 → **400「生成数量须为 1-50 万」**；**500000 条 → 200**，数量 500000、唯一性 true、32 位结构 true，耗时 **1712ms**、响应 **19.08MB**；解析接口传 500001 行 → **400「单次最多 50 万条码」**（写入通道上限已同步）。
  - **真浏览器**（Edge headless + CDP 真点击 + 截图，**走真实登录表单，不伪造登录态**）：① 提示文案渲染为「1-50 万条/次；超过 20 万条会先弹确认框（提示文件体积与耗时）」、输入框 `max=500000`、默认值仍 100；② 填 **200001** 点生成 → **弹窗出现**，文案「本次共 200,001 条 / 服务端生成预计约 0.6 秒 / TXT 6.3 MB · urls.txt 11.8 MB · CSV 30.5 MB」；③ **填 5 万点生成 → 不弹窗、直接出结果**（阈值闸门有效）；④ 点【确认生成】→ **生成总数由 50,000 变为 200,001**、唯一数 199,973、重码 28、耗时 **0.62s**（与弹窗预估 0.6 秒吻合）、弹窗关闭。截图 `C:/shots/nz315-bigconfirm.png`（弹窗态）与 `C:/shots/nz315-result.png`（200,001 条结果态）。
- **两个踩坑（写给下一个 Agent）**：① **Nuxt UI v4 的 `USelect`（Reka UI）选项不吃合成的 MouseEvent / PointerEvent** —— 分层试了三轮（PointerEvent 三连 → 触发器 ArrowDown+Enter → 选项 `.click()` + 选项上 `keydown Enter`），**最终生效的是最后一种**；照 EP 时代的经验点点不动会白排查很久。② **不要以「元素是否存在/当前值」断言异步结果** —— 首次断言时读到的是**上一轮遗留结果（50,000）**并误判成「确认按钮没生效」，必须**等「值发生变化」再判定**（本轮已改为 `total !== before`）。
- **未做（需用户决策，均已在 AGENTS.md 记录）**：① nginx `proxy_read_timeout 120s` 未动 —— 19MB 响应仅在极慢链路（<1.5 Mbps）才可能超时，属可选优化，本次不引入无谓的线上配置变更；② `deploy/nginx-nz315.conf` 里「10 万条码文件校验耗时较长」的注释未同步（纯注释，同步反而会让服务器上的实际配置与本仓库文本产生漂移）；③ 离线工具经核查**支持多文件合并导入、其 1000 万上限仅作用于「离线应急生成」模式**，因此**非阻塞**，网站导出 50 万单文件可直接拖入。
- **修改文件**：新增 `shared/utils/code-limits.ts` · `server/utils/code-generator.ts` · `server/api/admin/codes/{generate,stock-in,import,parse}.post.ts` · `app/pages/admin/generator/index.vue` · `AGENTS.md`（进度段新增条目 + 日期改 09-21）· 本条目 · `.workbuddy/memory/2026-09-21.md`。临时验证脚本与日志（`scripts/_tmp-*`、`logs/_*`，均已 gitignore）用完即删。

### 2026-09-19 | 部署包重打（基线 02f4d5c）：修掉「删旧工具包 → 下载按钮 404」的连锁问题 + 新增 18 号上传流程
- **结果一句话**：用户确认「可以删掉」旧工具包 v1.1.0 并问「工具怎么上传」。核查中发现**原上线包与这个新决定互相冲突** → 已把上线包重打为 **`nz315-master-02f4d5c.tar.gz`（720,769 字节 / SHA256 `caee6531f07a13022258b47deab96ef2dae134e60f5bd9c3b82aece4c27c5b8a`）**，并新增**可复用**的 `docs/handover/18-离线工具包构建与上传流程.md`。**服务器未动。**
- **🔴 差点上线才炸的连锁问题**：原包 `nz315-master-933a12a.tar.gz` 里 `generator/index.vue` 的 `OFFLINE_TOOL.url` 还是 `/tools/nz315-qr-tool-v1.1.0.exe`（v1.2.0 的接入是本节上面那条 commit `ff12f76` 才有的）。若照原样部署 **并且** 按用户要求删掉服务器上的 v1.1.0 → 生成页「下载离线工具」按钮**必然 404**。**这是"两个各自正确的决定拼在一起就出事"的典型**：删旧包对、部署旧包也说得通，一起做就错。教训：**当本次任务包含"删除某个线上资源"时，必须回头核对所有引用该资源的代码/文档是否已在本次部署范围内更新。**
- **★ 一条决定上传顺序的实测结论（本机拿到硬证据）**：Nitro 把静态资源清单**构建期固化**进产物 —— 实测 `.output/server/chunks/_/nitro.mjs` 里逐条列着 `/tools/nz315-qr-tool-v1.1.0.exe` 的 `type: application/octet-stream` / `etag` / `size: 95030861` / `path: ../public/tools/...`。⇒ **工具包必须在 `npm run build` 之前放进 `public/tools/`**；build 之后再往 `.output/public/` 丢文件，清单里没有它 ⇒ **404，且 `pm2 reload` 不管用**。执行单据此把上传排在构建之前（新增 5.0）。
- **打包自验（按 tar-deploy-package 技能流程，全绿）**：`git archive` 打 `02f4d5c` → 170 文件 + 56 目录；自写 tar 解析器与 `git -c core.quotePath=false ls-tree -r` **双向**核对（「包内多出」= 无、「git 有而包内无」= 无）；排除项 `无 .env / node_modules / .output / .nuxt / public/tools`；关键文件逐一点名（含 `generator/index.vue` 24,250 字节）；**从包里直接读出生成页常量，确认已是 `v1.2.0` + 新 SHA256**；依赖零变化（`git diff 933a12a..HEAD -- package.json package-lock.json` 为空）。**旧包已从交付目录删除**（防手滑传错版本）。
- **新增 `docs/handover/18-离线工具包构建与上传流程.md`（可复用，不随版本过期）**：三个关键事实（工具源码在本机且**非 git 仓库** / 发布件被 gitignore 故代码包不含它 / 清单构建期固化）+ **顺序铁律** + 流程 A 本机发版（改版本 → **用系统 Node 24 打包**（托管 Node 22 会 PNG→ICO 步骤 V8 OOM）/ `unset ELECTRON_RUN_AS_NODE` 跑 E2E / 三套自验 / 落位 / **`fileName` vs `url` 的命名差异**）+ 流程 B 服务器上传（传 → `sha256sum` + 删旧 → build → 公网 curl + 浏览器双验）+ 常见坑表 + **版本登记表**。
- **17 号执行单同步更新（6 处）**：代码包路径/字节/SHA256 换新；备份目录名 → `nz315-backup-02f4d5c-$TS`；总览表第 5 步加「5.0 放工具包」；第 3 步 `public/tools/` 期望改为「此刻仍是旧版 v1.1.0，属正常别慌」；**新增 5.0**（宝塔上传路径 + SHA256 判据 + 为何不能 build 后再放 + 旧版为何必须删）；**新增 6.5**（`curl -sI` 200/404 + 「curl 200 ≠ 页面上点得动 —— 按钮走 `fetch → Blob`」）；第 7 步 `code_base` / `note` 同步（note 记 `public/tools` 已换 v1.2.0 并删 v1.1.0）。
- **`docs/handover/README.md`**：索引补 18 号，并**补上此前漏登记的 14 / 15 号**（两个文件确实存在，但一直没进 §四清单）。
- **修改文件**：`docs/handover/17-部署执行单-安全加固上线.md` · 新增 `docs/handover/18-离线工具包构建与上传流程.md` · `docs/handover/README.md` · `AGENTS.md`（顶部部署块 ③ 改写 +「项目进度」新增条目 + 上面 v1.2.0 条目里「v1.1.0 仍在原位未删」改为**已删**）· 本条目 · `.workbuddy/memory/2026-09-19.md`。**交付件**：`E:\software\workbuddy\文件存放处\2026-09-19-1750-安全加固与工具v1.2.0\nz315-master-02f4d5c.tar.gz`（旧包同目录已删）。

### 2026-09-19 | 离线工具改造 v1.2.0：从「自己造码」改为「导入平台码文件 → 只出图」
- **结果一句话**：用户提出「当前离线工具自己生成追溯码，与网站生成的码规格对不上，出图后还得再录入网站，数据一更新又要重发工具」，要求改成**纯生图工具**。已完成改造并打包 **v1.2.0**（`95,035,957` 字节 / SHA256 `04373ae1dc21752636f1b68945edb2dca8cff19c8b005b2ace1070cbc0a72fe8`），工具侧三套测试 **33 项全绿**；网站生成页已接入新包并改写操作说明。**EXE 为 gitignored，上线须单独上传。**
- **为什么不是重做（技术底牌）**：`app/main.js` 的 `ipcMain.handle('qr-generate')` 入参本就是 `config.items`（**码 / URL 字符串数组**）——**出图引擎天生与「码从哪来」解耦**，renderer 只是喂了本地生成的码。故只需把码来源换成「导入文件解析结果」，出图链路 / 进度条 / 停止 / 前 3 张预览 / 文件命名全部原样复用，**`main.js` 一行未改**。
- **挖出「规格对不上」的两个真根因**：① **两边码算法不同** —— 工具为 `前11位 + 毫秒时间戳13位 + 纯随机8位`（**无校验位**），平台为 `前11位 + [时间戳+6位随机+2位校验]截19位 + 前30位的 MD5 末2位`（**有校验位**），同一产品两边出的码根本不同；② **规格码数据源不同** —— 工具用内置快照 `data.json`（2025-06-01），平台用 `product_spec` 活数据。纯生图改造后**两者同时消失**（码统一由平台产出，工具只当打印机）。
- **顺手修掉一处既有 bug**：工具「追溯查询地址」默认值是 `https://www.cynx.cn/pesticide.php?sn=` —— **指着旧站且参数名是 `?sn=`** 而非平台的 `?code=`，即工具出的图本来就扫不到 nz315。已改为 `https://www.nz315.cn/trace?code=`。
- **工具侧改动**（工程目录 `E:\wokeplace\二维码生成离线软件`，**独立于本仓库，且非 git 仓库**）：
  | 文件 | 改动 |
  |---|---|
  | `app/renderer/parse-codes.js` | **新增**：码文件解析器（独立文件便于单测）—— 剥离 BOM、兼容 CRLF、识别 urls.txt / 纯码 TXT / sn 清单 CSV / 多列粘贴文本、跨文件去重、CSV 表头跳过、无前缀时拒收纯码 |
  | `app/renderer/app.js` | 新增导入模块（拖拽 + 多选合并 + 统计 + 前 5 条预览 + 清空）；码源改为「导入优先，否则离线应急」；文件名前缀默认取导入文件名；补 `'use strict'` |
  | `app/renderer/index.html` | 重排为 **① 导入码文件（主流程）→ ② 输出二维码图片 → ③ 更新与设置**；原「企业 / 证号 / 规格 / 生成 / 导出」五步**折叠为「离线应急生成」**；模块大小提示改为 DataMatrix 建议 ≥4 |
  | `app/package.json` | 版本 → `1.2.0`，描述改写 |
  | `test/test-parse-codes.js` · `test/test-electron-import.js` · `test/verify-qr-output.js` | **新增**三套测试 |
- **验证（33 项全绿）**：① 解析器单测 **10/10**；② **真实 Electron 端到端 18/18**（拖入带 BOM 的 urls.txt + 纯码 CRLF 文本 → 断言解析条数 / 跨文件去重 / 首条无 BOM 残留 / 前缀自动识别与回填 / 出图入参 / 数量超限夹取 / 清空复位）；③ 出图可解码性 **5/5**（生成的 PNG 用 zxing 读回原文，QR 3/4/6px 与 DM 4/6px 内容全部一致）。
- **两个实测发现（已固化进文档）**：① **DataMatrix 模块 3px 时 zxing 解不出**（`FormatException`），4px 起稳定 → 界面提示已改为「DataMatrix 建议 ≥4」；② **环境坑**：沙箱注入的 `ELECTRON_RUN_AS_NODE=1` 会把 Electron 降级成纯 Node（`require('electron')` 报 MODULE_NOT_FOUND、`--no-sandbox` 报 bad option）→ 必须 `unset`（**设空值无效**，Electron 判的是"变量是否存在"）并加 `--no-sandbox`；且**托管 Node 22 跑 electron-builder 会在「PNG→ICO」步骤 V8 OOM 崩**（exit `2147483651`），**换系统 Node 24 打包即通过**。
- **网站侧改动**：`app/pages/admin/generator/index.vue` —— `OFFLINE_TOOL` 常量更新为 v1.2.0（新 size / SHA256 / URL / 名称）、操作说明改为 5 步（含「可一次拖入多个文件自动合并去重」「DataMatrix 建议 ≥4」「印刷前微信扫验」）、页头描述同步；新包落位 `public/tools/nz315-qr-tool-v1.2.0.exe`（SHA256 与打包源文件逐字节一致）。SFC 编译校验通过（解析 / 模板 / script 三处零错误）。
- **给下一个 Agent 的提示**：① **`public/tools/*.exe` 是 gitignored**（`.gitignore` 已注明"部署时需单独拷贝该目录到服务器"）→ 本次上线**必须单独上传 90MB 的 v1.2.0 包**，否则生成页下载按钮 404；② `public/tools/` 里旧的 `nz315-qr-tool-v1.1.0.exe` **暂未删除**（建议删，但等用户确认）；③ 工具源码目录**不是 git 仓库**，本次改动无法用版本控制回溯，建议尽快 `git init`。
- **修改文件**：`E:\wokeplace\二维码生成离线软件\{README.md, 数据更新操作指南.md, app/package.json, app/renderer/index.html, app/renderer/app.js, app/renderer/parse-codes.js, test/test-parse-codes.js, test/test-electron-import.js, test/verify-qr-output.js}` · `E:\二维码管理\{app/pages/admin/generator/index.vue, public/tools/nz315-qr-tool-v1.2.0.exe}` · 本条目 · `.workbuddy/memory/2026-09-19.md`。

### 2026-09-19 | 部署前复核：迁移校验脚本三处「只在生产才暴露」的缺陷 + 17 号部署执行单 + 代码包就绪
- **结果一句话**：准备本次部署（用户要求「部署新版本到线上服务器」）时，按"每条命令都要有证据"的规矩复核 `scripts/verify-db-migration.mjs`，发现**它在真实生产库上第一步就会崩**——连同另外两处「只在生产条件下才暴露」的判据缺陷一并修掉（提交 `f379264`）；生成上线代码包 `nz315-master-f379264.tar.gz`（**694,642 字节 / SHA256 `2a21dcea…6243`**，169 文件，已逐条与 `git ls-tree` 核对）；新增 **`docs/handover/17-部署执行单-安全加固上线.md`**（逐条命令 + 期望输出 + 回滚 + 卡点速查）。**部署尚未执行**（服务器操作由用户在宝塔终端逐条粘贴，SSH 在我这边不可用）。
- **缺陷 ①（致命，会当场卡住部署）**：`snapshot()` 里 `SELECT id, username, role, status, session_epoch FROM user` —— 而 **`session_epoch` 正是本次要补的新列，补列前它不存在**。三明治用法的第一步 `dump` 是「补列**之前**」跑的，于是在生产库上必然以 `ER_BAD_FIELD_ERROR: Unknown column 'session_epoch' in 'field list'` 中止。**本机库该列已在位（09-19 下午已跑过 migrate），所以这条分支在本机永远走不到 —— 典型的"本地全绿、上线必炸"。** 修法：先查 `information_schema.COLUMNS` 探测列存在性，缺失时用 `CAST(0 AS SIGNED) AS session_epoch` 兜底（与 ALTER 的 `DEFAULT 0` 对齐，保证迁移前后账号维度仍可逐字段比对）。
- **缺陷 ②（假 FAIL，会盖掉真红字）**：原比对要求**全部表**行数严格相等。但 `scan_log` / `operation_log` 是**纯追加日志**——线上真实消费者扫码、管理员登录都会写它们。部署窗口期（几分钟）内只要有一个真人在用，`compare` 就报 FAIL，而人会看到"数据被污染了"的红字指向一张日志表。修法：区分「业务主数据（严格相等）」与「活跃日志表（只增不减，打印 `注意`，不计入 FAIL）」。业务主数据表仍是严格要求——`seed()` 若被误跑，`enterprise`/`trace_code`/`product`/`batch`/`upload_batch`/`product_spec`/`product_original` 必被命中，一个都跑不掉。
- **缺陷 ③（同类假 FAIL）**：`session_epoch` 被纳入账号维度严格比对——它随**登出 / 改密 / 重置密码**正常变化，部署窗口里任何人登出一次就会变。修法：账号维度只比 `id/username/role/status`，`session_epoch` 降级为**留证打印**（`基线非零账号 / 现在非零账号`）。
- **另加一道防线**：基线文件带 `scriptVersion`，结构一变即**拒绝比对**并提示重新 `dump`，避免拿过期基线当证据（此前只能靠人记住"别把过期基线当证据"）。
- **验证（四条，均本机实跑）**：
  1. 本机真实库 `dump → compare` → **PASS**（15 张表、`MAX(id)` 八项全等、企业/账号/追溯码快照全等）。
  2. **人为下调基线模拟两类场景**：把 `scan_log` / `operation_log` 各 −1 → 仅打印 `注意 …（活跃表，允许正常增长）`、**exit 0**；把 `trace_code` −1 → **`FAIL  trace_code  103 -> 104`、exit 1** → **证明"放宽"只放宽了日志表，核心表判据没有松**。
  3. **独立临时库完整演练生产补列场景**（建表 → 人为 `DROP COLUMN session_epoch` 造出"线上库形态" → 再跑 `--migrate-only`）：脚本正确输出 `[db] 迁移：user 补充列 session_epoch（会话吊销）`、列被补回（`bigint / NOT NULL / DEFAULT 0 / 第 12 位`），且 `enterprise`/`user`/`trace_code`/`upload_batch`/`product`/`product_spec`/`batch`/`product_original` **八张表行数全为 0 → 零业务写入**；演练用临时库与 `.env` 改动均已还原（复核 `DB_NAME=nz315`）。
  4. 兜底 SQL 形态验证：探测真实列返回 1 行、探测不存在列返回 0 行；`CAST(0 AS SIGNED)` 与真实列读出的值类型均为 `number`，JSON 序列化可比对。
- **上线产物**：`nz315-master-f379264.tar.gz`（`git archive` 打包，天然不含 `.env` / `.output` / `node_modules` / 90MB 离线工具 EXE）；**依赖零变化**（`package.json`/`package-lock.json` 自 09-16 部署以来未改，服务器无需装新依赖）。
- **17 号文档要点**：7 步执行单（体检 → 备份代码+库 → 上传校验 sha256 → 解包并**把 PM2 配置换回服务器修正版** → **补列三明治** → 构建+`pm2 reload` → 验证+写部署标记）；含**误判对照表**（活跃表"注意"≠污染、业务表 `FAIL` 才停手）、**`db-init` 权限报错的 SQL 备选**（应用账号无 `CREATE DATABASE` 权限时走同一句 ALTER）、回滚两条路、卡点速查。**17 号是执行口径的唯一来源**（16 号 §5.1 的旧比对口径已就地标注推翻）。
- **两处口径需下一个 Agent 注意**：① **`viewer/admin123` 只存在于本机库**，线上没有该账号 → 想在线上验收"只读收口"须先在线上建一个 viewer（系统设置 → 用户权限 → 新增用户 → 只读账号），**验完删掉**（已写进 `AGENTS.md` 与 17 号）；② `deploy/ecosystem.config.cjs` 在仓库里仍是**未修正的原始版**（`PORT: 3000`、无 `interpreter`），每次解包都会盖掉服务器那份修正版 —— 17 号第 3 步已把它列为**必做动作**，长期方案应是把修正版直接入库（本轮未做，避免动部署面）。
- **修改文件**：`scripts/verify-db-migration.mjs` · 新增 `docs/handover/17-部署执行单-安全加固上线.md` · `docs/handover/16-…`（§5.1 口径修正 + 指向 17 号）· `docs/handover/README.md`（索引）· `AGENTS.md`（部署块 + 常用命令表）· 本条目 · `.workbuddy/memory/2026-09-19.md`。

### 2026-09-19 | 堵住「部署须补列」指令的生产库污染雷（`db-init` 补 `--migrate-only`）+ 16 号交接文档
- **结果一句话**：给 `scripts/db-init.mjs` 补出 **`--migrate-only`** 参数（只建表 + 增量迁移，跳过演示数据），**实测零写入 PASS**；修正 3 处文档中由我本人写下的**危险部署指令**；新增 `docs/handover/16-交接手册-安全加固收尾与新对话接续.md`（自包含交接文档）。**未部署服务器**。
- **怎么发现的**：写交接文档时核对"部署前先跑 `node scripts/db-init.mjs` 补 `session_epoch` 列"这条指令 —— 翻源码发现 `main()` **无条件执行 `seed()` 与 `backfillUploadBatches()`**，而交接文档 13 号原本明写「本次部署零数据库变更，**绝对不要在生产库跑 db-init**」。**两条既有指令正面冲突，且错在我这一侧。**
- **为什么 seed 危险（不是"幂等可重跑"就安全）**：`seed()` 的保护只是「按名字/证号查存在才插」：
  | seed 内容 | 真实库后果 |
  |---|---|
  | 演示企业「山东绿丰生物科技有限公司」（按 `name` 查） | 真实库企业名对不上 → **实打实新建** |
  | 4 条演示追溯码 `1230101*`（含已冻结 / 已作废） | **插进 `trace_code` 核心业务表** |
  | 演示规格 / 产品 / 原药 / 批次 | 按证号查存在才插，不存在则插入 |
  | `admin` / `lvfeng` / `codeop` 三个 `admin123` 账号 | 已存在则不插；**线上若已按安全清单删过 → 以 `admin123` 重建** |

  **活证据（本机库实测）**：`enterprise` id=1「山东绿丰农药有限公司」（真实业务，2026-08-31 建）与 **id=2「山东绿丰生物科技有限公司」（seed 建，2026-09-03）** 并存；4 条 `1230101*` 码 `enterprise_id=2`、`created_at` 全为 09-05 → **确属 seed 写入**。
- **修复**：`--migrate-only` 跳过 `seed()` 与 `backfillUploadBatches()`；顶部注释写明红线与本次事故背景；seed 执行前主动打印「⚠️ 即将写入演示数据…（生产/真实库请改用 `--migrate-only`）」。另新增常驻脚本 `scripts/verify-db-migration.mjs` 作为「零写入」的客观留证手段。
- **验证（实测 PASS）**：新增**常驻校验脚本 `scripts/verify-db-migration.mjs`**（`dump` 记基线 → 跑迁移 → `compare` 逐表比对；三明治用法，真实库部署时同样适用），在跑迁移前后比对 —— **15 张表行数全等**（含 `trace_code` 104、`pesticide_reg` 97,471、`user` 6）· **`MAX(id)` 自增位未推进**（ent/usr/code/ub/prod/spec/batch/orig 八项全等）· **企业名单 / 账号（含 `session_epoch`）/ 追溯码前 30 条快照全等** → **PASS（业务数据零变化）**；运行日志确认无任何「迁移：」行（列已存在时 `migrate()` 全 no-op）→ **幂等成立**。
- **文档修正（3 处，均为修正我本人上午写下的字）**：`AGENTS.md`（顶部「待部署的安全加固」块 → 明确 `--migrate-only` 不可省 + 常用命令表新增一行 + 进度段）；`PROJECT_LOG.md`（09-19 前端收口条目下的「数据库依赖」追述）；`.workbuddy/memory/2026-09-19.md`。
- **新增交接文档**：`docs/handover/16-交接手册-安全加固收尾与新对话接续.md` —— 60 秒必读 / 三提交因果链 / 本机与服务器状态 / **三条机制的边界说明**（为何 `issuedAt <` 用严格小于、为何旧两段 token 必须拒、为何 Origin 必须精确比对）/ 本机验证清单 / **部署动作清单**（补列 → 构建 → `pm2 reload`，含 §5.1 的零脚本 SQL 备选）/ 7 条铁律 / 踩坑与可复用配方 / 待办 / 文档索引。`docs/handover/README.md` 索引同步：16 号标为最新，13 号降为「服务器事实仍有效」。
- **给下一个 Agent 的提示**：① **`db-init` 这类"初始化 + 演示数据"混合脚本，需要"只做结构变更"时先读源码确认 `seed` 是否受控**——文档写"幂等可重跑"不等于安全，**幂等 ≠ 无害**，「查存在才插」在**另一个数据集**上等价于「无条件插」；② 部署补列用 **`node scripts/db-init.mjs --migrate-only`**，或走 16 号文档 §5.1 的幂等 SQL（零脚本执行）；③ 判断"某条命令能不能在生产库跑"**不能只看文档，要看它调用的函数**——本轮就是文档对文档打架；④ 本次修复**尚未部署服务器**。

### 2026-09-19 | 前端按角色收口 + 补齐三项后端遗留（会话吊销 / 登录 Origin 校验 / 生成数量 0 边界）
- **结果一句话**：改动 17 个文件（后端 5 · 数据库迁移 1 · 前端 11）——**登录/登出补上服务端会话吊销 + 跨站校验**、**登录接口补 Origin 校验（并顺手修掉一个前缀绕过漏洞）**、**生成数量 0 不再被吞成 100**、**前端按角色隐藏全部写入口**（菜单/按钮/面板/页头入口 + 只读提示条）；**后端回归 27/27 PASS**、**生产构建 EXIT=0**、**真浏览器（Edge headless + CDP）双角色截图实测通过**；**未部署服务器**（线上仍为旧版本，待部署窗口）。
- **来源**：同日安全测试报告 `docs/测试报告-2026-09-19-功能与安全测试.md` 登记的四项遗留（前三项本条目修复，第四项「前端未按角色隐藏入口」即本轮主任务）。用户原话：「前端还没按角色藏按钮 …… 属已登记的遗留项（连同 quantity:0 被吞、登出无吊销、登录无 Origin 校验，这些你也补齐吧」。
- **① 会话吊销（登出/改密即失效）**：原实现只清客户端 cookie——**token 本身仍在 7 天有效期内，被复制后依旧可用**，改密码也踢不掉已经登录的会话（账号被盗场景形同虚设）。修法：`user` 表新增 **`session_epoch BIGINT`** 列（`scripts/db-init.mjs` DDL + 幂等 `migrate()` 双写，本机已跑通），token payload 由两段 `userId.expiry` 升级为**三段 `userId.expiry.issuedAt`**；`getCurrentUser` 增加判定 **`issuedAt < session_epoch` → 视为未登录**。登出（`logout.post.ts`）与重置密码（`users/[id]/reset-password.post.ts`）都会把 `session_epoch` 刷到当前毫秒。判定用**严格小于**，避免同毫秒内「登出 → 立刻重登」被误杀。
- **② 登录接口补跨站校验（顺带修掉一个真漏洞）**：`login.post.ts` 此前完全不校验 Origin（登录 CSRF 面）。补上后**发现 `assertSameOrigin` 本身有缺陷**——旧写法是 `origin.startsWith('http://' + host)`，**前缀比较**：`https://www.nz315.cn.evil.com` 可以穿过（攻击者注册同前缀域名即可绕过全部写接口的 CSRF 防护）；且 `http`/`https` 混用时（反代终结 TLS）会**误拒同站请求**。已改为**取 `x-forwarded-host || host` 后做完整 origin 精确比对**。无 Origin 的请求（curl / 服务端调用 / Node fetch）照旧放行，不影响 API 客户端。
- **③ 生成数量 0 边界**：`codes/generate.post.ts` 原写 `Number(body.quantity || 100)`——**`0` 是 falsy，传 0 反而生成 100 个码**（一个"静默放大请求"的坑）。改为仅 `undefined/null/''` 落默认 100，其余一律进 1–10000 区间校验；`0`/负数/非数字现在稳定 **400**。
- **④ 前端按角色收口（本轮主任务）**：`useUser()` 新增 **`canWrite`（非 viewer）** 与 **`canManageUsers`（platform_admin / enterprise_admin）** 两个 computed，与后端 `requireWritableUser` / `users` 三件套白名单**逐条对齐**，共改 11 个前端文件：
  | 位置 | 收口方式 |
  |---|---|
  | `app/layouts/admin.vue` | 侧栏菜单带 `writeOnly` 标记（追溯码生成 / 追溯码上传），只读账号**整条隐藏**（进去只剩空白页，没必要给）；内容区顶部加只读**提示条**，避免用户以为"功能丢了" |
  | 8 个业务页（alerts/batches/codes/collection/generator/messages/products/specs） | 表头【新增】、行内【编辑/删除/冻结/作废/修正/绑定/恢复正常/处理/标为已读】、各确认弹窗的**确认按钮**、文件选择与【解析校验】【导入】【生成追溯码】等约 40 处 `v-if="canWrite && …"` |
  | `app/pages/admin/settings/index.vue` | Tab 列表改 `settingsTabs` computed——**用户权限**仅 `canManageUsers` 可见、**数据备份**仅 `isPlatformAdmin` 可见；企业信息保存按钮按 `canManageUsers` 隐藏并给出"当前角色不可修改"说明 |
- **验证证据（三层，均本机实跑）**：
  1. **后端回归 27/27 PASS**：三段 token 正常登录/鉴权；**旧两段 token 一律 401**；登出后旧 token **401**；重置密码后旧 token **401**；`quantity:0`→**400**、`quantity:3`→**3 个码**、不传→**100**；同站 Origin 登录 **200**；`http://127.0.0.1:3100.evil.com` 与写接口前缀伪造 **403**；无 Origin / 跨主机请求按预期放行。
  2. **生产构建 `nuxt build` EXIT=0**。
  3. **真浏览器（Edge headless + CDP）双角色实测**（同一页面同一次会话，仅换身份）：`/admin/codes` → viewer 侧栏 **9 项**（无追溯码生成/上传）、行内按钮**只剩【详细】**；platform_admin 侧栏 **11 项**、行内按钮 **详细/冻结/新建批次并绑定/修正/删除**齐全、无只读提示条。`/admin/settings` → viewer Tab **只剩【企业信息】【操作日志】**且无【保存企业信息】；platform_admin **四个 Tab 齐全**。
- **数据卫生**：验证用的临时 viewer 账号（`tmpviewer`）已删除（复核残留 0，账号表回到 5 个原账号）；临时脚本、日志、浏览器 profile 全部清理。
- **修改文件**：`server/utils/auth.ts` · `server/api/auth/login.post.ts` · `server/api/auth/logout.post.ts` · `server/api/admin/users/[id]/reset-password.post.ts` · `server/api/admin/codes/generate.post.ts` · `scripts/db-init.mjs` · `app/composables/useUser.ts` · `app/layouts/admin.vue` · `app/pages/admin/{alerts,batches,codes,collection,generator,messages,products,settings,specs}/index.vue` · `AGENTS.md` · 本条目 · `.workbuddy/memory/2026-09-19.md`。
- **⚠️ 升级副作用（部署时必须知道）**：token 格式由两段改三段，`verifySessionToken` **主动拒绝旧格式**（旧 token 无法承载签发时间，服务端无从判断其是否已被吊销，只能一律作废）→ **部署后所有在线用户需重新登录一次**，属预期行为，不是故障。
- **⚠️ 数据库依赖**：`user.session_epoch` 是**新增列**，服务器库需跑一次 **`node scripts/db-init.mjs --migrate-only`** 把列补上；**漏跑则登出/改密吊销静默失效**（`Number(undefined||0)=0`，判定恒不成立）。
  - 🔴 **`--migrate-only` 这个参数是本条目的同日追加修正（同日第二次提交）**：原先只写「跑 db-init」，但 `db-init.mjs` 的 `main()` **无条件执行 `seed()`** —— 演示企业「山东绿丰生物科技有限公司」（**按名字查存在才插**，真实库名字对不上就**新建**）、4 条演示追溯码（含冻结/作废码，插进 `trace_code` 核心业务表）、演示产品/批次、以及 3 个 `admin123` 演示账号。**本机库现存的企业 id=2 与 4 条 `1230101*` 码即为 seed 产物，是活证据。** 而交接文档 13 号原本明写「本次部署零数据库变更，**绝对不要跑 db-init**」——两条指令直接对撞。故给脚本补出 `--migrate-only`（只建表 + 增量迁移，跳过 seed 与历史码归档），并**实测验证零写入**：15 张表行数全部一致、`MAX(id)` 自增位未推进、企业名单/账号（含 `session_epoch`）/追溯码前 30 条快照全等 → **PASS**。
  - 备选（零脚本执行）路径：直接在服务器 MySQL 执行一条幂等 ALTER，见 `docs/handover/16-交接手册-安全加固收尾与新对话接续.md` §5.1。
- **给下一个 Agent 的提示**：① **新增写接口一律 `requireWritableUser`**，同步在页面按钮上加 `v-if="canWrite"`——**后端拦得住不等于体验收得干净**，本轮之前 viewer 是"看得见按钮、点了吃 403"；② 任何"能改变他人凭证状态"的写操作（改密、改角色、禁用）都要**顺带 `revokeUserSessions`**，否则旧会话在 TTL 内继续有效；③ 判断 Origin 一律**完整比对**，别用 `startsWith`（本轮实测可被同前缀域名绕过）；④ 前端新增"按角色可见"的入口时，去 `useUser()` 取 `canWrite`/`canManageUsers`，**别再直接比 `role === 'viewer'`**（散落判断迟早与后端白名单漂移）；⑤ 本次修复**尚未部署服务器**。

### 2026-09-19 | 修复 P0 提权漏洞与 P1 viewer 写守卫缺失（安全加固）
- **结果一句话**：改动 20 个后端文件——17 个写接口守卫 `requireBackendUser` → `requireWritableUser`，`users` 三件套补齐角色判断；**权限回归 46/46 通过**、生产构建通过；**未部署服务器**（线上仍为旧版本，待部署窗口）。
- **来源**：同日全量安全测试（报告 `docs/测试报告-2026-09-19-功能与安全测试.md`，**含复现细节勿推公开仓库**）。
- **P0 根因**：`users.post.ts` / `users/[id].patch.ts` / `users/[id]/reset-password.post.ts` 三处角色判断均写作 `if (user.role === 'enterprise_admin')`，**code_admin / viewer 直接穿透**（仅剩"不能操作 platform_admin"兜底），且入口守卫是 `requireBackendUser`。**祭品账号实测证据链**：viewer 重置厂家主账号密码 → **200** → 用新密码登录主账号 → **200（接管闭环）** → viewer 禁用主账号 → **200** → viewer 自建 code_admin 账号 → **200**。
- **P1 根因**：写守卫两套标准并存——`specs`/`products`/`backup` 用 `requireWritableUser`/`requirePlatformAdmin`（正确拦截 viewer），而 batches 全族、alerts/messages/settings patch、codes 全族共 17 个写接口只用 `requireBackendUser`。实测 viewer 建生产批次 → **200**、处理风险预警 → **200**、作废追溯码 → **200**。
- **修复内容**：① 17 个写接口守卫脚本化精确替换（每处断言命中 1 次，防误改）；② `users` 三件套新增白名单判断——仅 `platform_admin`/`enterprise_admin`，其余 403「需要厂家主账号权限」；③ 企业信息编辑（`settings/enterprise/[id].patch`，涉法人/许可证号/资质到期日等合规字段）收紧为主账号及以上；④ 保留全部原有约束（厂家不能建主账号、不能操作总部账号、跨企业 404）；⑤ `codes/parse` 为纯解析预览不写库，保持放行。
- **回归矩阵（46/46 PASS）**：viewer × 23 个写接口（batches 3 · alerts/messages/settings 3 · codes 12 · users 3 · products/specs/backup 3）**全 403**；viewer 读接口（codes/products/users 列表）仍 **200**；code_admin 用户管理与改企业信息 **403**、生成码/建批次/冻结码 **200**（未误伤）；enterprise_admin 建号/编辑/重置密码 **200**，建主账号 **400**、动总部账号 **403**；platform_admin 全通；未登录写接口 **401**。
- **数据卫生**：测试账号、测试批次、一次性码全部删除；码 1522 复核 `status=1 flag=0 batch_id=null`（未被误改）。
- **修改文件**：`server/api/admin/**` 20 个（batches 3 · alerts 1 · messages 1 · settings 1 · codes 12 · users 3 减去重复计）· `AGENTS.md`（守卫三级约定 + 进度段）· 本条目 · `.workbuddy/memory/2026-09-19.md`。
- **给下一个 Agent 的提示**：① **新增写接口一律用 `requireWritableUser`**，用 `requireBackendUser` 等于对 viewer 敞开——本轮 17 处全是这么来的；总部专属才用 `requirePlatformAdmin`；② 角色判断**别只写 `=== 'enterprise_admin'` 分支**（code_admin/viewer 会穿透），正确写法是"白名单 + 提前 403"；③ 前端尚未按角色隐藏操作入口，viewer 能看到按钮但点击 403，属已登记遗留项；④ 本次修复**尚未部署服务器**。

### 2026-09-18 | 阿里云 HTTPS 配好并通过公网验证（公众端摄像头前置条件达成）
- **结果一句话**：用户在宝塔终端执行「阿里云免费证书 → 证书落位 `/www/server/panel/vhost/cert/nz315/` → 改 `nz315.conf`（80 跳 301 + 443 反代 3100）→ `nginx -t && nginx -s reload`」，**零代码改动、零构建、零 PM2 重启**；本机从**公网侧**独立复测全部通过，`www.cynx.cn` 全程 online。
- **动机**：公众端扫码页要用摄像头，而 `navigator.mediaDevices.getUserMedia` 只在**安全上下文**（https 或 localhost）下可用 —— `app/composables/useQrScanner.ts:222` 的 `window.isSecureContext` 预检会在 http 下直接报「扫码需在 HTTPS 安全页面使用」。**HTTPS 是摄像头功能的硬前置。**
- **公网侧实测判据（本机 node 直连，非服务器本地回环）**：
  | 检查 | 结果 |
  |---|---|
  | 443 证书（SNI=www.nz315.cn） | `authorized: true`（信任链 OK）· `subject CN=www.nz315.cn` · **`SAN=DNS:www.nz315.cn, DNS:nz315.cn`** · issuer **DigiCert** · 到期 **2026-12-16** |
  | `https://www.nz315.cn/` | **200** · 标题「农资315 - 农药追溯查询」（**不再是 cynx**）|
  | `https://www.nz315.cn/login` | **200** |
  | **`https://www.nz315.cn/scan`** | **200** · 标题「扫码查询 - 农资315」← **摄像头页在安全上下文下可达** |
  | `http://www.nz315.cn/` | **301** → `Location: https://www.nz315.cn/` |
  | `https://www.cynx.cn/` | **200** · 标题正常 → **正式站未受影响** |
  | `pm2 list`（用户实跑） | **cynx online（21h）· nz315 online（24h）** |
- **混合内容预检（HTTPS 才暴露得出的雷）**：全仓库 `*.ts/*.vue/*.json/*.cjs/*.mjs` grep `http://`（排除 `localhost`/`127.0.0.1`）**零命中** → 页面不会因混合内容被浏览器拦资源。
- **两条实测更正（推翻既有文档结论）**：
  1. **「阿里云免费证书是单域名，不能加裸域名 443 块」错误** —— 本次证书 SAN **实际包含 `nz315.cn`**。实测裸域名 `https://nz315.cn` 现状为证书不匹配（`ERR_TLS_CERT_ALTNAME_INVALID`、`CN=www.cynx.cn`），真因是**没有裸域名的 443 server 块**、请求落到了 cynx 上，而**不是**证书不覆盖。→ 14 号文档 §2.3 已用删除线就地更正，并新增 §2.7 给出修法（补 `server_name nz315.cn` 的 `return 301` 块，精确匹配、**照旧不写 `default_server`**）。
  2. 14 号文档 §0 那张「cynx 占着 443 / https 全 404」的实测表**已全部过期**，保留为 09-17 历史证据。
- **仍未完成**：① 裸域名 443 跳转块**尚未执行**（用户已确认要做）；② `https://www.nz315.cn/MP_verify_OUOoNSqTrpZkfWli.txt` 实测仍 **404** —— nginx 两处 location 已就位，缺 `/www/server/nginx/html/` 下的文件（14 号文档 §2.4）→ **微信「网页授权域名」尚未配**；③ 公安联网备案。
- **运维提醒**：阿里云免费证书 **90 天、不自动续期**，**2026-12-16 到期**，到期前须重新申请并替换 `cert/nz315/` 两个文件 + `nginx -s reload`。
- **修改文件**：`AGENTS.md`（状态块 + 项目进度段）· `docs/handover/14-微信网页授权域名配置流程.md`（复核更新段 + §2.3 更正 + 新增 §2.7 + 排错表更正）· `docs/handover/09-部署进度-阿里云.md`（状态行 + §0）· `docs/handover/08-待办清单.md`（复核更新段：P0-2 作废、P0-7 可执行、新增 P0-10 与证书续期项）· `.workbuddy/memory/2026-09-18.md` · 本条目。**服务器上除 `nz315.conf` 外零改动；仓库代码零改动，未跑构建。**
- **给下一个 Agent 的提示**：① 摄像头相关改动先看 `app/composables/useQrScanner.ts`，**微信内置浏览器（尤其 iOS）不允许网页调相机**，已有相册选图兜底 `decodeImageFile` —— 真机验证请用**系统浏览器**，别在微信里测；② 判断证书是否覆盖某域名**只信实测 SAN**，不要按证书"类型"推断（本轮已因此翻车一次）；③ **SSH 不可用**，服务器操作由用户逐条粘贴执行、回贴输出。

> 📌 **2026-09-24 归档**：2026-08-31 … 09-17 的 **80 条**旧条目已折叠至 **`PROJECT_LOG-archive-2026-08-31_09-17.md`**（本轮记忆瘦身，条目原文零删改，只做搬运）。主文件保留 09-18 起的条目（含线 A / 线 B 上线记录）。

# PROJECT_LOG.md — 项目变更记录（Agent 交接档案）

> **本文件是项目的记忆备份**：让后续接手的 Agent 在最短时间内了解项目演进、最近改动与遗留问题。
> **使用规则**：每个参与本项目的 Agent 完成一轮修改后，**必须在「变更记录」最顶部追加一条记录**（不要覆盖历史），并在 `AGENTS.md` 的「项目进度」段同步更新。

---

## 变更记录模板（复制使用）

```
### YYYY-MM-DD | 标题（一句话概括本次工作）
- **工作内容**：做了什么、为什么做
- **修改文件**：涉及的文件路径清单
- **测试情况**：运行了哪些验证、结果如何
- **遗留问题/待办**：未完成事项、已知问题、后续建议
- **给下一个 Agent 的提示**：接手时需要特别注意什么
```

---


### 2026-08-31 | 数据概览板块增强（PRD 5.2/5.5.8：30天趋势折线图 + 快捷入口 + 码库存预警）
- **工作内容**：按用户指示聚焦数据概览板块，对照 PRD 补齐差距项：①扫码趋势由近 7 天条形图升级为**近 30 天折线图**（SVG 自绘：面积渐变 + 折线 + 数据点 + 轴刻度，API 侧补零保证连续 30 个日期点）；②新增 8 个**快捷入口**（生产采集/追溯码生成/码库管理/产品管理/生产批次/扫码统计/风险预警/消息中心，PRD 5.2 P2）；③新增**码库存预警**卡片（PRD 5.5.8：可用码低于 stockThreshold 阈值标红「低库存」、作废占比超 10% 告警，阈值从 system_setting 读取、默认 10000）。
- **修改文件**：`app/pages/admin/index.vue`、`server/api/admin/stats.get.ts`
- **测试情况**：dev(3100) 验证 stats API 12 字段齐全（scanTrend 30 点补零连续、stockThreshold=10000、stockAlerts 正确触发 lowStock+voidAbnormal）；Edge headless CDP 登录真实页面截图 + DOM 检查：折线图 polyline 渲染、快捷入口齐全、库存预警「低库存」红标签与「作废占比 25%」黄标签正常显示；提交 a239510。
- **遗留问题/待办**：①演示数据中个别产品名含乱码字符（数据问题，非 UI，AGENTS.md 已记录）；②本机 Chrome 无法 headless 启动（静默退出 code 0），截图已改用 Edge（同内核 CDP 可用），调试脚本保留在 screenshots/（不入库）；③其余列表页仍为旧风格可继续按码库页模式迁移
- **给下一个 Agent 的提示**：①MySQL 8 中 `generated` 是保留字，SQL 别名/排序勿用（已踩坑两次）；②数据概览折线图为 SVG 自绘（无图表库），坐标计算在 index.vue script 内，改样式注意 viewBox 与 PAD 常量；③vision API 有频控（429），截图验证优先用 CDP DOM 检查（scripts/check-dashboard-dom.mjs 可复用）
### 2026-08-31 | V1.0 生产构建验证通过 + 修复生产登录 500（SESSION_SECRET 未改默认值）
- **工作内容**：按 AGENTS.md 待办优先级执行生产构建验证（npm run build 全量构建 + 生产服务器运行验证），验证过程发现并修复一个生产环境登录故障。
- **验证过程与结论**：
