export default defineNuxtConfig({
  compatibilityDate: '2026-07-01',
  devtools: { enabled: false },
  modules: ['@nuxt/ui'],
  css: ['~/assets/css/main.css'],

  // Nitro 内联 zxing，避免 Windows 下 CJS 子模块被外置为裸盘符路径，导致所有请求 500。
  nitro: {
    externals: {
      inline: ['@zxing/library', 'xlsx'],
    },
  },

  // 页面组件 name 对齐路由名（Keep-Alive 按组件 name 精确缓存的前提）：
  // 后台页面均为 admin/*/index.vue，不开启时组件名全是 'index'，无法区分/精确缓存
  experimental: {
    normalizePageNames: true,
  },

  // Vite 文件监听忽略：调试残留与截图文件被浏览器锁定会触发 EBUSY
  vite: {
    server: {
      watch: {
        ignored: ['**/docs/.edge-tmp*/**', '**/docs/_tmp-*', '**/.dsh-vision-router/**'],
      },
    },
  },

  // 字体提供器：禁用 google/googleicons（外网不可达环境会超时并导致 dev 崩溃）
  fonts: {
    providers: {
      google: false,
      googleicons: false,
    },
  },

  // 图标使用本地 lucide 集合（离线，避免依赖 google fonts）
  icon: {
    serverBundle: { collections: ['lucide'] },
    clientBundle: { scan: true, sizeLimitKb: 512 },
  },

  runtimeConfig: {
    dbHost: process.env.DB_HOST || '127.0.0.1',
    dbPort: Number(process.env.DB_PORT || 3306),
    dbUser: process.env.DB_USER || 'root',
    dbPassword: process.env.DB_PASSWORD || '',
    dbName: process.env.DB_NAME || 'nz315',
    // 生产环境必须显式配置强随机 SESSION_SECRET，缺失则启动失败（防会话伪造）
    sessionSecret: process.env.SESSION_SECRET || (process.env.NODE_ENV === 'production'
      ? (() => { throw new Error('[FATAL] 生产环境必须设置 SESSION_SECRET 环境变量（建议: openssl rand -base64 48）') })()
      : 'dev-session-secret-change-me'),
    siteName: '农资315',
    // 微信公众号网页授权（消费者登录）：未配置时登录入口整体不可用，不做模拟登录
    wechatAppId: process.env.WECHAT_APP_ID || '',
    wechatAppSecret: process.env.WECHAT_APP_SECRET || '',
    // 高德 Web服务 key：**仅服务端**用于 IP 定位（server/utils/ip-geo.ts → 写 scan_log 的省/市）。
    // 2026-09-23 公众端「附近门店」（POI 周边搜索）整体下线后，本 key 只剩这一个调用方
    // ⇒ 配额被 POI 刷爆而绞杀省份写入的风险（P1-1 死穴）**物理消除**
    amapWebKey: process.env.AMAP_WEB_KEY || '',

    // 扫码 URL 前缀（PRD 3.3：https://{域名}/trace?code={32位码}），部署环境可用 NUXT_PUBLIC_TRACE_BASE_URL 覆盖
    public: {
      traceBaseUrl: process.env.NUXT_PUBLIC_TRACE_BASE_URL || 'https://www.nz315.cn/trace?code=',
      // 2026-09-23：「附近门店」整体下线（原地改为农资记账），高德 JS API（地图展示）一并移除 ⇒
      // 原先的 amapJsKey / amapSecurityCode 已删除（如服务器 .env 仍残留这两个变量，属无害死变量，
      // 不必特意去清理）。服务端的 amapWebKey 保留 —— ip-geo 还在用。
    },
  },

  app: {
    head: {
      meta: [
        { name: 'viewport', content: 'width=device-width, initial-scale=1, viewport-fit=cover' },
        { name: 'format-detection', content: 'telephone=no' },
      ],
      link: [{ rel: 'icon', type: 'image/svg+xml', href: '/favicon.svg' }],
    },
  },
})
