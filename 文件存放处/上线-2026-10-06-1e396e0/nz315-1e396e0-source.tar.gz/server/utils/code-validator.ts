// 追溯码解析校验（PRD 3.1 编码规则 + 5.5.2 校验项）
// 32 位结构：第1位登记类别(1=PD/2=WP)、2-7位登记证号后6位、第8位生产类型(1/2/3)、9-11位规格码、12位后自定义

export interface CodeCheckResult {
  line: string          // 原始行（可能含空白）
  code: string          // 清洗后的码
  valid: boolean
  reason: string        // 失败原因（空串=通过）
  reasonCode?: string   // 稳定原因代码，重复分类不依赖界面文案
  matchedProductId?: number | null  // 按完整11位头匹配的产品
}

// 行内「独立」32 位数字串（边界断言避免从更长数字串中截取 32 位子串，如 40 位序列号）
const CODE_RE = /(?<![0-9])[0-9]{32}(?![0-9])/

/**
 * 单行清洗 + 智能提取 32 位追溯码（2026-09-10 易用性增强）
 * 支持三种常见输入格式（用户拿生成页导出的任意文件都能直接上传）：
 *   ① 完整扫码链接：https://www.nz315.cn/trace?code=xxx（取 code 参数，兼容 ?code= / &code= / #code=）
 *   ② 纯 32 位码：整行仅数字（允许引号/逗号/空白/BOM 包裹）
 *   ③ 表格/CSV 行内独立 32 位数字串（如 sn 清单 CSV 的首列）
 * 三者都不是时返回清洗后原文，由 validateCode 报「未识别到 32 位追溯码」
 */
export function cleanLine(raw: string): string {
  const s = String(raw).replace(/^\uFEFF/, '').trim()
  if (!s) return ''
  // ① 扫码链接：优先取 code 参数（URL 中可能还有其它数字，参数最可靠）
  const mParam = s.match(/[?&#]code=([0-9]{32})(?![0-9])/i)
  if (mParam) return mParam[1] as string
  // ② 剥离常见分隔符后整行即 32 位码（纯码文件 / 带引号逗号包裹的单码）
  const stripped = s.replace(/[\s"',，;；]/g, '')
  if (/^[0-9]{32}$/.test(stripped)) return stripped
  // ③ 行内独立的 32 位数字串（CSV sn 清单首列、带前后缀的表格导出等）
  const mAny = s.match(CODE_RE)
  if (mAny) return mAny[0] as string
  // ④ 无法提取：返回清洗后原文（交由校验给出明确失败原因）
  return stripped || s
}

/**
 * 校验单行码（同步校验结构；产品/规格匹配由调用方传入上下文）
 * @param code 清洗后的码
 * @param ctx 企业产品完整头部与全库已有码集合
 */
export function validateCode(
  code: string,
  ctx: { products: { id: number; head: string }[]; existingSet: Set<string> },
  productId?: number,
): CodeCheckResult {
  const base: CodeCheckResult = { line: code, code, valid: false, reason: '' }
  if (!code) { base.reason = '空行'; base.reasonCode = 'EMPTY_LINE'; return base }

  // 长度与数字
  if (!/^\d{32}$/.test(code)) { base.reason = '未识别到 32 位追溯码'; base.reasonCode = 'INVALID_CODE'; return base }

  // 第1位：登记类别
  const first = code[0]
  if (first !== '1' && first !== '2') { base.reason = '第1位登记类别无效'; base.reasonCode = 'INVALID_CATEGORY'; return base }

  // 第8位：生产类型
  const eighth = code[7]
  if (eighth !== '1' && eighth !== '2' && eighth !== '3') { base.reason = '第8位生产类型无效'; base.reasonCode = 'INVALID_PRODUCTION'; return base }

  const candidates = productId === undefined ? ctx.products : ctx.products.filter(p => p.id === productId)
  const matches = candidates.filter(p => p.head === code.slice(0, 11))
  if (matches.length !== 1) {
    const product = candidates.find(p => p.head.slice(1, 7) === code.slice(1, 7))
    if (product) {
      const fields = [[0, 1, '登记类别'], [7, 8, '生产类型'], [8, 11, '规格码']] as const
      const diff = fields.find(([start, end]) => product.head.slice(start, end) !== code.slice(start, end))
      if (diff) {
        const [start, end, label] = diff
        base.reason = `第${start + 1}${end > start + 1 ? '–' + end : ''}位${label}与产品不一致（应为${product.head.slice(start, end)}，实际${code.slice(start, end)}）`
      } else base.reason = '码头部匹配多个产品，请检查产品建档'
    } else base.reason = productId === undefined ? '登记证后6位(' + code.slice(1, 7) + ')未匹配产品' : '码归属与所选产品不一致'
    base.reasonCode = 'PRODUCT_MISMATCH'
    return base
  }
  const matchedProductId = matches[0]!.id

  // 系统内重复
  if (ctx.existingSet.has(code)) { base.reason = '重复码'; base.reasonCode = 'DUPLICATE_DATABASE'; return base }

  base.valid = true
  base.matchedProductId = matchedProductId
  return base
}
